package Utils;

/**
 * class that represent Constants Parameters In System  
 * @version 1.0 
 * @project - Final Project 2021  
 * @Date 07.09.2021
 */
public class Constants {

	//************************************************************Class Members*********************************************************//

	/**
	 * max stations line colors for station name variable
	 */
	public static int stationsNumber = 2;
	
	/**
	 * price per travel variable
	 */	
	public static float pricePerTravel = (float) 5.99;
}
