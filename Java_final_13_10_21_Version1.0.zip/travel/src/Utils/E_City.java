package Utils;
/**
 * class that represent cities 
 */
public enum E_City {
	
	//-------------------------------------------------------------Values---------------------------------------------------------------------
	TelAviv("Tel Aviv"),RamatGan("Ramat Gan"),BatYam("Bat Yam"),BneiBrak("Bnei Brak"),GivatShmuel("Givat Shmuel"),Givataim("Givataim"),
	Herzelia("Herzelia"),Holon("Holon"),OrYehuda("Or Yehuda"),PetahTikva("Petah Tikva"),Yehud("Yehud");
	
	//-------------------------------------------------------------Class Members----------------------------------------------------------------
	/**
	 * city variable
	 */
	private final String city;
	
	//-------------------------------------------------------------Constructor------------------------------------------------------------------
	/**
	 * constructor
	 * @param city
	 */
	E_City(String city){
		this.city = city;
	}

	//-------------------------------------------------------------Methods----------------------------------------------------------------------
	/**
	 * get city method 
	 * @return city
	 */
	public String getCity() { 
		return city; 
	}
	
}
