package Utils;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
/**
 * class that represent Email Sending Methods In System  
 * @version 1.0 
 * @project - Final Project 2021  
 * @Date 07.09.2021
 */
public class EmailMethods {

	/**
	 * Method that send email for reset password
	 * @param email
	 * @param id
	 * @throws MalformedURLException
	 */
	public static void generateMail(String email,String id) throws MalformedURLException {
		//authentication info
				
				//user and password for email and server
				final String username = "ntatravel2021@yahoo.com";
				final String password = "ftkfqaddahbscudc";
				String fromEmail = "ntatravel2021@yahoo.com";
				//email that we send him the reset mail
				String toEmail = email;
				
				Properties properties = new Properties();
					//cfg port and host for mail preferences
				properties.put("mail.smtp.auth", "true");
				properties.put("mail.smtp.starttls.enable", "true");
				properties.put("mail.smtp.host", "smtp.mail.yahoo.com");
				properties.put("mail.smtp.port", "587");
				
				//start email session with user,password,host details
				Session session = Session.getInstance(properties, new javax.mail.Authenticator() {
					protected PasswordAuthentication getPasswordAuthentication() {
						return new PasswordAuthentication(username,password);
					}
				});
				//Start our mail message
				MimeMessage msg = new MimeMessage(session);
				try {
					msg.setFrom(new InternetAddress(fromEmail));
					msg.addRecipient(Message.RecipientType.TO, new InternetAddress(toEmail));
					//mail subject
					msg.setSubject("Reset Password For ID Number : "+id);
					
					
					Multipart emailContent = new MimeMultipart();
					//url for mail content
					URL myURL = new URL("http://62.90.44.179/travel/password_recovery_JAVA.php/");	
					//Text body for mail
					MimeBodyPart textBodyPart = new MimeBodyPart();
					textBodyPart.setText("Forgot Your Password?\n"+"No worries, use the link below to reset it\n"+myURL);
					
					
					//Attach body parts to mail
					emailContent.addBodyPart(textBodyPart);
					
					//Attach multipart to message
					msg.setContent(emailContent);
					//send mail
					Transport.send(msg);
					System.out.println("Sent message");
				} catch (MessagingException e) {
					e.printStackTrace();
				}

			}
		
	}


