package Utils;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.util.SystemOutLogger;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import Core.Address;
import Core.Card;
import Core.Customer;
import Core.Manager;
import Core.Travel;
import ExcelObjects.ExcelReportCustSearches;
import ExcelObjects.ExcelReportCustUse;
import ExcelObjects.ExcelReportIncome;
import application.Main;
import Core.*;

/**
 * Class that represent SQL Queries In System And Conncetion To DB  
 * @version 1.0 
 * @project - Final Project 2021  
 * @Date 07.09.2021
 */
public class SQL {
	public static  Travel travel= Main.getInstance();

	//************************************************************Class Members*********************************************************//

	/**
	 * connection url to DB
	 */
	static String connectionUrl = "jdbc:sqlserver://62.90.44.179:1433;databaseName=travelsystem;user=Admin;password=Daniel2021;" ;   

	/**
	 * Connection to db variable
	 */
	static Connection con = null;  

	/** 
	 * Sql statement variable
	 */
	static Statement stmt = null;  

	/**
	 * results set variable
	 */
	static ResultSet rs = null;  

	/**
	 * Prepare statement before use of sql variable
	 */
	static PreparedStatement pst=null;


	//************************************************************ Methods*********************************************************//

	/**
	 * method to connect to sql DB 
	 */
	public static void connectTo() {

		// SQL Server User Name And Password Setting

		String user = "Admin";
		String pass = "Daniel2021";


		try {
			// Establish the connection.
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			con = DriverManager.getConnection(connectionUrl, user, pass);
		}
		catch (Exception e) {
			e.printStackTrace();
		}

	}



	/**
	 * Sql Method To Add Line To DB
	 * @param color
	 * @param stationsSum
	 */
	public static void sqlAddLine(String color ,int stationsSum) {
		try {  
			//sql statement to add data to DB
			String SQL = "insert into TblLine (color, stationsSum) values (?,?) ";  
			pst = con.prepareStatement(SQL);  
			//set data into columns
			pst.setString(1, color);
			pst.setInt(2, stationsSum);

			int i=pst.executeUpdate(); 

			//success
			if(i==1) {
				System.out.println("there is one effeced row");
			}

		}  
		catch (SQLException e) {
			e.printStackTrace();
		}

		finally {
			//add data to sql and close connection with DB
			if (rs != null) try { rs.close(); } catch(Exception e) {}  
			if (stmt != null) try { stmt.close(); } catch(Exception e) {}
		} 

	}

	/**
	 * Sql Method To get managers employees from DB
	 */
	public static int getEmployeesManagersFromDB() {
		//connect to DB
		SQL.connectTo();
		//sql statement to add data to DB

		String sql ="select TblSystemUser.*,TblManager.startWorkingDate from TblManager inner join TblSystemUser on TblManager.id=TblSystemUser.id";

		Statement stmt = null;
		try {
			stmt = SQL.con.createStatement();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		ResultSet rs = null;
		try {
			rs = stmt.executeQuery(sql);
		} catch (SQLException e1) {
			e1.printStackTrace();
		}

		// loop through the result set
		try {
			while (rs.next()) {
				Manager s = new Manager(rs.getString("id"), rs.getString("firstName"), rs.getString("lastName"), rs.getString("email"),
						rs.getDate("birthDate"), rs.getString("pass"), rs.getString("phone"),rs.getDate("startWorkingDate"));
				Travel.addItem(travel.getManagers(), s.getId(), s);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return travel.getManagers().size();
	}

	
	/**
	 * Sql Method To get csr employees from DB
	 */
	public static int getEmployeesCSRFromDB() {
		//connect to DB
		SQL.connectTo();
		//sql statement to add data to DB

		String sql ="select TblSystemUser.*,TblCsr.startWorkingDate from TblCsr inner join TblSystemUser on TblCsr.id=TblSystemUser.id";

		Statement stmt = null;
		try {
			stmt = SQL.con.createStatement();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		ResultSet rs = null;
		try {
			rs = stmt.executeQuery(sql);
		} catch (SQLException e1) {
			e1.printStackTrace();
		}

		// loop through the result set
		try {
			while (rs.next()) {
				Csr s = new Csr(rs.getString("id"), rs.getString("firstName"), rs.getString("lastName"), rs.getString("email"),
						rs.getDate("birthDate"), rs.getString("pass"), rs.getString("phone"),rs.getDate("startWorkingDate"));
				Travel.addItem(travel.getCsr(), s.getId(), s);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return travel.getCsr().size();
	}

	
	/**
	 * Sql Method To get Lines from DB
	 */
	public static void getLines() {
		//connect to DB
		SQL.connectTo();
		//sql statement to get data from DB
		String sql ="select TblLine.* from TblLine";
		Statement stmt = null;
		try {
			stmt = SQL.con.createStatement();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		ResultSet rs = null;
		try {
			rs = stmt.executeQuery(sql);
		} catch (SQLException e1) {
			e1.printStackTrace();
		}

		// loop through the result set
		try {
			while (rs.next()) {
				Line l = new Line(E_LineColor.valueOf(rs.getString("color")),rs.getInt("stationsSum"));
				travel.getLines().add(l);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	/**
	 * Sql Method To get stations from DB
	 */
	public static int getStations() {
		//connect to DB
		SQL.connectTo();
		//sql statement to get data from DB
		String sql ="select distinct TblStation.* from  TblStation inner join TblLine on TblStation.primaryLine=TblLine.color OR TblStation.secondaryLine=TblLine.color"; 

		Statement stmt = null;
		try {
			stmt = SQL.con.createStatement();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		ResultSet rs = null;
		try {
			rs = stmt.executeQuery(sql);
		} catch (SQLException e1) {
			e1.printStackTrace();
		}

		// loop through the result set
		try {
			while (rs.next()) {
				Line primary=null;
				Line secondary=null;
				Station s = new Station(Integer.parseInt(rs.getString("stationNumber")), rs.getString("stationName"), rs.getBoolean("isJunction"), rs.getString("city"));
				for(Line l : travel.getLines()){
					if(l.getColor().toString().equals(rs.getString("primaryLine"))) {
						primary=l;
					}
					if(l.getColor().toString().equals(rs.getString("secondaryLine"))) {
						secondary=l;
					}
				}
				s.addLine(primary);
				if(secondary!=null) {
					s.addLine(secondary);
				}
				Travel.addItem(travel.getStations(), s.getStationName(), s);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return travel.getStations().size();
	}

	/**
	 * Sql Method To Add Manager To DB
	 * @param m
	 * @throws SQLException
	 */
	public static void addManager(Manager m) throws SQLException {
		//connect to DB
		connectTo();
		String SQL = null;
		try {
			//sql statement to add data to DB

			SQL = "insert into TblSystemUser (id, firstName,lastName,email,birthDate,pass,phone,img) values (?,?,?,?,?,?,?,?)";  
			pst = con.prepareStatement(SQL);  
			//set data into columns
			pst.setString(1, m.getId());
			pst.setString(2, m.getfName());
			pst.setString(3, m.getlName());
			pst.setString(4, m.getEmail()	);
			pst.setObject(5, m.getbDate());
			pst.setString(6, m.getPassword());
			pst.setString(7, m.getPhone());	
			pst.setObject(8, null);	
			pst.executeUpdate(); 

			SQL = "insert into TblManager (id,startWorkingDate) values (?,?) ";  
			pst = con.prepareStatement(SQL);  
			//set data into columns
			pst.setString(1, m.getId());
			pst.setObject(2, m.getStartWorkingDate());
			pst.executeUpdate(); 

		}  
		catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Sql Method To Add Csr Employee To DB
	 * @param c
	 * @throws SQLException
	 */
	public static void addCsr(Csr c) throws SQLException {
		//connect to DB
		connectTo();
		String SQL = null;
		try {
			//sql statement to add data to DB

			SQL = "insert into TblSystemUser (id, firstName,lastName,email,birthDate,pass,phone,img) values (?,?,?,?,?,?,?,?)";  
			pst = con.prepareStatement(SQL);  
			//set data into columns
			pst.setString(1, c.getId());
			pst.setString(2, c.getfName());
			pst.setString(3, c.getlName());
			pst.setString(4, c.getEmail()	);
			pst.setObject(5, c.getbDate());
			pst.setString(6, c.getPassword());
			pst.setString(7, c.getPhone());	
			pst.setObject(8, null);	
			pst.executeUpdate(); 

			SQL = "insert into TblCsr (id,startWorkingDate) values (?,?) ";  
			pst = con.prepareStatement(SQL);  
			//set data into columns
			pst.setString(1, c.getId());
			pst.setObject(2, c.getStartWorkingDate());
			pst.executeUpdate(); 

		}  
		catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Sql Method To Add Line To DB
	 * @param l
	 * @throws SQLException
	 */
	public static void addLine(Line l) throws SQLException {
		//connect to DB
		connectTo();
		String SQL = null;
		try {
			//sql statement to add data to DB

			SQL = "insert into TblColor (color) values (?)";  
			pst = con.prepareStatement(SQL);  
			pst.setString(1, l.getColor().toString());
			pst.executeUpdate(); 

			SQL = "insert into TblLine (color, stationsSum) values (?,?)";  
			pst = con.prepareStatement(SQL);  
			//set data into columns
			pst.setString(1, l.getColor().toString());
			pst.setInt(2,l.getStationSum());
			pst.executeUpdate(); 

		}  
		catch (SQLException e) {
			e.printStackTrace();
		}
	}


	/**
	 * Sql Method To Add Station To DB
	 * @param s
	 * @throws SQLException
	 */
	public static void addStation(Station s) throws SQLException {
		//connect to DB
		connectTo();
		String SQL = null;
		try {
			//sql statement to add data to DB
			SQL = "insert into TblStation(stationName,stationNumber,isJunction,city,primaryLine,secondaryLine) values (?,?,?,?,?,?)";  
			pst = con.prepareStatement(SQL);  
			pst.setString(1, s.getStationName());
			pst.setInt(2, s.getStationNumber());
			pst.setBoolean(3, s.isJunction());
			pst.setString(4, s.getCity());
			pst.setString(5, s.getLines().get(0).getColor().toString());
			if(s.getLines().size()>1) {
				if(!s.getLines().get(1).getColor().toString().equals(""))
					pst.setString(6, s.getLines().get(1).getColor().toString());
			}
			else {
				pst.setString(6, null);
			}
			pst.executeUpdate(); 
		}  
		catch (SQLException e) {
			e.printStackTrace();
		}
	}


	/**
	 * Sql Method To Remove Color From DB
	 * @param color
	 */
	public static void removeLine(String color) {
		//connect to DB
		SQL.connectTo();
		try { 
			//sql statement to remove data from table
			String sql = "DELETE FROM TblLine WHERE TblLine.color=?;"; 
			//set data for statement useage for removing data input
			pst = con.prepareStatement(sql);  
			pst.setString(1,color);

			int i=pst.executeUpdate(); 

			if(i==1) {
				System.out.println("there is one effeced row");
			}
		}  
		catch (SQLException e) {
			e.printStackTrace();
		}
	}


	/**
	 * Sql Method To Remove Manager From DB
	 * @param id
	 */
	public static void removeManager(String id) {
		//connect to DB
		SQL.connectTo();
		try { 
			//sql statement to remove data from table
			String sql = "DELETE FROM TblManager WHERE TblManager.id=?;"; 
			//set data for statement useage for removing data input
			pst = con.prepareStatement(sql);  
			pst.setString(1,id);

			int i=pst.executeUpdate(); 

			if(i==1) {
				System.out.println("there is one effeced row");
			}
		}  
		catch (SQLException e) {
			e.printStackTrace();
		}
		try { 
			//sql statement to remove data from table
			String sql = "DELETE FROM TblSystemUser WHERE TblSystemUser.id=?;"; 
			//set data for statement useage for removing data input
			pst = con.prepareStatement(sql);  
			pst.setString(1,id);

			int i=pst.executeUpdate(); 

			if(i==1) {
				System.out.println("there is one effeced row");
			}
		}  
		catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Sql Method To Remove Station From DB
	 * @param stationName
	 */
	public static void removeStation(String stationName) {
		//connect to DB
		SQL.connectTo();
		try { 
			//sql statement to remove data from table
			String sql = "DELETE FROM TblStation WHERE TblStation.stationName=?;"; 
			//set data for statement useage for removing data input
			pst = con.prepareStatement(sql);  
			pst.setString(1,stationName);

			int i=pst.executeUpdate(); 

			if(i==1) {
				System.out.println("there is one effeced row");
			}
		}  
		catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Sql Method To Change Password In DB
	 * @param id
	 * @param pass
	 */
	public static void changePassword(String id,String pass) {
		//connect to DB
		SQL.connectTo();
		try { 
			//sql statement to update data in table
			String sql = "UPDATE TblSystemUser Set TblSystemUser.pass=? WHERE TblSystemUser.id=?;"; 
			//set data into columns
			pst = con.prepareStatement(sql);  
			pst.setString(1,pass);
			pst.setString(2,id);

			int i=pst.executeUpdate(); 

			if(i==1) {
				System.out.println("there is one effeced row");
			}
		}  
		catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Sql Method To Change Admin User Password In DB
	 * @param user
	 * @param pass
	 */
	public static void changeAdminPassword(String user,String pass) {
		//connect to DB
		SQL.connectTo();
		try { 
			//sql statement to update data in table
			String sql = "UPDATE TblAdminUser Set TblAdminUser.pass=? WHERE TblAdminUser.userName=?;"; 
			//set data into columns
			pst = con.prepareStatement(sql);  
			pst.setString(1,pass);
			pst.setString(2,user);

			int i=pst.executeUpdate(); 

			if(i==1) {
				System.out.println("there is one effeced row");
			}
		}  
		catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Sql Method Change Manager Ditails In DB
	 * @param id
	 * @param fName
	 * @param lName
	 * @param phone
	 */
	public static void changeManagerDetails(String id,String fName,String lName,String phone) {
		//connect to DB
		SQL.connectTo();
		try { 
			//sql statement to update data in table
			String sql = "UPDATE TblSystemUser Set TblSystemUser.firstName=? , TblSystemUser.lastName=? , TblSystemUser.phone=? WHERE TblSystemUser.id=?;"; 
			//set data into columns
			pst = con.prepareStatement(sql);  
			pst.setString(1,fName);
			pst.setString(2,lName);
			pst.setString(3,phone);
			pst.setString(4,id);


			int i=pst.executeUpdate(); 

			if(i==1) {
				System.out.println("there is one effeced row");
			}
		}  
		catch (SQLException e) {
			e.printStackTrace();
		}
	}



	/**
	 * Sql Method To Get Table Stops In To DB
	 * @throws IOException
	 * @throws ParseException
	 */
	public static void getTblStopsInToDB() throws IOException, ParseException {

		/*Read Excel  File And Populate CardTypes Data*/
		/*Excel File Location*/
		File ExcelFile = new File("C:\\Users\\Roni\\Desktop\\s3.xlsx");

		FileInputStream fis = new FileInputStream(ExcelFile);
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		XSSFSheet sheetRed = workbook.getSheetAt(0);
		int rowTotal = sheetRed.getLastRowNum();
		//connect to DB
		connectTo();

		//get data from excel file
		for(int i=1;i<=rowTotal;i++) {
			Row row = sheetRed.getRow(i);
			int trainNumber=0,stopHour=0,passengersInTrain=0;
			String stationName="",startStation="",endStation="";
			Date stopDate=null;
			float stopMinute=0,loadParamter=0;
			int covid19InOut=0,direction=0;


			for(int j=0;j<11;j++) {
				if(j==0) {
					trainNumber=(int)Float.parseFloat(row.getCell(j).toString());
				}
				else if(j==1) {
					stationName=row.getCell(j).toString();
				}

				else if(j==2) {
					stopDate=new SimpleDateFormat("dd/MM/yyyy").parse(row.getCell(j).toString());  

				}
				else if(j==3) {
					stopHour=(int)Float.parseFloat(row.getCell(j).toString());
				}
				else if(j==4) {
					stopMinute=(int)Float.parseFloat(row.getCell(j).toString());
				}
				else if(j==5) {
					passengersInTrain=(int)Float.parseFloat(row.getCell(j).toString());
				}

				else if(j==6) {
					startStation=row.getCell(j).toString();
				}


				else if(j==7) {
					endStation=row.getCell(j).toString();
				}

				else if(j==8) {
					loadParamter=Float.parseFloat(row.getCell(j).toString());
				}

				else if(j==9) {
					covid19InOut=(int)Float.parseFloat(row.getCell(j).toString());
				}
				else if(j==10) {
					direction=(int)Float.parseFloat(row.getCell(j).toString());
				}
			}

			String SQL = null;
			try {
				//sql statement to add data to DB
				SQL = "insert into TblStopsIn(trainNumber,stationName,stopDate,stopHour,stopMinute,passengersInTrain,startStation,endStation,loadParameter,covid19InOut,direction) values (?,?,?,?,?,?,?,?,?,?,?)";  
				//set data into columns
				pst = con.prepareStatement(SQL);  
				pst.setInt(1,trainNumber);
				pst.setString(2,stationName);
				pst.setObject(3,stopDate);
				pst.setInt(4, stopHour);
				pst.setFloat(5, stopMinute);
				pst.setInt(6,passengersInTrain);
				pst.setString(7,startStation);
				pst.setString(8, endStation);
				pst.setFloat(9, loadParamter);
				pst.setInt(10, covid19InOut);
				pst.setInt(11, direction);

				pst.executeUpdate(); 
			}  
			catch (SQLException e) {
				e.printStackTrace();
			}

		}


	}



	/**
	 * Sql Method To Get Table Route In To DB
	 * @throws IOException
	 * @throws ParseException
	 */
	public static void getTblRouteToDB() throws IOException, ParseException {

		/*Read Excel  File And Populate CardTypes Data*/
		/*Excel File Location*/
		File ExcelFile = new File("C:\\Users\\Roni\\Desktop\\r4.xlsx");

		FileInputStream fis = new FileInputStream(ExcelFile);
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		XSSFSheet sheet = workbook.getSheetAt(0);
		int rowTotal = sheet.getLastRowNum();
		//connect to DB
		connectTo();
		

		for(int i=1;i<=rowTotal;i++) {
			Row row = sheet.getRow(i);
			int startHour=0,endHour=0,trainNumber=0;
			String sourceStationName="",destStationName="";
			Date routeDate=null;
			float startMinute=0,endMinute=0;

			//get data from excel file

			for(int j=0;j<8;j++) {
				if(j==0) {
					routeDate=new SimpleDateFormat("dd/MM/yyyy").parse(row.getCell(j).toString());  
				}
				else if(j==1) {
					startHour=(int)Float.parseFloat(row.getCell(j).toString());
				}

				else if(j==2) {
					endHour=(int)Float.parseFloat(row.getCell(j).toString());
				}
				else if(j==3) {
					startMinute=(int)Float.parseFloat(row.getCell(j).toString());
				}
				else if(j==4) {
					endMinute=(int)Float.parseFloat(row.getCell(j).toString());
				}
				else if(j==5) {
					sourceStationName=row.getCell(j).toString();
				}

				else if(j==6) {
					destStationName=row.getCell(j).toString();
				}


				else if(j==7) {
					trainNumber=(int) Float.parseFloat(row.getCell(j).toString());
				}
			}

			String SQL = null;
			try {
				//sql statement to add data to DB
				SQL = "insert into TblRoute(routeDate,startHour,endHour,startMinute,endMinute,sourceStationName,destStationName,trainNumber) values (?,?,?,?,?,?,?,?)";  
				//set data into columns
				pst = con.prepareStatement(SQL);  
				pst.setObject(1,routeDate);
				pst.setInt(2,startHour);
				pst.setInt(3,endHour);
				pst.setFloat(4, startMinute);
				pst.setFloat(5, endMinute);
				pst.setString(6,sourceStationName);
				pst.setString(7,destStationName);
				pst.setInt(8, trainNumber);			

				pst.executeUpdate(); 
			}  
			catch (SQLException e) {
				e.printStackTrace();
			}

		}


	}


	/**
	 * Sql Method To Get Customers Searches From DB By Dates
	 * @param from
	 * @param to
	 * @return
	 * @throws ParseException
	 */
	public static ArrayList<ExcelReportCustSearches> getCustSearchesFromDBByDates(String from ,String to) throws ParseException {

		ArrayList<ExcelReportCustSearches> data = new ArrayList<ExcelReportCustSearches>();

		Date fromDate =new SimpleDateFormat("yyyy-MM-dd").parse(from);  
		Date toDate =new SimpleDateFormat("yyyy-MM-dd").parse(to);  

		int fromYear = fromDate.getYear()+1900;
		int fromMonth = fromDate.getMonth()+1;
		int fromDay = fromDate.getDate();

		int toYear = toDate.getYear()+1900;
		int toMonth = toDate.getMonth()+1;
		int toDay = toDate.getDate();
		//connect to DB
		SQL.connectTo();
		//sql statement to get data from DB
		//get searches from table customer search
		String sql ="select t.*	from TblCustSearch as t where t.custDate between '"+from+"' and '"+to+"'";

		Statement stmt = null;
		try {
			stmt = SQL.con.createStatement();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		ResultSet rs = null;
		try {
			rs = stmt.executeQuery(sql);
		} catch (SQLException e1) {
			e1.printStackTrace();
		}

		// loop through the result set
		try {
			while (rs.next()) {
				String id = rs.getString("id");
				Date custDate = rs.getDate("custDate");
				int custHour = rs.getInt("custHour");
				float custMinute = rs.getFloat("custMinute");
				String sourceStationName = rs.getString("sourceStationName");
				String destStationName = rs.getString("destStationName");
				String sourceCity = rs.getString("sourceStationNameCity");
				String destCity = rs.getString("destinationStationNameCity");
				int covid = rs.getInt("covid19Val");
				float load = rs.getFloat("loadCust");

				ExcelReportCustSearches e = new ExcelReportCustSearches(id,custDate,custHour, custMinute, sourceStationName, destStationName, sourceCity,destCity,covid, load);
				data.add(e);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		//get searches from potential customer table search
		String sql2 ="select t.*,sCity=(select s.city from TblStation as s where s.stationName=t.sourceStationName),dCity=(select s.city from TblStation as s where s.stationName=t.destStationName) from TblPotentialUserSearch as t";

		Statement stmt2 = null;
		try {
			stmt2 = SQL.con.createStatement();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		ResultSet rs2 = null;
		try {
			rs2 = stmt2.executeQuery(sql2);
		} catch (SQLException e1) {
			e1.printStackTrace();
		}

		// loop through the result set
		try {
			while (rs2.next()) {
				String id = String.valueOf(rs2.getInt("potentialNumber"));
				Date custDate = rs2.getDate("custDate");
				int custHour = rs2.getInt("custHour");
				float custMinute = rs2.getFloat("custMinute");
				String sourceStationName = rs2.getString("sourceStationName");
				String destStationName = rs2.getString("destStationName");
				String sourceCity = rs2.getString("sCity");
				String destCity = rs2.getString("dCity");
				int covid =0;
				float load =0;

				ExcelReportCustSearches e = new ExcelReportCustSearches(id,custDate,custHour, custMinute, sourceStationName, destStationName, sourceCity,destCity,covid, load);
				data.add(e);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return data;

	}

	/**
	 * Sql Method To Get Customers Uses From DB By Dates
	 * @param from
	 * @param to
	 * @return ArrayList<ExcelReportCustUse>
	 * @throws ParseException
	 */
	public static ArrayList<ExcelReportCustUse> getCustUsesFromDBByDates(String from ,String to) throws ParseException {
		ArrayList<ExcelReportCustUse> data = new ArrayList<ExcelReportCustUse>();
		Date fromDate =new SimpleDateFormat("yyyy-MM-dd").parse(from);  
		Date toDate =new SimpleDateFormat("yyyy-MM-dd").parse(to);  

		int fromYear = fromDate.getYear()+1900;
		int fromMonth = fromDate.getMonth()+1;
		int fromDay = fromDate.getDate();

		int toYear = toDate.getYear()+1900;
		int toMonth = toDate.getMonth()+1;
		int toDay = toDate.getDate();
		//connect to DB
		SQL.connectTo();
		//sql statement to get data from DB
		String sql ="select t.* from TblCustomerExitEnter as t where t.exitEnterDate between '"+from+"' and '"+to+"'";

		Statement stmt = null;
		try {
			stmt = SQL.con.createStatement();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		ResultSet rs = null;
		try {
			rs = stmt.executeQuery(sql);
		} catch (SQLException e1) {
			e1.printStackTrace();
		}

		// loop through the result set
		try {
			while (rs.next()) {
				int custEnterExitId = rs.getInt("custEnterExitId");
				int id = rs.getInt("id");
				int stopsInId = rs.getInt("stopsInId");
				Date exitEnterDate = rs.getDate("exitEnterDate");
				int exitEnterHour = rs.getInt("exitEnterHour");
				float exitEnterMinute = rs.getFloat("exitEnterMinute");
				boolean exitEnter = rs.getBoolean("exitEnter");
				String startStation = rs.getString("statStation");
				String endStation = rs.getString("endStation");
				int trainNumber = rs.getInt("trainNumber");
				float loadParameter = rs.getFloat("loadParameter");
				int covid19InOut = rs.getInt("covid19InOut");
				int direction = rs.getInt("direction");
				String fromCity = rs.getString("fromCity");
				String toCity = rs.getString("toCity");
				String stationName=rs.getString("stationName");

				ExcelReportCustUse e = new ExcelReportCustUse(custEnterExitId,id,stopsInId,  exitEnterDate,  exitEnterHour,  exitEnterMinute,
						exitEnter,  startStation,  endStation,  trainNumber,loadParameter,
						covid19InOut, direction,fromCity,toCity,stationName) ;

				data.add(e);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return data;

	}

	/**
	 * Sql Method To Add Report To DB
	 * @throws SQLException
	 */
	public static void addReportId() throws SQLException {
		//connect to DB
		connectTo();
		String SQL = null;
		Date d = new Date();
		int year = d.getYear()+1900;
		int month = d.getMonth()+1;
		int day = d.getDate(); 

		String s = String.valueOf(year)+"-"+String.valueOf(month)+"-"+String.valueOf(day);
		try {
			//sql statement to add data to DB
			SQL = "insert into TblReport (reportDate) values (?)";  
			pst = con.prepareStatement(SQL); 
			pst.setString(1,s);

			pst.executeUpdate(); 
		}  
		catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Sql Method To Add Report To Manager In DB
	 * @param reportId
	 * @param empId
	 * @param reportType
	 * @throws SQLException
	 */
	public static void addReportToManager(int reportId,String empId,String reportType) throws SQLException {
		connectTo();
		String SQL=null;
		try {
			//sql statement to add data to DB
			SQL = "insert into TblReportsByManager (reportNumber,id,reportType) values (?,?,?)";  
			//set data into columns
			pst = con.prepareStatement(SQL); 
			pst.setInt(1,reportId);
			pst.setString(2,empId);
			pst.setString(3,reportType);

			pst.executeUpdate(); 
		}  
		catch (SQLException e) {
			e.printStackTrace();
		}

	}


	/**
	 * Sql Method To Get Max Report Id Number
	 * @return
	 * @throws SQLException
	 */
	public static int getMaxReportIdNumber() throws SQLException {
		//connect to DB
		SQL.connectTo();
		//sql statement to get data from DB
		String sql ="select max(t.reportNumber) as max from TblReport as t";
		Statement stmt = null;
		try {
			stmt = SQL.con.createStatement();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		ResultSet rs = null;
		try {
			rs = stmt.executeQuery(sql);
		} catch (SQLException e1) {
			e1.printStackTrace();
		}

		int ret=0;
		while (rs.next()) {
			ret = rs.getInt("max");
		}
		return ret;
	}

	/**
	 * Sql Method That Get Customers Uses From DB By Dates With Income
	 * @param from
	 * @param to
	 * @return
	 * @throws ParseException
	 */
	public static ArrayList<ExcelReportIncome> getCustUsesFromDBByDatesWithIncome(String from ,String to) throws ParseException {
		ArrayList<ExcelReportIncome> data = new ArrayList<ExcelReportIncome>();
		Date fromDate =new SimpleDateFormat("yyyy-MM-dd").parse(from);  
		Date toDate =new SimpleDateFormat("yyyy-MM-dd").parse(to);  

		int fromYear = fromDate.getYear()+1900;
		int fromMonth = fromDate.getMonth()+1;
		int fromDay = fromDate.getDate();

		int toYear = toDate.getYear()+1900;
		int toMonth = toDate.getMonth()+1;
		int toDay = toDate.getDate();
		//connect to DB
		SQL.connectTo();
		//sql statement to get data from DB
		String sql ="select t.* from TblCustomerExitEnter as t where t.exitEnterDate between '"+from+"' and '"+to+"'";

		Statement stmt = null;
		try {
			stmt = SQL.con.createStatement();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		ResultSet rs = null;
		try {
			rs = stmt.executeQuery(sql);
		} catch (SQLException e1) {
			e1.printStackTrace();
		}

		// loop through the result set
		try {
			while (rs.next()) {
				int custEnterExitId = rs.getInt("custEnterExitId");
				int id = rs.getInt("id");
				int stopsInId = rs.getInt("stopsInId");
				Date exitEnterDate = rs.getDate("exitEnterDate");
				int exitEnterHour = rs.getInt("exitEnterHour");
				float exitEnterMinute = rs.getFloat("exitEnterMinute");
				boolean exitEnter = rs.getBoolean("exitEnter");
				String startStation = rs.getString("statStation");
				String endStation = rs.getString("endStation");
				int trainNumber = rs.getInt("trainNumber");
				float loadParameter = rs.getFloat("loadParameter");
				int covid19InOut = rs.getInt("covid19InOut");
				int direction = rs.getInt("direction");
				String fromCity = rs.getString("fromCity");
				String toCity = rs.getString("toCity");
				String stationName=rs.getString("stationName");

				ExcelReportIncome e = new ExcelReportIncome(custEnterExitId,id,stopsInId,  exitEnterDate,  exitEnterHour,  exitEnterMinute,
						exitEnter,  startStation,  endStation,  trainNumber,loadParameter,
						covid19InOut, direction,fromCity,toCity,stationName,Constants.pricePerTravel) ;

				data.add(e);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return data;

	}

	/**
	 * Sql Method That Get Station Color
	 * @param stationName
	 * @return
	 * @throws SQLException
	 */
	public static String getStationColor(String stationName) throws SQLException {
		//connect to DB
		SQL.connectTo();
		String sql ="select t.primaryLine as c  from TblStation as t where t.stationName like '"+stationName+"'";
		Statement stmt = null;
		try {
			stmt = SQL.con.createStatement();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		ResultSet rs = null;
		try {
			rs = stmt.executeQuery(sql);
		} catch (SQLException e1) {
			e1.printStackTrace();
		}

		String ret="";
		while (rs.next()) {
			ret = rs.getString("c");
		}
		return ret;
	}


	/**
	 * Sql Method That Add Table Cards To DB
	 * @throws IOException
	 * @throws ParseException
	 */
	public static void getTblCardsToDB() throws IOException, ParseException {

		/*Read Excel  File And Populate CardTypes Data*/
		/*Excel File Location*/
		File ExcelFile = new File("C:\\Users\\Roni\\Desktop\\Cards.xlsx");

		FileInputStream fis = new FileInputStream(ExcelFile);
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		XSSFSheet sheet = workbook.getSheetAt(0);
		int rowTotal = sheet.getLastRowNum();
		//connect to DB
		connectTo();


		for(int i=1;i<=rowTotal;i++) {
			Row row = sheet.getRow(i);
			float moneyAmount=0;
			Date cardDate=new Date();


			for(int j=0;j<2;j++) {
				if(j==0) {
					moneyAmount=Float.parseFloat(row.getCell(j).toString());
				}
				else if(j==1) {
					cardDate=new SimpleDateFormat("dd/MM/yyyy").parse(row.getCell(j).toString());  
				}


				String SQL = null;
				try {
					//sql statement to add data to DB
					SQL = "insert into TblCard(moneyAmount,cardDate) values (?,?)";  
					//set data into columns
					pst = con.prepareStatement(SQL);  
					pst.setFloat(1,moneyAmount);
					pst.setObject(2,cardDate);

					pst.executeUpdate(); 
				}  
				catch (SQLException e) {
					e.printStackTrace();
				}

			}

		}
	}


	/**
	 * Sql Method That Add Table System User To DB
	 * @throws ParseException
	 * @throws IOException
	 */
	public static void getTblSystemUserToDB() throws ParseException, IOException {

		/*Excel File Location*/
		File ExcelFile = new File("C:\\Users\\Roni\\Desktop\\SystemUser.xlsx");

		FileInputStream fis = new FileInputStream(ExcelFile);
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		XSSFSheet sheet1 = workbook.getSheetAt(0);
		int rowTotal = sheet1.getLastRowNum();
		//connect to DB
		connectTo();


		for(int i=1;i<=rowTotal;i++) {
			Row row = sheet1.getRow(i);
			String id="",firstName="",lastName="",email="",pass="",phone="",img="";
			Date birthDate=new Date();


			//get data from excel file

			for(int j=0;j<8;j++) {

				if(j==0) {
					int num=0;
					num=(int)Double.parseDouble(row.getCell(j).toString());					
					id = String.valueOf(num);
				}
				else if(j==1) {
					firstName=row.getCell(j).toString();

				}
				else if(j==2) {
					lastName=row.getCell(j).toString();

				}
				else if(j==3) {
					email=row.getCell(j).toString();

				}
				else if(j==4) {
					birthDate=new SimpleDateFormat("dd/MM/yyyy").parse(row.getCell(j).toString());  
				}

				else if(j==5) {
					pass=row.getCell(j).toString();
				}

				else if(j==6) {
					phone=row.getCell(j).toString();
				}
				else if(j==7) {
					img=row.getCell(j).toString();
				}

			}
			String SQL = null;
			try {
				//sql statement to add data to DB
				SQL = "insert into TblSystemUser(id,firstName,lastName,email,birthDate,pass,phone,img) values (?,?,?,?,?,?,?,?)";  
				//set data into columns
				pst = con.prepareStatement(SQL);  
				pst.setString(1,id);
				pst.setString(2,firstName);
				pst.setString(3,lastName);
				pst.setString(4,email);
				pst.setObject(5,birthDate);
				pst.setString(6,pass);
				pst.setString(7,phone);
				pst.setObject(8,img);

				pst.executeUpdate(); 
			}  
			catch (SQLException e) {
				e.printStackTrace();
			}

		}


	}



	/**
	 * Sql Method That Add Table Customers User To DB
	 * @throws ParseException
	 * @throws IOException
	 */
	public static void getTblCustomerToDB() throws ParseException, IOException {

		/*Excel File Location*/
		File ExcelFile = new File("C:\\Users\\Roni\\Desktop\\Customers.xlsx");

		FileInputStream fis = new FileInputStream(ExcelFile);
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		XSSFSheet sheet1 = workbook.getSheetAt(0);
		int rowTotal = sheet1.getLastRowNum();
		//connect to DB
		connectTo();

		for(int i=1;i<=rowTotal;i++) {
			Row row = sheet1.getRow(i);
			String id="",city="",zipCode="",street="";
			int covid19Val=0,cardNumber=0,buildingNumber=0,departmentNumber=0;
			Date joinDate=new Date();
			float loadCust=0;

			//get data from excel file

			for(int j=0;j<10;j++) {

				if(j==0) {
					int num=0;
					num=(int)Double.parseDouble(row.getCell(j).toString());					
					id = String.valueOf(num);
				}
				else if(j==1) {

					covid19Val=(int)Float.parseFloat(row.getCell(j).toString());
				}
				else if(j==2) {
					joinDate=new SimpleDateFormat("dd/MM/yyyy").parse(row.getCell(j).toString());  
				}
				else if(j==3) {
					cardNumber=(int)Double.parseDouble(row.getCell(j).toString());
				}

				else if(j==4) {
					city=row.getCell(j).toString();
				}

				else if(j==5) {
					int zip = (int)Float.parseFloat(row.getCell(j).toString());
					zipCode=String.valueOf(zip);
				}

				else if(j==6) {
					loadCust=Float.parseFloat(row.getCell(j).toString());

				}
				
				else if(j==7) {
					street = row.getCell(j).toString();
				}
				else if(j==8) {
					buildingNumber=(int)Float.parseFloat(row.getCell(j).toString());
				}
				else if(j==9) {
					departmentNumber=(int)Float.parseFloat(row.getCell(j).toString());
				}


			}
			String SQL = null;
			try {
				//sql statement to add data to DB
				SQL = "insert into TblCustomer(id,covid19Val,joinDate,cardNumber,city,zipCode,loadCust,street,bulidingNumber,departmentNumber) values (?,?,?,?,?,?,?,?,?,?)";  
				pst = con.prepareStatement(SQL);  
				//set data into columns
				pst.setString(1,id);
				pst.setInt(2,covid19Val);
				pst.setObject(3,joinDate);
				pst.setInt(4,cardNumber);
				pst.setString(5,city);
				pst.setString(6,zipCode);
				pst.setFloat(7,loadCust);
				pst.setString(8,street);
				pst.setInt(9,buildingNumber);
				pst.setInt(10,departmentNumber);

				pst.executeUpdate(); 
			}  
			catch (SQLException e) {
				e.printStackTrace();
			}

		}


	}


	/**
	 * Sql Method That Add Table Customers Exit/Enter To DB
	 * @throws ParseException
	 * @throws IOException
	 */
	public static void getTblCustomersExitEnterToDB() throws ParseException, IOException {

		/*Excel File Location*/
		File ExcelFile = new File("C:\\Users\\Roni\\Desktop\\e1.xlsx");

		FileInputStream fis = new FileInputStream(ExcelFile);
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		XSSFSheet sheet1 = workbook.getSheetAt(0);
		int rowTotal = sheet1.getLastRowNum();
		//connect to DB
		connectTo();

		for(int i=1;i<=rowTotal;i++) {
			Row row = sheet1.getRow(i);
			String id="",statStation="",endStation="",fromCity="",toCity="",stationName="";
			int stopsInId=0,exitEnterHour=0,exitEnter=0,trainNumber=0,covid19InOut=0,direction=0;
			Date exitEnterDate=null;
			float exitEnterMinute=0,loadParameter=0;


			//get data from excel file

			for(int j=0;j<15;j++) {

				if(j==0) {
					int num=0;
					num=(int)Double.parseDouble(row.getCell(j).toString());					
					id = String.valueOf(num);
				}
				else if(j==1) {
					stopsInId=(int)Float.parseFloat(row.getCell(j).toString());
				}

				else if(j==2) {
					exitEnterDate=new SimpleDateFormat("dd/MM/yyyy").parse(row.getCell(j).toString());  
				}
				else if(j==3) {
					exitEnterHour=(int)Double.parseDouble(row.getCell(j).toString());
				}

				else if(j==4) {
					exitEnterMinute=Float.parseFloat(row.getCell(j).toString());
				}

				else if(j==5) {
					exitEnter=(int)Double.parseDouble(row.getCell(j).toString());
				}

				else if(j==6) {
					statStation = row.getCell(j).toString();
				}

				else if(j==7) {
					endStation = row.getCell(j).toString();
				}
				else if(j==8) {
					trainNumber=(int)Double.parseDouble(row.getCell(j).toString());

				}
				else if(j==9) {
					loadParameter = Float.parseFloat(row.getCell(j).toString());

				}
				else if(j==10) {
					covid19InOut=(int)Double.parseDouble(row.getCell(j).toString());

				}
				else if(j==11) {
					direction=(int)Double.parseDouble(row.getCell(j).toString());
				}
				else if(j==12) {
					fromCity = row.getCell(j).toString();
				}
				else if(j==13) {
					toCity = row.getCell(j).toString();

				}
				else if(j==14) {
					stationName = row.getCell(j).toString();
				}
			}
			String SQL = null;
			try {
				//sql statement to add data to DB
				SQL = "insert into TblCustomerExitEnter(id,stopsInId,exitEnterDate,exitEnterHour,exitEnterMinute,exitEnter,statStation,endStation,trainNumber,loadParameter,covid19InOut,direction,fromCity,toCity,stationName) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";  
				pst = con.prepareStatement(SQL);  
				pst.setString(1,id);
				pst.setInt(2,stopsInId);
				pst.setObject(3,exitEnterDate);
				pst.setInt(4,exitEnterHour);
				pst.setFloat(5,exitEnterMinute);
				pst.setInt(6,exitEnter);
				pst.setString(7,statStation);
				pst.setString(8,endStation);
				pst.setInt(9,trainNumber);
				pst.setFloat(10,loadParameter);
				pst.setInt(11,covid19InOut);
				pst.setInt(12,direction);
				pst.setString(13,fromCity);
				pst.setString(14,toCity);
				pst.setString(15,stationName);

				pst.executeUpdate(); 
			}  
			catch (SQLException e) {
				e.printStackTrace();
			}

		}


	}

	/**
	 * Sql Method To get notifications from DB
	 */
	public static ArrayList<Notifacation> getNotifacationsFromDB() {
		//connect to DB
		SQL.connectTo();
		//sql statement to add data to DB

		String sql ="select * from TblNotification as t where t.active=1";
		ArrayList<Notifacation> data = new ArrayList<Notifacation>();
		Statement stmt = null;
		try {
			stmt = SQL.con.createStatement();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		ResultSet rs = null;
		try {
			rs = stmt.executeQuery(sql);
		} catch (SQLException e1) {
			e1.printStackTrace();
		}

		// loop through the result set
		try {
			while (rs.next()) {
				Notifacation n = new Notifacation(rs.getInt("id"),rs.getString("details"),rs.getDate("notifyDate"),rs.getBoolean("active"));
				data.add(n);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return data;
	}



	/**
	 * Sql Method To Add Notification To DB
	 * @param color
	 * @param stationsSum
	 */
	public static void sqlAddNotifacation(Notifacation n) {
		try {  
			//connect to DB
			SQL.connectTo();
			//sql statement to add data to DB
			String SQL = "insert into TblNotification (details,notifyDate,active) values (?,?,?) ";  

			pst = con.prepareStatement(SQL);  

			//set data into columns
			pst.setString(1,n.getDetails());
			pst.setObject(2,n.getNotifyDate());
			pst.setBoolean(3,true);

			int i=pst.executeUpdate(); 

			//success
			if(i==1) {
				System.out.println("there is one effeced row");
			}

		}  
		catch (SQLException e) {
			e.printStackTrace();
		}

		finally {
			//add data to sql and close connection with DB
			if (rs != null) try { rs.close(); } catch(Exception e) {}  
			if (stmt != null) try { stmt.close(); } catch(Exception e) {}
		} 

	}

	/**
	 * Sql Method To Remove Notification From DB
	 * @param color
	 */
	public static void removeNotification(int number) {
		//connect to DB
		SQL.connectTo();
		try { 
			//sql statement to remove data from table
			String sql = "DELETE FROM TblNotification WHERE id=?;"; 
			//set data for statement useage for removing data input
			pst = con.prepareStatement(sql);  
			pst.setInt(1,number);

			int i=pst.executeUpdate(); 

			if(i==1) {
				System.out.println("there is one effeced row");
			}
		}  
		catch (SQLException e) {
			e.printStackTrace();
		}
	}


	/**
	 * Sql Method That Add Table CustomersAddresses To DB
	 * @throws ParseException
	 * @throws IOException
	 */
	public static void getTblAddressesToDB() throws ParseException, IOException {

		/*Excel File Location*/
		File ExcelFile = new File("C:\\Users\\Roni\\Desktop\\addresses.xlsx");

		FileInputStream fis = new FileInputStream(ExcelFile);
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		XSSFSheet sheet1 = workbook.getSheetAt(0);
		int rowTotal = sheet1.getLastRowNum();
		//connect to DB
		connectTo();

		for(int i=1;i<=rowTotal;i++) {
			Row row = sheet1.getRow(i);
			String city="",zipCode="",street="";
			int buildingNumber=0,departmentNumber=0;

			//get data from excel file

			for(int j=0;j<5;j++) {

				if(j==0) {
					city = row.getCell(j).toString();
				}
				else if(j==1) {
					int num=(int)Float.parseFloat(row.getCell(j).toString());
					zipCode = String.valueOf(num);	
				}

				else if(j==2) {
					street = row.getCell(j).toString();
				}
				else if(j==3) {
					buildingNumber=(int)Float.parseFloat(row.getCell(j).toString());
				}
				else if(j==4) {
					departmentNumber=(int)Float.parseFloat(row.getCell(j).toString());
				}


			}
			String SQL = null;
			try {
				//sql statement to add data to DB
				SQL = "insert into TblAddress(city,zipCode,street,bulidingNumber,departmentNumber) values (?,?,?,?,?)";  
				pst = con.prepareStatement(SQL);  
				pst.setString(1,city);
				pst.setString(2,zipCode);
				pst.setString(3,street);
				pst.setInt(4,buildingNumber);
				pst.setInt(5,departmentNumber);

				pst.executeUpdate(); 
			}  
			catch (SQLException e) {
				e.printStackTrace();
			}

		}

	}



	/**
	 * Sql Method To get number of customers that joined to system in current month
	 * @throws ParseException 
	 * @throws SQLException 
	 */
	public static int countCustInDBInThisMonth(Date d) throws ParseException, SQLException {
		//connect to DB
		SQL.connectTo();
		//configure dates for count
		int month = d.getMonth()+1;
		int i=0;
		int year = d.getYear()+1900;
		int firstDay =1;
		String date = String.valueOf(firstDay)+"-"+String.valueOf(month)+"-"+String.valueOf(year);
		String lastDay = MethodsCheckInput.getLastDay(date);
		int last = Integer.parseInt(lastDay);
		String from = String.valueOf(year)+"-"+String.valueOf(month)+"-01";
		String to = String.valueOf(year)+"-"+String.valueOf(month)+"-"+lastDay;
		//sql statement 
		String sql ="select count(*) as c from TblCustomer as t where t.joinDate between '"+from+"' and '"+ to+ "'";
		Statement stmt = null;
		try {
			stmt = SQL.con.createStatement();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		ResultSet rs = null;
		try {
			rs = stmt.executeQuery(sql);
		} catch (SQLException e1) {
			e1.printStackTrace();
		}

		while (rs.next()) {
			i = rs.getInt("c");
		}
		return i;
	}

	/**
	 * Sql Method To get customers searches count in current month
	 * @throws ParseException 
	 * @throws SQLException 
	 */
	public static int countCustSearchesInDBInThisMonth(Date d) throws ParseException, SQLException {
		//connect to DB
		SQL.connectTo();
		//configure dates for count
		int month = d.getMonth()+1;
		int i=0;
		int year = d.getYear()+1900;
		int firstDay =1;
		String date = String.valueOf(firstDay)+"-"+String.valueOf(month)+"-"+String.valueOf(year);
		String lastDay = MethodsCheckInput.getLastDay(date);
		int last = Integer.parseInt(lastDay);
		String from = String.valueOf(year)+"-"+String.valueOf(month)+"-01";
		String to = String.valueOf(year)+"-"+String.valueOf(month)+"-"+lastDay;
		//sql statement 
		String sql ="select count(*) as c from TblCustSearch as t where t.custDate between '"+from+"' and '"+ to+ "'";
		Statement stmt = null;
		try {
			stmt = SQL.con.createStatement();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		ResultSet rs = null;
		try {
			rs = stmt.executeQuery(sql);
		} catch (SQLException e1) {
			e1.printStackTrace();
		}

		while (rs.next()) {
			i = rs.getInt("c");
		}
		return i;
	}


	/**
	 * Sql Method To get potential customers searches count in current month
	 * @throws ParseException 
	 * @throws SQLException 
	 */
	public static int countPotentialCustomersSearchesInDBInThisMonth(Date d) throws ParseException, SQLException {
		//connect to DB
		SQL.connectTo();
		//configure dates for count
		int month = d.getMonth()+1;
		int i=0;
		int year = d.getYear()+1900;
		int firstDay =1;
		String date = String.valueOf(firstDay)+"-"+String.valueOf(month)+"-"+String.valueOf(year);
		String lastDay = MethodsCheckInput.getLastDay(date);
		int last = Integer.parseInt(lastDay);
		String from = String.valueOf(year)+"-"+String.valueOf(month)+"-01";
		String to = String.valueOf(year)+"-"+String.valueOf(month)+"-"+lastDay;
		//sql statement 
		String sql ="select count(*) as c from TblPotentialUserSearch as t where t.custDate between '"+from+"' and '"+ to+ "'";
		Statement stmt = null;
		try {
			stmt = SQL.con.createStatement();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		ResultSet rs = null;
		try {
			rs = stmt.executeQuery(sql);
		} catch (SQLException e1) {
			e1.printStackTrace();
		}

		while (rs.next()) {
			i = rs.getInt("c");
		}
		return i;
	}


	/**
	 * Sql Method To get number of red line uses this month
	 * @throws ParseException 
	 * @throws SQLException 
	 */
	public static int countXLineUsesInDBInThisMonth(Date d,String color) throws ParseException, SQLException {
		//connect to DB
		SQL.connectTo();
		//configure dates for count
		int month = d.getMonth()+1;
		int i=0;
		int year = d.getYear()+1900;
		int firstDay =1;
		String date = String.valueOf(firstDay)+"-"+String.valueOf(month)+"-"+String.valueOf(year);
		String lastDay = MethodsCheckInput.getLastDay(date);
		int last = Integer.parseInt(lastDay);
		String from = String.valueOf(year)+"-"+String.valueOf(month)+"-01";
		String to = String.valueOf(year)+"-"+String.valueOf(month)+"-"+lastDay;
		//sql statement 
		String sql ="select count(*) as c from TblCustomerExitEnter as t inner join TblStation as s on t.stationName=s.stationName where s.primaryLine like '"+color+"' and t.exitEnterDate between '"+from+"' and '"+ to+ "'";
		Statement stmt = null;
		try {
			stmt = SQL.con.createStatement();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		ResultSet rs = null;
		try {
			rs = stmt.executeQuery(sql);
		} catch (SQLException e1) {
			e1.printStackTrace();
		}

		while (rs.next()) {
			i = rs.getInt("c");
		}
		return i;
	}
	


	/**
	 * Sql Method To get number of customers that joined to system in dates difference
	 * @throws ParseException 
	 * @throws SQLException 
	 */
	public static int countCustInDBInThisMonth(String from,String to) throws ParseException, SQLException {
		//connect to DB
		SQL.connectTo();
		int i=0;
		//sql statement 
		String sql ="select count(*) as c from TblCustomer as t where t.joinDate between '"+from+"' and '"+ to+ "'";
		Statement stmt = null;
		try {
			stmt = SQL.con.createStatement();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		ResultSet rs = null;
		try {
			rs = stmt.executeQuery(sql);
		} catch (SQLException e1) {
			e1.printStackTrace();
		}

		while (rs.next()) {
			i = rs.getInt("c");
		}
		return i;
	}

	/**
	 * Sql Method To get customers searches count in in dates difference
	 * @throws ParseException 
	 * @throws SQLException 
	 */
	public static int countCustSearchesInDBInThisMonth(String from,String to) throws ParseException, SQLException {
		//connect to DB
		SQL.connectTo();
		//configure dates for count
		int i=0;
		int firstDay =1;
	
		//sql statement 
		String sql ="select count(*) as c from TblCustSearch as t where t.custDate between '"+from+"' and '"+ to+ "'";
		Statement stmt = null;
		try {
			stmt = SQL.con.createStatement();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		ResultSet rs = null;
		try {
			rs = stmt.executeQuery(sql);
		} catch (SQLException e1) {
			e1.printStackTrace();
		}

		while (rs.next()) {
			i = rs.getInt("c");
		}
		return i;
	}


	/**
	 * Sql Method To get potential customers searches count in dates difference
	 * @throws ParseException 
	 * @throws SQLException 
	 */
	public static int countPotentialCustomersSearchesInDBInThisMonth(String from,String to) throws ParseException, SQLException {
		//connect to DB
		SQL.connectTo();
		//configure dates for count
		int i=0;
	
		//sql statement 
		String sql ="select count(*) as c from TblPotentialUserSearch as t where t.custDate between '"+from+"' and '"+ to+ "'";
		Statement stmt = null;
		try {
			stmt = SQL.con.createStatement();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		ResultSet rs = null;
		try {
			rs = stmt.executeQuery(sql);
		} catch (SQLException e1) {
			e1.printStackTrace();
		}

		while (rs.next()) {
			i = rs.getInt("c");
		}
		return i;
	}


	/**
	 * Sql Method To get number of red line uses in dates difference
	 * @throws ParseException 
	 * @throws SQLException 
	 */
	public static int countXLineUsesInDBInThisMonth(String from,String to,String color) throws ParseException, SQLException {
		//connect to DB
		SQL.connectTo();
		//configure dates for count
		int i=0;
	
		//sql statement 
		String sql ="select count(*) as c from TblCustomerExitEnter as t inner join TblStation as s on t.stationName=s.stationName where s.primaryLine like '"+color+"' and t.exitEnterDate between '"+from+"' and '"+ to+ "'";
		Statement stmt = null;
		try {
			stmt = SQL.con.createStatement();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		ResultSet rs = null;
		try {
			rs = stmt.executeQuery(sql);
		} catch (SQLException e1) {
			e1.printStackTrace();
		}

		while (rs.next()) {
			i = rs.getInt("c");
		}
		return i;
	}
	
	
	/**
	 * Sql Method To Remove Customer From DB
	 * @param id
	 */
	public static void removeCustomer(String id) {
		//connect to DB
		SQL.connectTo();
		try { 
			//sql statement to remove data from table
			String sql = "DELETE FROM TblCustomer WHERE TblCustomer.id=?;"; 
			//set data for statement useage for removing data input
			pst = con.prepareStatement(sql);  
			pst.setString(1,id);

			int i=pst.executeUpdate(); 

			if(i==1) {
				System.out.println("there is one effeced row");
			}
		}  
		catch (SQLException e) {
			e.printStackTrace();
		}
		try { 
			//sql statement to remove data from table
			String sql = "DELETE FROM TblSystemUser WHERE TblSystemUser.id=?;"; 
			//set data for statement useage for removing data input
			pst = con.prepareStatement(sql);  
			pst.setString(1,id);

			int i=pst.executeUpdate(); 

			if(i==1) {
				System.out.println("there is one effeced row");
			}
		}  
		catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Sql Method To Remove CSR Employee From DB
	 * @param id
	 */
	public static void removeCsr(String id) {
		//connect to DB
		SQL.connectTo();
		try { 
			//sql statement to remove data from table
			String sql = "DELETE FROM TblCsr WHERE TblCsr.id=?;"; 
			//set data for statement useage for removing data input
			pst = con.prepareStatement(sql);  
			pst.setString(1,id);

			int i=pst.executeUpdate(); 

			if(i==1) {
				System.out.println("there is one effeced row");
			}
		}  
		catch (SQLException e) {
			e.printStackTrace();
		}
		try { 
			//sql statement to remove data from table
			String sql = "DELETE FROM TblSystemUser WHERE TblSystemUser.id=?;"; 
			//set data for statement useage for removing data input
			pst = con.prepareStatement(sql);  
			pst.setString(1,id);

			int i=pst.executeUpdate(); 

			if(i==1) {
				System.out.println("there is one effeced row");
			}
		}  
		catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	
	/**
	 * Sql Method That check if customer exist in db and return customer id
	 * @param id
	 * @return
	 * @throws SQLException
	 */
	public static String getCust(String id) throws SQLException {
		//connect to DB
		SQL.connectTo();
		String sql ="select t.id from TblCustomer as t where t.id="+id;
		Statement stmt = null;
		try {
			stmt = SQL.con.createStatement();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		ResultSet rs = null;
		try {
			rs = stmt.executeQuery(sql);
		} catch (SQLException e1) {
			e1.printStackTrace();
		}

		String ret="";
		while (rs.next()) {
			ret = rs.getString("id");
		}
		return ret;
	}
	
	/**
	 * Sql Method That check if CSR exist in db and return CSR id
	 * @param id
	 * @return
	 * @throws SQLException
	 */
	public static String getCSR(String id) throws SQLException {
		//connect to DB
		SQL.connectTo();
		String sql ="select t.id from TblCsr as t where t.id="+id;
		Statement stmt = null;
		try {
			stmt = SQL.con.createStatement();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		ResultSet rs = null;
		try {
			rs = stmt.executeQuery(sql);
		} catch (SQLException e1) {
			e1.printStackTrace();
		}

		String ret="";
		while (rs.next()) {
			ret = rs.getString("id");
		}
		return ret;
	}
	
		
	
	/**
	 * Sql Method To Add Customer To DB
	 * @param c
	 * @throws SQLException
	 */
	public static void addCustomer(Customer c) throws SQLException {
		//connect to DB
		connectTo();
		String SQL = null;
		try {
			//sql statement to add data to DB

			SQL = "insert into TblSystemUser (id, firstName,lastName,email,birthDate,pass,phone,img) values (?,?,?,?,?,?,?,?)";  
			pst = con.prepareStatement(SQL);  
			//set data into columns
			pst.setString(1, c.getId());
			pst.setString(2, c.getfName());
			pst.setString(3, c.getlName());
			pst.setString(4, c.getEmail()	);
			pst.setObject(5, c.getbDate());
			pst.setString(6, c.getPassword());
			pst.setString(7, c.getPhone());	
			pst.setObject(8, null);	
			pst.executeUpdate(); 

			SQL = "insert into TblCustomer (id,covid19Val,joinDate,cardNumber,city,zipCode,loadCust,street,bulidingNumber,departmentNumber) values (?,?,?,?,?,?,?,?,?,?) ";  
			pst = con.prepareStatement(SQL);  
			//set data into columns
			pst.setString(1, c.getId());
			pst.setBoolean(2,c.isCovid19Val());
			pst.setObject(3,c.getJoinDate());
			pst.setInt(4,c.getCard().getCardNumber());
			pst.setString(5,c.getAddress().getCity());
			pst.setString(6,c.getAddress().getZipCode());
			pst.setDouble(7,c.getLoadVal());
			pst.setString(8,c.getAddress().getStreet());
			pst.setInt(9,c.getAddress().getBuildingNumber());
			pst.setInt(10,c.getAddress().getDepartmentNumber());

			pst.executeUpdate(); 

		}  
		catch (SQLException e) {
			e.printStackTrace();
		}
	}

	
	
	
	/**
	 * Sql Method To Add Card To DB
	 * @param c
	 * @throws SQLException
	 */
	public static void addCard(Card c) throws SQLException {
		//connect to DB
		connectTo();
		String SQL = null;
		try {
			//sql statement to add data to DB

			SQL = "insert into TblCard (moneyAmount,cardDate) values (?,?)";
			pst = con.prepareStatement(SQL);  
			//set data into columns
			pst.setDouble(1, c.getMoneyAmount());
			pst.setObject(2, c.getJoinDate());
			pst.executeUpdate(); 
		}  
		catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Sql Method To Get Max Card Number
	 * @return
	 * @throws SQLException
	 */
	public static int getMaxCardNumber() throws SQLException {
		//connect to DB
		SQL.connectTo();
		//sql statement to get data from DB
		String sql ="select max(t.cardNumber) as max from TblCard as t";
		Statement stmt = null;
		try {
			stmt = SQL.con.createStatement();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		ResultSet rs = null;
		try {
			rs = stmt.executeQuery(sql);
		} catch (SQLException e1) {
			e1.printStackTrace();
		}

		int ret=0;
		while (rs.next()) {
			ret = rs.getInt("max");
		}
		return ret;
	}
	/**
	 * Sql Method To get csr employees from DB
	 */
	public static ArrayList<String> getEmployeesCSRToArrayList() {
		ArrayList<String> csrEmp = new ArrayList<String>();
		//connect to DB
		SQL.connectTo();
		//sql statement to add data to DB

		String sql ="select TblSystemUser.*,TblCsr.startWorkingDate from TblCsr inner join TblSystemUser on TblCsr.id=TblSystemUser.id";

		Statement stmt = null;
		try {
			stmt = SQL.con.createStatement();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		ResultSet rs = null;
		try {
			rs = stmt.executeQuery(sql);
		} catch (SQLException e1) {
			e1.printStackTrace();
		}

		// loop through the result set
		try {
			while (rs.next()) {
				String s = rs.getString("id")+"-"+rs.getString("firstName")+" "+rs.getString("lastName");
				csrEmp.add(s);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return csrEmp;
	}

	
	/**
	 * Sql Method That check if Admin User exist in db and return Admin User ID
	 * @param userName
	 * @return
	 * @throws SQLException
	 */
	public static String getAdminUser(String userName) throws SQLException {
		//connect to DB
		SQL.connectTo();
		String sql ="select t.* from TblAdminUser as t where t.userName="+userName;
		Statement stmt = null;
		try {
			stmt = SQL.con.createStatement();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		ResultSet rs = null;
		try {
			rs = stmt.executeQuery(sql);
		} catch (SQLException e1) {
			e1.printStackTrace();
		}

		String ret="";
		while (rs.next()) {
			ret = rs.getString("userName");
		}
		return ret;
	}
	
	/**
	 * Sql Method That check if Admin User exist in db and return Admin User ID
	 * @param userName
	 * @return
	 * @throws SQLException
	 */
	public static String getAdminPassword(String userName) throws SQLException {
		//connect to DB
		SQL.connectTo();
		String sql ="select t.* from TblAdminUser as t where t.userName="+userName;
		Statement stmt = null;
		try {
			stmt = SQL.con.createStatement();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		ResultSet rs = null;
		try {
			rs = stmt.executeQuery(sql);
		} catch (SQLException e1) {
			e1.printStackTrace();
		}

		String ret="";
		while (rs.next()) {
			ret = rs.getString("pass");
		}
		return ret;
	}

	/**
	 * Sql Method That get user's email
	 * @param userName
	 * @return
	 * @throws SQLException
	 */
	public static String getEmail(String userName) throws SQLException {
		//connect to DB
		SQL.connectTo();
		String sql ="select t.email from TblSystemUser as t where t.id="+userName ;
		Statement stmt = null;
		try {
			stmt = SQL.con.createStatement();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		ResultSet rs = null;
		try {
			rs = stmt.executeQuery(sql);
		} catch (SQLException e1) {
			e1.printStackTrace();
		}

		String ret="";
		while (rs.next()) {
			ret = rs.getString("email");
		}
		return ret;
	}
	
}



