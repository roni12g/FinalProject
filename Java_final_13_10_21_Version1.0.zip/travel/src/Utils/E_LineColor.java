package Utils;

/**
 * class that represent Line Colors In System  
 * @version 1.0 
 * @project - Final Project 2021  
 * @Date 07.09.2021
 */
public enum E_LineColor {
	//-------------------------------------------------------------Values---------------------------------------------------------------------
	
	Red,Green,Purple,Black,Yellow,Pink,White,Grey;
	
}
