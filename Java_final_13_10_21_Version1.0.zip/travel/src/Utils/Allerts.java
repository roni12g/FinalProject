package Utils;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
/**
 * class that represent Allerts In System  
 * @version 1.0 
 * @project - Final Project 2021  
 * @Date 07.09.2021
 */
public class Allerts {

	
	//************************************************************ Methods*********************************************************//

	/**
	 * Method that pop up error alert
	 * @param title
	 * @param content
	 */
	public static void errorAlert(String title,String content) {
		Alert alert = new Alert(AlertType.ERROR);
		alert.setTitle(title);
		alert.setHeaderText(null);
		alert.setContentText(content);
		alert.showAndWait();
	}
	
	/**
	 * Method that pop up information alert
	 * @param title
	 * @param content
	 */
	public static void infoAllert(String title,String content) {
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setTitle(title);
		alert.setHeaderText(null);
		alert.setContentText(content);
		alert.showAndWait();
	}

}
