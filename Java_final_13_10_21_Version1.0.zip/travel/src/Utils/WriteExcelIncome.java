package Utils;


import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import ExcelObjects.ExcelReportCustUse;
import ExcelObjects.ExcelReportIncome;
/**
 * class that represent  Excel Export File For Income In System  
 * @version 1.0 
 * @project - Final Project 2021  
 * @Date 07.09.2021
 */
public class WriteExcelIncome {
	
	//************************************************************ Methods*********************************************************//

	/**
	 * Method that write data to excel file
	 * @param excelFilePath
	 * @param res
	 */
	public void writeExcelFile(String excelFilePath,ArrayList<ExcelReportIncome> res) {
		//file header
		final String[] header= {"EnterExitId", "Id Number", "Stop IndexId", "Date" ,"Hour","Minute",
				"exit/Enter Value","Route Start Station","Route End Station","Train Number","Station Load Parameter"
				,"Covid19-Value","Train Direction","From City","To City","Current Station Name","Price Per Travel"};


		Workbook workbook = new XSSFWorkbook();
		// For .xls extension HSSF workbook can be created
		//workbook = new HSSFWorkbook();

		// Creating sheet with in the workbook
		Sheet sheet = workbook.createSheet("Search Results");
		/*Font and style For Header*/
		Font font = workbook.createFont();

		Row row = sheet.createRow(0);
		// Writing header to excel
		for(int i = 0; i < header.length; i++) {
			// each column 20 characters wide
			sheet.setColumnWidth(i, 20*256);
			Cell cell = row.createCell(i);
			cell.setCellValue(header[i]);
		}   
		// Header styling ends

		int rowNum = 1;

		for(ExcelReportIncome r : res) {
			// create new row and fill data in this row
			row = sheet.createRow(rowNum++);
			row.createCell(0).setCellValue(r.getCustEnterExitId());
			row.createCell(1).setCellValue(r.getId());
			row.createCell(2).setCellValue(r.getStopsInId());
			row.createCell(3).setCellValue(r.getExitEnterDate());
			row.createCell(4).setCellValue(r.getExitEnterHour());            
			row.createCell(5).setCellValue(r.getExitEnterMinute());            
			row.createCell(6).setCellValue(r.isExitEnter());            
			row.createCell(7).setCellValue(r.getStartStation());            
			row.createCell(8).setCellValue(r.getEndStation());            
			row.createCell(9).setCellValue(r.getTrainNumber());            
			row.createCell(10).setCellValue(r.getLoadParameter());            
			row.createCell(11).setCellValue(r.getStartStation());            
			row.createCell(12).setCellValue(r.getCovid19InOut());  
			row.createCell(13).setCellValue(r.getDirection());    	
			row.createCell(14).setCellValue(r.getFromCity());    	
			row.createCell(15).setCellValue(r.getToCity());    	
			row.createCell(16).setCellValue(r.getStationName()); 
			row.createCell(17).setCellValue(5.90);

		}

		FileOutputStream outputStream = null;
		try {
			outputStream = new FileOutputStream(excelFilePath);
			// Writing to excel sheet
			workbook.write(outputStream);
		} catch (IOException exp) {
			
			exp.printStackTrace();
		}finally {
			if(outputStream != null) {
				try {
					outputStream.close();
				} catch (IOException e) {
					
					e.printStackTrace();
				}
			}
		}   
	}
}
