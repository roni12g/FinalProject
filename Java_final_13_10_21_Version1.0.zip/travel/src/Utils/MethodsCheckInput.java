package Utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.regex.Pattern;
/**
 * class that represent Methods for input check   
 * @version 1.0 
 * @project - Final Project 2021  
 * @Date 07.09.2021
 */
public class MethodsCheckInput {
	
	//************************************************************ Methods*********************************************************//

	/**
	 * method to check valid name input
	 * @param number
	 * @return true/false
	 */
	public static boolean validateName( String name ){
		if(name.length()>30)
			return false;
		else return Pattern.matches( "[a-zA-Z]+", name );
	} 

	/**
	 * method to check valid year input
	 * @param year
	 * @return true/false
	 */
	@SuppressWarnings("deprecation")
	public static boolean validateyear( String year ){

		boolean yearCheck =  Pattern.matches( "[0-9]+", year );

		if(yearCheck) {
			if(Integer.parseInt(year)>=1900 && Integer.parseInt(year)<=new Date().getYear()+1900) {
				return true;
			}
			else
				return false;
		}

		return false;
	} 	


	/**
	 * method to check valid number input
	 * @param number
	 * @return true/false
	 */
	public static boolean validateNumber( String number ){
		if(number.length()>3 || number.length()==0)
			return false;
		else
			return Pattern.matches( "[0-9]"+ "+", number );
	} 

	/**
	 * method to check valid phone number input - 10 digits only
	 * @param phone
	 * @return
	 */
	public static boolean validatePhoneNumber( String phone ){
		return Pattern.matches("\\d{10}"+ "+", phone );
	} 

	/**
	 * method to check valid email input
	 * @param email
	 * @return true/false
	 */
	public static boolean validateEmail(String email) {
		final Pattern EMAIL_REGEX = Pattern.compile("[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?", Pattern.CASE_INSENSITIVE);
		return EMAIL_REGEX.matcher(email).matches();
	}

	/**
	 * method to check valid price amount input : double input only
	 * @param price
	 * @return true/false
	 */
	public static boolean validatePrice(String price) {
		final Pattern p = Pattern.compile("[0-9]"+"."+"[0-9]*");
		return p.matcher(price).matches();
	}


	/**
	 * check password is 8 digits/values at least
	 * @param str
	 * @return true/false
	 */
	public static boolean checkPassword(String str) {
		int counter=0;
		if(str.length()<8 || str.length()>30)
			return false;
		for(int i =0;i<str.length();i++) {
			if((str.charAt(i)>='0' && str.charAt(i)<='9') || (str.charAt(i)>='a' && str.charAt(i)<='z') || (str.charAt(i)>='A' && str.charAt(i)<='Z') 
					|| (str.charAt(i)=='!') || (str.charAt(i)=='?') || (str.charAt(i)=='@')){
				counter++;

			}
		}
		if(counter==str.length())
			return true;
		else
			return false;
	} 


	/**
	 * check if id is 10 digits 
	 * @param str
	 * @return true/false
	 */
	public static boolean checkId(String str) {
		int counter=0;
		if(str.length()!=9)
			return false;
		for(int i =0;i<str.length();i++) {
			if(str.charAt(i)>='0' && str.charAt(i)<='9'){
				counter++;
			}
		}
		if(counter==9)
			return true;
		else
			return false;
	} 


	/**
	 * Method that get month's last day (number)
	 * @param date
	 * @return true/false
	 * @throws ParseException
	 */
	public static String getLastDay(String date) throws ParseException {

		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd");
		Date convertedDate = dateFormat.parse(date);
		Calendar c = Calendar.getInstance();
		c.setTime(convertedDate);
		c.set(Calendar.DAY_OF_MONTH, c.getActualMaximum(Calendar.DAY_OF_MONTH));
		int i= c.getActualMaximum(Calendar.DAY_OF_MONTH)-1;
		
		if(i<10) {
			return "0"+String.valueOf(i);

		}
		
		return String.valueOf(i);
		
	}

	/**
	 * Method that get local date 
	 * @param dateString
	 * @return
	 */
	public static final LocalDate localDate (String dateString){
	    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
	    LocalDate localDate = LocalDate.parse(dateString, formatter);
	    return localDate;
	}


	
	/**
	 * method that check if zip code input id valid and contain only 5 digits
	 */
	public static boolean checkZipCode(String s) {
		if(s.length()!=5)
			return false;
		for(int i=0;i<s.length();i++) {
			if(s.charAt(i)<'0' || s.charAt(i)>'9') {
				return false;
			}
		}
		return true;
	}
	
	
}
