package Utils;


import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import ExcelObjects.ExcelReportCustSearches;
/**
 * class that represent  Excel Export File For Customer's Searches In System  
 * @version 1.0 
 * @project - Final Project 2021  
 * @Date 07.09.2021
 */
public class WriteExcelSearchCustData {
	
	//************************************************************ Methods*********************************************************//

	/**
	 * Method that write data to excel file
	 * @param excelFilePath
	 * @param res
	 */
	public void writeExcelFile(String excelFilePath,ArrayList<ExcelReportCustSearches> res) {
		//file header
		final String[] header= {"Id Number","Search Date", "Search Hour" ,"Search Minute","Source Station Name","Destination Station Name"
				,"Source City Name","Destination City Name","Covid19 Parameter","Load Parameter"};
		
		
		

		Workbook workbook = new XSSFWorkbook();
		// For .xls extension HSSF workbook can be created
		//workbook = new HSSFWorkbook();

		// Creating sheet with in the workbook
		Sheet sheet = workbook.createSheet("Search Results");
		/*Font and style For Header*/
		Font font = workbook.createFont();

		Row row = sheet.createRow(0);
		// Writing header to excel
		for(int i = 0; i < header.length; i++) {
			// each column 20 characters wide
			sheet.setColumnWidth(i, 20*256);
			Cell cell = row.createCell(i);
			cell.setCellValue(header[i]);
		}   
		// Header styling ends

		int rowNum = 1;

		for(ExcelReportCustSearches r : res) {
			// create new row and fill data in this row
			row = sheet.createRow(rowNum++);
			row.createCell(0).setCellValue(r.getId());
			row.createCell(1).setCellValue(r.getCustDate());
			row.createCell(2).setCellValue(r.getCustHour());
			row.createCell(3).setCellValue(r.getCustMinute());            
			row.createCell(4).setCellValue(r.getSourceStationName());            
			row.createCell(5).setCellValue(r.getDestStationName());            
			row.createCell(6).setCellValue(r.getSourceStationNameCity());            
			row.createCell(7).setCellValue(r.getDestinationStationNameCity());     
			row.createCell(8).setCellValue(r.getCovid());     
			row.createCell(9).setCellValue(r.getLoad());     
			
		     	
		}


		FileOutputStream outputStream = null;
		try {
			outputStream = new FileOutputStream(excelFilePath);
			// Writing to excel sheet
			workbook.write(outputStream);
		} catch (IOException exp) {
			// TODO Auto-generated catch block
			exp.printStackTrace();
		}finally {
			if(outputStream != null) {
				try {
					outputStream.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}   
	}
}
