package application;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.ResourceBundle;

import javax.swing.JOptionPane;

import org.apache.poi.hssf.record.formula.functions.If;

import Core.Csr;
import Core.Manager;
import Core.Travel;
import Utils.Allerts;
import Utils.MethodsCheckInput;
import Utils.SQL;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
/**
 * class that represent  Form For Adding Employee To System  Controller  
 * @version 1.0 
 * @project - Final Project 2021  
 * @Date 07.09.2021
 */
public class AddEmployeeController extends Application 	implements Initializable{

	//************************************************************Class Members*********************************************************//

	/**
	 * DB SingleTone Object
	 */
	public static  Travel travel= Main.getInstance();

	//************************************************************Java FX Components*********************************************************//

	@FXML
	private ImageView image;

	@FXML
	private AnchorPane anchore1;

	@FXML
	private AnchorPane anchore;

	@FXML
	private TextField txtIPassword;

	@FXML
	private TextField txtIDNumber;

	@FXML
	private ComboBox<String> comboTypeEmployee;

	@FXML
	private TextField txtLName;

	@FXML
	private TextField txtFName;

	@FXML
	private TextField txtUserName;

	@FXML
	private DatePicker bDatePicker;

	@FXML
	private TextField txtPhoneNumber;

	@FXML
	private Button applyBtn;

	@FXML
	private Button backBtn;

	//************************************************************Java FX Handlers*********************************************************//

	/**
	 * Apply Button Handler ->Add/Save/Modify Data In DB
	 * @param event
	 * @throws SQLException
	 */
	@FXML
	void ApplyHandler(ActionEvent event) throws SQLException {
		//check that combo boxes value selected isn't empty
		if(comboTypeEmployee.getValue()==null) {
			Allerts.errorAlert("Error Message","Combo Box Can't Be Empty, Try Again");
		}
		//check type of value is Finance Manager
		else if(comboTypeEmployee.getValue().equals("Finance Manager") || comboTypeEmployee.getValue().equals("Csr") ) {
			//check id number input
			if(!MethodsCheckInput.checkId(txtIDNumber.getText())) {
				Allerts.errorAlert("Error","ID Number Isn't Valid , Enter Only 9 Digits , Try Again");
				emptyAllFields();
			}
			//check password input
			else if(!MethodsCheckInput.checkPassword(txtIPassword.getText())) {
				Allerts.errorAlert("Error","Password Isn't Valid , Enter At Least 8 Digits/Characters , Try Again");
				emptyAllFields();	
			}
			//check first name input
			else if(!MethodsCheckInput.validateName(txtFName.getText())) {
				Allerts.errorAlert("Error","First Name Isn't Valid , Enter Only Characters , Try Again");
				emptyAllFields();	
			}

			//check last name input
			else if(!MethodsCheckInput.validateName(txtLName.getText())) {
				Allerts.errorAlert("Error","Last Name Isn't Valid , Enter Only Characters , Try Again");
				emptyAllFields();	
			}

			//check phone number input
			else if(!MethodsCheckInput.validatePhoneNumber(txtPhoneNumber.getText())) {
				Allerts.errorAlert("Error","Phone Number Isn't Valid , Enter Only 10 Digits , Try Again");
				emptyAllFields();	
			}
			else {
				//initialize all input fields to object
				String email = txtUserName.getText()+"@ItravelNta.co.il";
				LocalDate date = bDatePicker.getValue();
				ZoneId defaultZoneId = ZoneId.systemDefault();
				Date bDate = Date.from(date.atStartOfDay(defaultZoneId).toInstant());
		 		if(comboTypeEmployee.getValue().equals("Finance Manager")) {
					Manager m = new Manager(txtIDNumber.getText(), txtFName.getText(), txtLName.getText(), email,bDate, txtIPassword.getText(), txtPhoneNumber.getText(), new Date());
					//Add Item To DB
					if(Travel.addItem(travel.getManagers(),m.getId(),m)) {
						SQL.addManager(m);
						SQL.getEmployeesManagersFromDB();
						Allerts.infoAllert("Success Message", "Employee : "+m.getId()+" - "+m.getfName()+" "+m.getlName()+" Added To System");
						//empty input fields data
						txtFName.setText("");
						txtIDNumber.setText("");
						txtIPassword.setText("");
						txtLName.setText("");
						txtPhoneNumber.setText("");
						txtUserName.setText("");
					}
					else {
						//show error alert
						Allerts.errorAlert("Error Message","Employee : "+m.getId()+" Allready Exist In System , Try Again");
						//empty input fields data
						txtFName.setText("");
						txtIDNumber.setText("");
						txtIPassword.setText("");
						txtLName.setText("");
						txtPhoneNumber.setText("");
						txtUserName.setText("");
					}
				}
		 		
		 		else if(comboTypeEmployee.getValue().equals("Csr")) {
					Csr c = new Csr(txtIDNumber.getText(), txtFName.getText(), txtLName.getText(), email,bDate, txtIPassword.getText(), txtPhoneNumber.getText(), new Date());
					//Add Item To DB
					if(SQL.getCSR(txtIDNumber.getText()).equals("")) {
						SQL.addCsr(c);
						Allerts.infoAllert("Success", "Employee : "+c.getId()+" - "+c.getfName()+" "+c.getlName()+" Added To System");
						//empty input fields data
						txtFName.setText("");
						txtIDNumber.setText("");
						txtIPassword.setText("");
						txtLName.setText("");
						txtPhoneNumber.setText("");
						txtUserName.setText("");
					}
					else {
						//show error alert
						Allerts.errorAlert("Error Message","Employee : "+txtIDNumber.getText()+" Allready Exist In System , Try Again");
						//empty input fields data
						txtFName.setText("");
						txtIDNumber.setText("");
						txtIPassword.setText("");
						txtLName.setText("");
						txtPhoneNumber.setText("");
						txtUserName.setText("");
					}
				}
			}
		}
	}


	/**
	 * Back Button Handler
	 */
	@FXML
	void backHandler(ActionEvent event) throws IOException {
		//open admin menu form
		AnchorPane pane = FXMLLoader.load(getClass().getResource("AdminMenu.fxml"));
		anchore1.getChildren().setAll(pane);
	}

	/**
	 * Method To Initialize Data In Form
	 */
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		//initialize employee type combo box
		ObservableList<String> list = FXCollections.observableArrayList("Finance Manager","Csr");
		this.comboTypeEmployee.setItems(list);
		//image resource
		Image i = new Image(getClass().getResourceAsStream("/home.jpg"));
		this.image.setImage(i);
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
	}

	/**
	 * Method that empty input fields in form
	 */
	public void emptyAllFields() {
		txtFName.setText("");
		txtIDNumber.setText("");
		txtIPassword.setText("");
		txtLName.setText("");
		txtPhoneNumber.setText("");
		txtUserName.setText("");
	}
}
