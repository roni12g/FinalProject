package application;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

import Utils.Allerts;
import Utils.SQL;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
/**
 * class that represent Remove customer form -> Controller  
 * @version 1.0 
 * @project - Final Project 2021  
 * @Date 07.09.2021
 */
public class RemovCustController extends Application implements Initializable {
	//************************************************************Class Members*********************************************************//
	@FXML
	private AnchorPane anchore1;
	
	//************************************************************Java FX Components*********************************************************//

	@FXML
	private AnchorPane anchore;

	@FXML
	private ImageView image;

	@FXML
	private TextField txtID;

	@FXML
	private Button applyBtn;

	@FXML
	private Button backBtn;

	//************************************************************Java FX Handlers*********************************************************//
	/**
	 * Apply Button Handler ->Modify Data In DB
	 * @param event
	 * @throws SQLException
	 */
	@FXML
	void applyHandler(ActionEvent event) throws SQLException {
		//get data from txt field
		String s = this.txtID.getText();
		//get customer data from db
		String id = SQL.getCust(s);
		if(s.equals(id)) {
			//remove customer from db
			SQL.removeCustomer(id);
			//allert success
			Allerts.infoAllert("Success","Customer : "+id+" Deleted From DB");
			txtID.setText("");
		}
		else {//customer doesn't exist in db
			Allerts.errorAlert("Error","Customer : "+txtID.getText()+" Doesn't Exist In DB , Try Again");
			txtID.setText("");
		}
	}
	
 
	/**
	 * Back Button Handler
	 */
	@FXML
	void backHandler(ActionEvent event) throws IOException {
		//open new frame inside current stage -> Open CSR Main Menu
		AnchorPane pane = FXMLLoader.load(getClass().getResource("CsrMenu.fxml"));
		anchore1.getChildren().setAll(pane);
	}
	
	/**
	 * Method To Initialize Data In Form
	 */
	@Override
	public void initialize(URL location, ResourceBundle resources) {		
		//image resource
		Image i = new Image(getClass().getResourceAsStream("/home.jpg"));
		this.image.setImage(i);
	}

	@Override
	public void start(Stage primaryStage) throws Exception {		
	}

}
