package application;

import java.awt.Desktop;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
/**
 * class that represent  About Form Controller  
 * @version 1.0 
 * @project - Final Project 2021  
 * @Date 07.09.2021
 */
public class AboutController extends Application 	implements Initializable {
	//************************************************************Class Members*********************************************************//

	//************************************************************Java FX Components*********************************************************//

	@FXML
	private AnchorPane anchore1;

    @FXML
    private ImageView image;
    
	@FXML
	private AnchorPane anchore;

	@FXML
	private Button backBtn;

    @FXML
    private Hyperlink lnkBtn;
    
    @FXML
    private ImageView imageFB;

    @FXML
    private ImageView imageChrome;
    
	//************************************************************Java FX Handlers*********************************************************//
    /**
	 * Back Button Handler
	 */
	@FXML
	void backHandler(ActionEvent event) throws IOException {
		if(Main.typeOfUser==1) {//check type of menu to open
			//open new frame inside current stage -> Open Manager Main Menu
			AnchorPane pane = FXMLLoader.load(getClass().getResource("ManagerMenu.fxml"));
			anchore1.getChildren().setAll(pane);
		}

		if(Main.typeOfUser==0) {//check type of menu to open
			//open new frame inside current stage -> Open Admin Main Menu
			AnchorPane pane = FXMLLoader.load(getClass().getResource("AdminMenu.fxml"));
			anchore1.getChildren().setAll(pane);
		}
		
		if(Main.typeOfUser==2) {//check type of menu to open
			//open new frame inside current stage -> Open CSR Main Menu
			AnchorPane pane = FXMLLoader.load(getClass().getResource("CsrMenu.fxml"));
			anchore1.getChildren().setAll(pane);
		}
		
	}


	@Override
	public void start(Stage primaryStage) throws Exception {
	

	}

	/**
	 * Method To Initialize Data In Form
	 */
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		//image resource
		Image i = new Image(getClass().getResourceAsStream("/home.jpg"));
		this.image.setImage(i);
		Image k = new Image(getClass().getResourceAsStream("/fb.jpg"));
		this.imageFB.setImage(k);
		Image n = new Image(getClass().getResourceAsStream("/chrome.jpg"));
		this.imageChrome.setImage(n);
	}
	/**
	 * Method To Open Link In Web Page
	 * @param event
	 * @throws MalformedURLException
	 * @throws IOException
	 * @throws URISyntaxException
	 */
    @FXML
    void linkHandler(ActionEvent event) throws MalformedURLException, IOException, URISyntaxException {
        Desktop.getDesktop().browse(new URL("https://www.nta.co.il/lines").toURI());
    }
    
	/**
	 * Open FB Site -> System FB Web Site For System Customers And Potential Customers
	 * @param event
	 * @throws URISyntaxException 
	 * @throws IOException 
	 * @throws MalformedURLException 
	 */
    @FXML
    void fbHandler(MouseEvent event) throws MalformedURLException, IOException, URISyntaxException {
        Desktop.getDesktop().browse(new URL("https://www.facebook.com/NTAIsrael").toURI());
    }
    
    
    /**
	 * Open Web Site -> System Web Site For System Customers And Potential Customers
	 * @param event
	 * @throws URISyntaxException 
	 * @throws IOException 
	 * @throws MalformedURLException 
	 */
    @FXML
    void chromeHandler(MouseEvent event) throws MalformedURLException, IOException, URISyntaxException {
        Desktop.getDesktop().browse(new URL("http://62.90.44.179/travel/index.php").toURI());
    }

}
