package application;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.text.ParseException;
import java.time.LocalDate;
import java.util.Date;
import java.util.ResourceBundle;
import Utils.Constants;
import Utils.MethodsCheckInput;
import Utils.SQL;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

/**
 * class that represent Menu Form For DashBoard bar chart Controller  
 * @version 1.0 
 * @project - Final Project 2021  
 * @Date 07.09.2021
 */
public class DashBoardController  extends Application implements Initializable{

	//************************************************************Class Members*********************************************************//

	//************************************************************Java FX Components*********************************************************//

	@FXML
	private AnchorPane anchore1;

	@FXML
	private AnchorPane anchore;

	@FXML
	private ImageView image;

	@FXML
	private Button backBtn;

	@FXML
	private BarChart<String,Number> barChart;

	@FXML
	private CategoryAxis x;

	@FXML
	private NumberAxis y;

	@FXML
	private Button applyBtn;

	@FXML
	private DatePicker fromDate;

	@FXML
	private DatePicker toDate;

	@FXML
	private Label fromLabel;

	@FXML
	private Label toLabel;



	//************************************************************Java FX Handlers*********************************************************//

	/**
	 * Back Button Handler
	 * @param event
	 * @throws IOException
	 */
	@FXML
	void backHandler(ActionEvent event) throws IOException {
		this.barChart.getData().clear();
		if(Main.typeOfUser==0) {//check if user is admin
			//open new frame inside current stage
			AnchorPane pane = FXMLLoader.load(getClass().getResource("AdminMenu.fxml"));
			anchore.getChildren().setAll(pane);
		}
		else if(Main.typeOfUser==1) {//check if user is finance manager
			//open new frame inside current stage
			AnchorPane pane = FXMLLoader.load(getClass().getResource("ManagerMenu.fxml"));
			anchore.getChildren().setAll(pane);
		}
	}


	/**
	 * Method To Initialize Data In Form
	 */
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		//image resource
		Image i = new Image(getClass().getResourceAsStream("/home.jpg"));
		this.image.setImage(i);
		//get today date details
		Date d = new Date();
		int month = d.getMonth()+1;
		String m = "";
		if(month<10) {
			m="0"+String.valueOf(month);
		}
		else {
			m=String.valueOf(month);
		}
		int year = d.getYear()+1900;
		int firstDay =1;

		//set strings with current month details
		String date = String.valueOf(firstDay)+"-"+m+"-"+String.valueOf(year);
		String lastDay = null;
		try {
			lastDay = MethodsCheckInput.getLastDay(date);
		} catch (ParseException e2) {
			e2.printStackTrace();
		}
		int last = Integer.parseInt(lastDay);

		String from = "01-"+m+"-"+String.valueOf(year);
		String to = String.valueOf(last)+"-"+m+"-"+String.valueOf(year);

		LocalDate  fromD= MethodsCheckInput.localDate(from);
		this.fromDate.setValue(fromD);

		LocalDate  toD= MethodsCheckInput.localDate(to);
		this.toDate.setValue(toD);

		//dash board variable
		int numberOfCustomers=0;
		int numOfCustSearches=0;
		int numOfPotentialSearches=0;
		int redLineUses=0;
		int greenLineUses=0;
		int purpleLineUses=0;
		float income = 0;


		//count method to count number customers in db in current month
		try {
			numberOfCustomers = SQL.countCustInDBInThisMonth(new Date());
		} catch (ParseException e1) {
			e1.printStackTrace();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}

		//count method to count number of new customers searches in db in current month
		try {
			numOfCustSearches = SQL.countCustSearchesInDBInThisMonth(new Date());
		} catch (ParseException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		//count method to count number of random customers searches in db in current month
		try {
			numOfPotentialSearches = SQL.countPotentialCustomersSearchesInDBInThisMonth(new Date());
		} catch (ParseException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		//count number of travels in red line
		try {
			redLineUses = SQL.countXLineUsesInDBInThisMonth(new Date(),"Red");
		} catch (ParseException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		//count number of travels in green line

		try {
			greenLineUses = SQL.countXLineUsesInDBInThisMonth(new Date(),"Green");
		} catch (ParseException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		//count number of travels in purple line

		try {
			purpleLineUses = SQL.countXLineUsesInDBInThisMonth(new Date(),"Purple");
		} catch (ParseException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		//income calculator
		income = (redLineUses+greenLineUses+purpleLineUses)*Constants.pricePerTravel;

		XYChart.Series<String,Number> series1 = new XYChart.Series<>();
		XYChart.Series<String,Number> series2 = new XYChart.Series<>();
		XYChart.Series<String,Number> series3 = new XYChart.Series<>();

		//add date to bar chart
		series1.setName(month+"-"+year+" Statistics");
		series1.getData().add(new XYChart.Data<>("New Customers",numberOfCustomers));
		series1.getData().add(new XYChart.Data<>("Income",income));

		series2.setName(month+"-"+year+" Search Statistics");
		series2.getData().add(new XYChart.Data<>("Customers",numOfCustSearches));
		series2.getData().add(new XYChart.Data<>("Random",numOfPotentialSearches));

		series3.setName(month+"-"+year+" Lines Uses");		
		series3.getData().add(new XYChart.Data<>("Red",redLineUses));
		series3.getData().add(new XYChart.Data<>("Green",greenLineUses));
		series3.getData().add(new XYChart.Data<>("Purple",purpleLineUses));
		//set data to bar chart in form
		barChart.getData().add(series1);
		barChart.getData().add(series2);
		barChart.getData().add(series3);
		barChart.setBarGap(-30);


	}

	@FXML
	void applyHandler(ActionEvent event) {
		//clear data in bar chart
		this.barChart.getData().clear();
		LocalDate fromDate = this.fromDate.getValue();
		LocalDate toDate = this.toDate.getValue();

		//compute dates for variables sql queries
		String fromDay = String.valueOf(fromDate.getDayOfMonth());
		if(fromDay.length()<2)
			fromDay = "0"+fromDay;
		String fromMonth = String.valueOf(fromDate.getMonthValue());
		if(fromMonth.length()<2)
			fromMonth = "0"+fromMonth;
		String fromYear = String.valueOf(fromDate.getYear());

		String toDay = String.valueOf(toDate.getDayOfMonth());
		if(toDay.length()<2)
			toDay = "0"+toDay;

		String toMonth = String.valueOf(toDate.getMonthValue());
		if(toMonth.length()<2)
			toMonth = "0"+toMonth;
		String toYear = String.valueOf(toDate.getYear());

		String from = fromYear+"-"+fromMonth+"-"+fromDay;
		String to = toYear+"-"+toMonth+"-"+toDay;

		System.out.println(from);
		System.out.println(to);
		
		//dash board variable
		int numberOfCustomers=0;
		int numOfCustSearches=0;
		int numOfPotentialSearches=0;
		int redLineUses=0;
		int greenLineUses=0;
		int purpleLineUses=0;
		float income = 0;


		//count method to count number customers in db in current month
		try {
			numberOfCustomers = SQL.countCustInDBInThisMonth(from,to);
		} catch (ParseException e1) {
			e1.printStackTrace();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}

		//count method to count number of new customers searches in db in current month
		try {
			numOfCustSearches = SQL.countCustSearchesInDBInThisMonth(from,to);
		} catch (ParseException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		//count method to count number of random customers searches in db in current month
		try {
			numOfPotentialSearches = SQL.countPotentialCustomersSearchesInDBInThisMonth(from,to);
		} catch (ParseException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		//count number of travels in red line
		try {
			redLineUses = SQL.countXLineUsesInDBInThisMonth(from,to,"Red");
		} catch (ParseException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		//count number of travels in green line

		try {
			greenLineUses = SQL.countXLineUsesInDBInThisMonth(from,to,"Green");
		} catch (ParseException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		//count number of travels in purple line

		try {
			purpleLineUses = SQL.countXLineUsesInDBInThisMonth(from,to,"Purple");
		} catch (ParseException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		//income calculator
		income = (redLineUses+greenLineUses+purpleLineUses)*Constants.pricePerTravel;

		System.out.println(income);

		XYChart.Series<String,Number> series1 = new XYChart.Series<>();
		XYChart.Series<String,Number> series2 = new XYChart.Series<>();
		XYChart.Series<String,Number> series3 = new XYChart.Series<>();

		//add date to bar chart
		series1.setName(fromMonth+"-"+fromYear+" Statistics");
		series1.getData().add(new XYChart.Data<>("New Customers",numberOfCustomers));

		series1.getData().add(new XYChart.Data<>("Income",income));

		series2.setName(fromMonth+"-"+fromYear+" Search Statistics");
		series2.getData().add(new XYChart.Data<>("Customers",numOfCustSearches));
		series2.getData().add(new XYChart.Data<>("Random",numOfPotentialSearches));

		series3.setName(fromMonth+"-"+fromYear+" Lines Uses");		
		series3.getData().add(new XYChart.Data<>("Red",redLineUses));
		series3.getData().add(new XYChart.Data<>("Green",greenLineUses));
		series3.getData().add(new XYChart.Data<>("Purple",purpleLineUses));
		//set data to bar chart in form
		barChart.getData().add(series1);
		barChart.getData().add(series2);
		barChart.getData().add(series3);
		barChart.setBarGap(-30);


	}

	@Override
	public void start(Stage primaryStage) throws Exception {
	}

}
