package application;

import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Date;
import java.util.ResourceBundle;

import org.apache.poi.util.SystemOutLogger;

import Core.Csr;
import Core.Manager;
import Core.Travel;
import Utils.Allerts;
import Utils.MethodsCheckInput;
import Utils.SQL;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
/**
 * class that represent Login Menu Form For Logging In System -> Controller  
 * @version 1.0 
 * @project - Final Project 2021  
 * @Date 07.09.2021
 */
public class LoginController extends Application implements Initializable{

	//************************************************************Class Members*********************************************************//

	/**
	 * Admin User Name Varaible
	 */
	public static String userAdmin = "";

	/**
	 * Admin Password Variable
	 */
	public static String passwordAdmin = "";
	
	/**
	 * DB SingleTone Object
	 */
	public static  Travel travel= Main.getInstance();
	
	/**
	 * Manager Data Object Variable
	 */
	public static Manager m;
	
	/**
	 * CSR Data Object Variable
	 */
	public static Csr c;

	//************************************************************Java FX Components*********************************************************//

	@FXML
	private AnchorPane anchore1;

	@FXML
	private AnchorPane anchore;

	@FXML
	private TextField txtUserName;

	@FXML
	private PasswordField txtPassword;

	@FXML
	private ComboBox<String> comboTypeEmployee;

	@FXML
	private Button loginBtn;

	@FXML
	private Button exitBtn;

	@FXML
	private Label lavelShowPassword;

	@FXML
	private CheckBox checkBoxShowPassword;

	@FXML
	private ImageView image;

    @FXML
    private Label label;

    @FXML
    private DatePicker dateToday;
    
    @FXML
    private Label label1;

	//************************************************************Java FX Handlers*********************************************************//

	/**
	 * Method that show writen password on screen
	 * @param event
	 */
	@FXML
	void checkBoxShowPasswordHandler(ActionEvent event) {
		if(checkBoxShowPassword.isSelected()) {
			this.lavelShowPassword.setText("\t"+txtPassword.getText());
		}
		else if (!checkBoxShowPassword.isSelected()) {
			this.lavelShowPassword.setText("");
		}
	}

	/**
	 * Method To Initialize Data In Form
	 */
	@Override
	public void initialize(URL location, ResourceBundle resources) {

		ObservableList<String> list = FXCollections.observableArrayList("IT User","Finance Manager","Csr");
		//initialize combo box -> type of employee
		this.comboTypeEmployee.setItems(list);
		this.lavelShowPassword.setText("");
		//image resource
		Image i = new Image(getClass().getResourceAsStream("/home.jpg"));
		this.image.setImage(i);

		//set time and date parameter to date picker

		String day = String.valueOf(new Date().getDate());
		String month = String.valueOf(new Date().getMonth()+1);
		String year = String.valueOf(new Date().getYear()+1900);
		if(day.length()<2)
			day = "0"+day;
		if(month.length()<2)
			month = "0"+month;
		
		LocalDate l = MethodsCheckInput.localDate(day+"-"+month+"-"+year);
		this.dateToday.setValue(l);
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
	}

	/**
	 * Method to login to system
	 * @param event
	 * @throws SQLException 
	 */
	@FXML
	void loginHandler(ActionEvent event) throws SQLException {
		this.dateToday.setVisible(false);
		this.label1.setVisible(false);
		int flg=0;
		//check that combo box isn't empty
		if(this.comboTypeEmployee.getValue()==null) {
			Alert alert = new Alert(AlertType.ERROR);
			//alert
			alert.setTitle("Please Choose Employee Type");
			alert.setHeaderText(null);
			alert.setContentText("Please Choose Employee Type");
			alert.showAndWait();
			//empty input fields
			txtPassword.setText("");
			txtUserName.setText("");
			//flag = input invalid
			flg=1;
		}

		if(flg==0) { //input valid
			String user = this.txtUserName.getText();
			//check type of employee selected in combo box -> IT User
			if(this.comboTypeEmployee.getValue().equals("IT User")) {
				String userAdmin = SQL.getAdminUser(txtUserName.getText());
				System.out.println(userAdmin);
				String userPassword = SQL.getAdminPassword(txtUserName.getText());
				//check if input user and password are correct
				if(Integer.parseInt(txtUserName.getText())==Integer.parseInt(userAdmin) && this.txtPassword.getText().equals(userPassword)) {
					try {
						//update type of user
						Main.typeOfUser=0;
						this.userAdmin = txtUserName.getText();
						this.passwordAdmin = txtPassword.getText();
						//open new frame inside current stage
						AnchorPane pane = FXMLLoader.load(getClass().getResource("AdminMenu.fxml"));
						anchore1.getChildren().setAll(pane);

					} catch (Exception e) {
						System.out.println("Can't Load New Window");
					}
				}

				else {
					//wrong input data -> password or user name incorrect
					Allerts.errorAlert("Error","Wrong User Name Or Password , Try Again");
					txtPassword.setText("");
					txtUserName.setText("");

				}
			}


			//check type of employee selected in combo box -> Finance Manager
			else if(this.comboTypeEmployee.getValue().equals("Finance Manager")) {
				//get date of manager from db
				Manager m = travel.getManagers().get(user);
				LoginController.m=m;
				if(m!=null) {//manager not xisting in db
					if(this.txtUserName.getText().equals(m.getId()) && this.txtPassword.getText().equals(m.getPassword())){ 
						try {
							//update next window parameter
							Main.typeOfUser=1;
							//open new frame inside current stage
							AnchorPane pane = FXMLLoader.load(getClass().getResource("ManagerMenu.fxml"));
							anchore.getChildren().setAll(pane);

						} catch (Exception e) {
							System.out.println("Can't Load New Window");
						}
					}
					else {//alert wrong input data of username or password
						Allerts.errorAlert("Error","Wrong User Name Or Password , Try Again");
						txtPassword.setText("");
						txtUserName.setText("");
					}
				}
				else {//alert wrong input data of username or password
					Allerts.errorAlert("Error","Wrong User Name Or Password , Try Again");
					txtPassword.setText("");
					txtUserName.setText("");
					checkBoxShowPassword.setText("");

				}
			}
			
			
			//check type of employee selected in combo box -> CSR
			else if(this.comboTypeEmployee.getValue().equals("Csr")) {
				//get date of csr from db
				Csr c = travel.getCsr().get(user);
				LoginController.c=c;
				if(c!=null) {//csr not xisting in db
					if(this.txtUserName.getText().equals(c.getId()) && this.txtPassword.getText().equals(c.getPassword())){ 
						try {
							//update next window parameter
							Main.typeOfUser=2;
							//open new frame inside current stage
							AnchorPane pane = FXMLLoader.load(getClass().getResource("CsrMenu.fxml"));
							anchore.getChildren().setAll(pane);

						} catch (Exception e) {
							System.out.println("Can't Load New Window");
						}
					}
					else {//alert wrong input data of username or password
						Allerts.errorAlert("Error","Wrong User Name Or Password , Try Again");
						txtPassword.setText("");
						txtUserName.setText("");
					}
				}
				else {//alert wrong input data of username or password
					Allerts.errorAlert("Error","Wrong User Name Or Password , Try Again");
					txtPassword.setText("");
					txtUserName.setText("");

				}
			}
		}
	}

	/**
	 * Method to exit system
	 * @param event
	 */
	@FXML
	void exitHandler(ActionEvent event) {
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setTitle("Bye Bye");
		alert.setHeaderText(null);
		alert.setContentText("Bye Bye , See You Again");
		alert.showAndWait();
		System.exit(0);

	}
	/**
	 * Method to retrieve Password
	 * @param event
	 */
	@FXML
	void retrievePasswordHandler(ActionEvent event) {
		try {
			Main.typeOfUser=-1;//update type of user parameter
			//open new frame inside current stage
			AnchorPane pane = FXMLLoader.load(getClass().getResource("RetrievePassword.fxml"));
			anchore1.getChildren().setAll(pane);

		} catch (Exception e) {
			System.out.println("Can't Load New Window");
		}
	}

}