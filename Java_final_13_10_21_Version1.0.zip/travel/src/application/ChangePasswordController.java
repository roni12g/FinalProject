package application;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

import javax.swing.JOptionPane;

import Core.Travel;
import Utils.Allerts;
import Utils.MethodsCheckInput;
import Utils.SQL;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

/**
 * class that represent Menu Form For Change Password Controller  
 * @version 1.0 
 * @project - Final Project 2021  
 * @Date 07.09.2021
 */
public class ChangePasswordController extends Application implements Initializable {

	//************************************************************Class Members*********************************************************//
	/**
	 * DB SingleTone Object
	 */
	public static  Travel travel= Main.getInstance();

	//************************************************************Java FX Components*********************************************************//


	@FXML
	private ImageView image;

	@FXML
	private AnchorPane anchore1;

	@FXML
	private AnchorPane anchore;

	@FXML
	private PasswordField txtNewPassword;

	@FXML
	private PasswordField txtNewPasswordRepeat;

	@FXML
	private PasswordField txtOldPassword;

	@FXML
	private CheckBox checkBoxShowAllPasswords;

	@FXML
	private Button applyBtn;

	@FXML
	private Button backBtn;

	@FXML
	private Label labelOldPass;

	@FXML
	private Label labelNewPass;

	@FXML
	private Label labelNewPassRepeat;

	//************************************************************Java FX Handlers*********************************************************//
	/**
	 * Apply Button Handler ->Add/Save/Modify Data In DB
	 * @param event
	 * @throws SQLException
	 */
	@FXML
	void ApplyHandler(ActionEvent event) throws IOException {
		if(Main.typeOfUser==0) {
			//old password data from db
			String oldP = LoginController.passwordAdmin;
			//check if old password correct
			if(!oldP.equals(txtOldPassword.getText())) {
				//alert -> wrong old password input
				Allerts.errorAlert("Error", "Old Password Incorrect , Try Again ");
				//empty input fields
				txtNewPassword.setText("");
				txtNewPasswordRepeat.setText("");
				checkBoxShowAllPasswords.setText("");
				txtOldPassword.setText("");
			}
			else {
				//cehck if new passwords are same and if the old password is correct ->wrong input
				if(!txtNewPassword.getText().equals("") &&!txtOldPassword.getText().equals("") && !txtNewPasswordRepeat.getText().equals("")
						&& txtOldPassword.getText().equals(oldP) && txtNewPassword.getText().equals(txtNewPasswordRepeat.getText())) {
					if(!MethodsCheckInput.checkPassword(txtNewPassword.getText())) {
						Allerts.errorAlert("Error","Password Isn't Valid , Enter At Least 8 Digits/Characters , Try Again");
						txtNewPassword.setText("");
						txtNewPasswordRepeat.setText("");
						txtOldPassword.setText("");
					}
					else {//cehck if new passwords are same and if the old password is correct ->correct input
						if(txtNewPassword.getText().length()>7 && txtNewPasswordRepeat.getText().length()>7 ) {
							//change password in db
							SQL.changeAdminPassword(LoginController.userAdmin,txtNewPassword.getText());
							//alert
							Allerts.infoAllert("Success Message","Admin User's  : "+LoginController.userAdmin +" Password Has Been Changed, Please Login Again");
							//return to previous form
							AnchorPane pane = FXMLLoader.load(getClass().getResource("LoginMenu.fxml"));
							anchore.getChildren().setAll(pane);
						}
						else {
							//wrong input for password 
							Allerts.errorAlert("Error", "Password Has To Be 8 Charachters And More");
							//empty input fields
							txtNewPassword.setText("");
							txtNewPasswordRepeat.setText("");
							checkBoxShowAllPasswords.setText("");
							txtOldPassword.setText("");
						}
					}
				}

			}
		}
		if(Main.typeOfUser==1) {
			//old password data from db
			String oldP = LoginController.m.getPassword();
			//check if old password correct
			if(!oldP.equals(txtOldPassword.getText())) {
				//alert -> wrong old password input
				Allerts.errorAlert("Error", "Old Password Incorrect , Try Again ");
				//empty input fields
				txtNewPassword.setText("");
				txtNewPasswordRepeat.setText("");
				checkBoxShowAllPasswords.setText("");
				txtOldPassword.setText("");
			}
			else {
				//cehck if new passwords are same and if the old password is correct ->wrong input
				if(!txtNewPassword.getText().equals("") &&!txtOldPassword.getText().equals("") && !txtNewPasswordRepeat.getText().equals("")
						&& txtOldPassword.getText().equals(oldP) && txtNewPassword.getText().equals(txtNewPasswordRepeat.getText())) {
					if(!MethodsCheckInput.checkPassword(txtNewPassword.getText())) {
						Allerts.errorAlert("Error","Password Isn't Valid , Enter At Least 8 Digits/Characters , Try Again");
						txtNewPassword.setText("");
						txtNewPasswordRepeat.setText("");
						txtOldPassword.setText("");
					}
					else {//cehck if new passwords are same and if the old password is correct ->correct input
						if(txtNewPassword.getText().length()>7 && txtNewPasswordRepeat.getText().length()>7 ) {
							//change password in db
							SQL.changePassword(LoginController.m.getId(), txtNewPassword.getText());
							travel.getManagers().get(LoginController.m.getId()).setPassword(txtNewPassword.getText());
							//alert
							Allerts.infoAllert("Success Message","Finanec Manager's  : "+LoginController.m.getId() +" Password Has Been Changed, Please Login Again");
							//return to previous form
							AnchorPane pane = FXMLLoader.load(getClass().getResource("LoginMenu.fxml"));
							anchore.getChildren().setAll(pane);
						}
						else {
							//wrong input for password 
							Allerts.errorAlert("Error", "Password Has To Be 8 Charachters And More");
							//empty input fields
							txtNewPassword.setText("");
							txtNewPasswordRepeat.setText("");
							checkBoxShowAllPasswords.setText("");
							txtOldPassword.setText("");
						}
					}
				}
			}
		}
		else if(Main.typeOfUser==2) {
			//old password data from db
			String oldP = LoginController.c.getPassword();
			//check if old password correct
			if(!oldP.equals(txtOldPassword.getText())) {
				//alert -> wrong old password input
				Allerts.errorAlert("Error", "Old Password Incorrect , Try Again ");
				//empty input fields
				txtNewPassword.setText("");
				txtNewPasswordRepeat.setText("");
				checkBoxShowAllPasswords.setText("");
				txtOldPassword.setText("");
			}
			else {
				//cehck if new passwords are same and if the old password is correct ->wrong input
				if(!txtNewPassword.getText().equals("") &&!txtOldPassword.getText().equals("") && !txtNewPasswordRepeat.getText().equals("")
						&& txtOldPassword.getText().equals(oldP) && txtNewPassword.getText().equals(txtNewPasswordRepeat.getText())) {
					if(!MethodsCheckInput.checkPassword(txtNewPassword.getText())) {
						Allerts.errorAlert("Error","Password Isn't Valid , Enter At Least 8 Digits/Characters , Try Again");
						txtNewPassword.setText("");
						txtNewPasswordRepeat.setText("");
						txtOldPassword.setText("");
					}
					else {//cehck if new passwords are same and if the old password is correct ->correct input
						if(txtNewPassword.getText().length()>7 && txtNewPasswordRepeat.getText().length()>7 ) {
							//change password in db
							SQL.changePassword(LoginController.c.getId(), txtNewPassword.getText());
							travel.getCsr().get(LoginController.c.getId()).setPassword(txtNewPassword.getText());
							//alert
							Allerts.infoAllert("Success Message","Csr : "+LoginController.c.getId() +" Password Has Been Changed, Please Login Again");
							//return to previous form
							AnchorPane pane = FXMLLoader.load(getClass().getResource("LoginMenu.fxml"));
							anchore.getChildren().setAll(pane);
						}
						else {
							//wrong input for password 
							Allerts.errorAlert("Error", "Password Has To Be 8 Charachters And More");
							//empty input fields
							txtNewPassword.setText("");
							txtNewPasswordRepeat.setText("");
							checkBoxShowAllPasswords.setText("");
							txtOldPassword.setText("");
						}
					}
				}
				else {
					//alert -> wrong old password input
					Allerts.errorAlert("Error", "Old Password Incorrect , Try Again ");
					//empty input fields
					txtNewPassword.setText("");
					txtOldPassword.setText("");
					txtNewPasswordRepeat.setText("");
				}
			}
		}
	}

	/**
	 * Method that show all passwords entered by user
	 * @param event
	 */
	@FXML
	void checkBoxHandler(ActionEvent event) {
		//check box selected ->show passwords on screen
		if(this.checkBoxShowAllPasswords.isSelected()) {
			String oldP = this.txtOldPassword.getText();
			String newP = this.txtNewPassword.getText();
			String newPRepeat = this.txtNewPasswordRepeat.getText();
			this.labelOldPass.setText("\t"+oldP);
			this.labelNewPass.setText("\t"+newP);
			this.labelNewPassRepeat.setText("\t"+newPRepeat);
		}
		//empty input fields
		else {
			this.labelOldPass.setText("");
			this.labelNewPass.setText("");
			this.labelNewPassRepeat.setText("");
		}
	}

	/**
	 * Back Button Handler
	 */
	@FXML
	void backHandler(ActionEvent event) throws IOException {
		
		if(Main.typeOfUser==0) {//check type of menu to open
			Main.typeOfUser=0;
			//open new frame inside current stage -> return to previous form
			AnchorPane pane = FXMLLoader.load(getClass().getResource("AdminMenu.fxml"));
			anchore.getChildren().setAll(pane);
		}
		
		else if(Main.typeOfUser==1) {//check type of menu to open
			Main.typeOfUser=1;
			//open new frame inside current stage -> return to previous form
			AnchorPane pane = FXMLLoader.load(getClass().getResource("ManagerMenu.fxml"));
			anchore.getChildren().setAll(pane);
		}

		else if(Main.typeOfUser==2) {//check type of menu to open
			Main.typeOfUser=2;
			//open new frame inside current stage -> return to previous form
			AnchorPane pane = FXMLLoader.load(getClass().getResource("CsrMenu.fxml"));
			anchore.getChildren().setAll(pane);
		}
	}

	/**
	 * Method To Initialize Data In Form
	 */
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		//image resource
		Image i = new Image(getClass().getResourceAsStream("/home.jpg"));
		this.image.setImage(i);
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
	}


}
