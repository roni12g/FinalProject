package application;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javax.swing.JOptionPane;
import Core.Line;
import Core.Travel;
import Utils.Allerts;
import Utils.E_LineColor;
import Utils.MethodsCheckInput;
import Utils.SQL;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
/**
 * class that represent  Form For Adding Line To System  Controller  
 * @version 1.0 
 * @project - Final Project 2021  
 * @Date 07.09.2021
 */
public class AddLineController extends Application implements Initializable{

	//************************************************************Class Members*********************************************************//
	/**
	 * DB SingleTone Object
	 */
	public static  Travel travel= Main.getInstance();

	//************************************************************Java FX Components*********************************************************//

	@FXML
	private AnchorPane anchore1;

	@FXML
	private ImageView image;

	@FXML
	private AnchorPane anchore;

	@FXML
	private ComboBox<String> comboColor;

	@FXML
	private TextField txtLStationsNumber;

	@FXML
	private Button backBtn;

	@FXML
	private Button applyBtn;

	//************************************************************Java FX Handlers*********************************************************//

	/**
	 * Apply Button Handler ->Add/Save/Modify Data In DB
	 * @param event
	 * @throws SQLException
	 */
	@FXML
	void applyHandler(ActionEvent event) throws SQLException {

		//check input -> number for stations sum
		if(!MethodsCheckInput.validateNumber(txtLStationsNumber.getText())) {
			//wrong input ->alert
			Allerts.errorAlert("Error","Stations Number Isn't Valid , Enter Only Numbers , Try Again");
			txtLStationsNumber.setText("");
		}

		else {
			//create line object
			Line l = new Line(E_LineColor.valueOf(comboColor.getValue()),Integer.valueOf(txtLStationsNumber.getText()));
			//check if object exist in db
			if(!travel.getLines().contains(l)) {
				//add new line to db
				travel.getLines().add(l);
				//add new line to SQL DB
				SQL.addLine(l);
				//update db with new line
				SQL.getLines();
				//success alert
				Allerts.infoAllert("Success", "Line  : "+l.getColor().toString()+" Added To System");
				txtLStationsNumber.setText("");

			}
			else {
				//line exist in db - error alert
				Allerts.errorAlert("Error","Line "+comboColor.getValue()+" Allready Exist In System , Try Again");
				txtLStationsNumber.setText("");
			}
		}
	}
	
	/**
	 * Method To Initialize Data In Form
	 */
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
	
		ArrayList<String> colors = new ArrayList<String>();
		//add line colors options to arraylist
		for(E_LineColor e : E_LineColor.values()) {
			colors.add(e.toString());
		}
		ObservableList<String> list = FXCollections.observableArrayList(colors);
		//all data of line colors to combo box
		this.comboColor.setItems(list);
		//image resource
		Image i = new Image(getClass().getResourceAsStream("/home.jpg"));
		this.image.setImage(i);
	}

    /**
	 * Back Button Handler
	 */
	@FXML
	void backHandler(ActionEvent event) throws IOException {
		//return to admin menu form
		AnchorPane pane = FXMLLoader.load(getClass().getResource("AdminMenu.fxml"));
		anchore1.getChildren().setAll(pane);
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
	}

}
