package application;
	
import java.io.IOException;
import java.text.ParseException;

import Core.Travel;
import Utils.SQL;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;

/**
 * Main class ->Run the System   
 * @version 1.0 
 * @project - Final Project 2021  
 * @Date 07.09.2021
 */
public class Main extends Application {

	//************************************************************Class Members*********************************************************//
	/**
	 * DB SingleTone Object
	 */
	public static  Travel travel= Main.getInstance();
	
	/**
	 * Stage Variable
	 */
	private Stage primaryStage;

	/**
	 * Anchor pane Variable
	 */
	private AnchorPane rootLayout;

	/**
	 * Type of User variable:
	 *  -1-> Login 				
	 *   0-> for Admin				
	 *   1-> for Employee
	 */
	public static int typeOfUser = -1;
	
	/**
	 * Singleton pattern that create singleton object(only one pattern exists in system)
	 * @return travel
	 */
	public static Travel getInstance() {
		if(travel == null)
			//create new instance
			travel = new Core.Travel();

		//instance already exists 
		return travel; 
	}

	//************************************************************Java FX Handlers*********************************************************//

	/**
	 * start method to open stage of login frame
	 */
	@Override
	public void start(Stage primaryStage) {
		try {
			BorderPane root = new BorderPane();
			Scene scene = new Scene(root,800,600);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.show();

			this.primaryStage = primaryStage;
			//set title for window
			primaryStage.setTitle("I-Travel System");
			initRootLayout();

		} catch(Exception e) {
			e.printStackTrace();
		}
	}


	public void initRootLayout() {
		try {
			// Load root layout from fxml file.
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(Main.class.getResource("LoginMenu.fxml"));
			rootLayout = (AnchorPane) loader.load();
			// Show the scene containing the root layout.
			Scene scene = new Scene(rootLayout);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.setResizable(false);
			primaryStage.show();
			
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Main Method to run system
	 * @param args
	 * @throws IOException
	 * @throws ParseException
	 */
	public static void main(String[] args) throws IOException, ParseException {
		//get data from sql server
		SQL.getEmployeesManagersFromDB();
		SQL.getEmployeesCSRFromDB();
		SQL.getLines();
		SQL.getStations();
//		SQL.getTblAddressesToDB();
//		SQL.getTblStopsInToDB();
//		SQL.getTblRouteToDB();
//		SQL.getTblCardsToDB();
//		SQL.getTblSystemUserToDB();
//		SQL.getTblCustomerToDB();
//		SQL.getTblCustomersExitEnterToDB();
		launch(args);
	}
}
