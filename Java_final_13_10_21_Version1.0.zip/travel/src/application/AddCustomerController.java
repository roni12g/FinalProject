package application;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.ResourceBundle;
import Core.Address;
import Core.Card;
import Core.Customer;
import Utils.Allerts;
import Utils.MethodsCheckInput;
import Utils.SQL;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
/**
 * class that represent  Add Customer Form Controller  
 * @version 1.0 
 * @project - Final Project 2021  
 * @Date 07.09.2021
 */
public class AddCustomerController  extends Application implements Initializable{
	//************************************************************Class Members*********************************************************//

	//************************************************************Java FX Components*********************************************************//
	@FXML
	private AnchorPane anchore1;

	@FXML
	private AnchorPane anchore;

	@FXML
	private TextField txtBuilding;

	@FXML
	private TextField txtIPassword;

	@FXML
	private ImageView image;

	@FXML
	private TextField txtIDNumber;

	@FXML
	private TextField txtLName;

	@FXML
	private TextField txtFName;

	@FXML
	private TextField txtEmail;

	@FXML
	private DatePicker bDatePicker;

	@FXML
	private TextField txtPhoneNumber;

	@FXML
	private Button backBtn;

	@FXML
	private Button applyBtn;

	@FXML
	private TextField txtCity;

	@FXML
	private TextField txtStreet;

	@FXML
	private TextField txtZipCode;

	@FXML
	private TextField txtAppartment;

	@FXML
	private ComboBox<String> comboLoad;

	@FXML
	private ComboBox<String> comboCovid;

	//************************************************************Java FX Handlers*********************************************************//

	/**
	 * Apply Button Handler ->Add/Save/Modify Data In DB
	 * @param event
	 * @throws SQLException
	 * @throws IOException
	 */
	@FXML
	void ApplyHandler(ActionEvent event) throws SQLException, IOException {
		int flg=0;
		//check that combo boxes value selected isn't empty
		if(comboCovid.getValue()==null || comboLoad.getValue()==null){
			Allerts.errorAlert("Error Message","Combo Box Can't Be Empty, Try Again");
			flg=1;
		}

		//check id number input
		else if(!MethodsCheckInput.checkId(txtIDNumber.getText())) {
			Allerts.errorAlert("Error","ID Number Isn't Valid , Enter Only 9 Digits , Try Again");
			flg=1;
		}
		//check password input
		else if(!MethodsCheckInput.checkPassword(txtIPassword.getText())) {
			Allerts.errorAlert("Error","Password Isn't Valid , Enter At Least 8 Digits/Characters , Try Again");
			flg=1;
		}
		//check first name input
		else if(!MethodsCheckInput.validateName(txtFName.getText())) {
			Allerts.errorAlert("Error","First Name Isn't Valid , Enter Only Characters , Try Again");
			flg=1;
		}

		//check last name input
		else if(!MethodsCheckInput.validateName(txtLName.getText())) {
			Allerts.errorAlert("Error","Last Name Isn't Valid , Enter Only Characters , Try Again");
			flg=1;
		}

		//check phone number input
		else if(!MethodsCheckInput.validatePhoneNumber(txtPhoneNumber.getText())) {
			Allerts.errorAlert("Error","Phone Number Isn't Valid , Enter Only 10 Digits , Try Again");
			flg=1;
		}
		//check email input
		else if(!MethodsCheckInput.validateEmail(txtEmail.getText())) {
			Allerts.errorAlert("Error","E-mail Isn't Valid , Try Again");
			flg=1;
		}
		//check building number input
		else if(!MethodsCheckInput.validateNumber(txtBuilding.getText())) {
			Allerts.errorAlert("Error","Building Number Input Isn't Valid ,Enter Only Digits ,Try Again");
			flg=1;
		}
		//check building number input
		else if(!MethodsCheckInput.validateNumber(txtAppartment.getText())) {
			Allerts.errorAlert("Error","Appartment Number Input Isn't Valid ,Enter Only Digits ,Try Again");
			flg=1;
		}

		else if(!MethodsCheckInput.checkZipCode(txtZipCode.getText())) {
			Allerts.errorAlert("Error","Zip Code Number Input Isn't Valid ,Enter Only 5 Digits ,Try Again");
			flg=1;
		}

		if(flg==0) {
			//initialize all input fields to object
			LocalDate date = bDatePicker.getValue();
			ZoneId defaultZoneId = ZoneId.systemDefault();
			Date bDate = Date.from(date.atStartOfDay(defaultZoneId).toInstant());
			int cardNum = SQL.getMaxCardNumber();
			//create card object
			Card c = new Card(cardNum,0,new Date());
			boolean covid = true;
			double loadVal = 0.2;
			if(comboCovid.getValue().equals("Nevermind")) {
				covid=false;
			}
			if(comboCovid.getValue().equals("Nevermind")) {
				loadVal=0.8;
			}
			//create address object
			Address a = new Address(txtZipCode.getText(), txtStreet.getText(), Integer.parseInt(txtBuilding.getText()),txtCity.getText(), Integer.parseInt(txtAppartment.getText()));
			Customer cust = new Customer(txtIDNumber.getText(),txtFName.getText(),txtLName.getText(), txtEmail.getText(),
					bDate, txtIPassword.getText(), txtPhoneNumber.getText(), covid, new Date(), loadVal, a, c);
			//Add Item To DB
			if(SQL.getCust(txtIDNumber.getText()).equals("")) {
				SQL.addCard(c);
				SQL.addCustomer(cust);
				Allerts.infoAllert("Success", "Customer : "+cust.getId()+" - "+cust.getfName()+" "+cust.getlName()+" Added To System");

				if(Main.typeOfUser==2) {//check type of menu to open
					//open new frame inside current stage -> Open CSR Main Menu
					AnchorPane pane = FXMLLoader.load(getClass().getResource("CsrMenu.fxml"));
					anchore1.getChildren().setAll(pane);
				}
				else if(Main.typeOfUser==0) {//check type of menu to open
					AnchorPane pane = FXMLLoader.load(getClass().getResource("AdminMenu.fxml"));
					anchore1.getChildren().setAll(pane);	
				}

			}
			else {
				//show error alert
				Allerts.errorAlert("Error Message","Customer : "+txtIDNumber+" Allready Exist In System , Try Again");
				//empty input fields data
				txtFName.setText("");
				txtIDNumber.setText("");
				txtIPassword.setText("");
				txtLName.setText("");
				txtPhoneNumber.setText("");
				txtEmail.setText("");
				txtCity.setText("");
				txtZipCode.setText("");
				txtAppartment.setText("");
				txtStreet.setText("");
				txtBuilding.setText("");
			}
		}

	}

	/**
	 * Back Button Handler
	 * @param event
	 * @throws IOException
	 */
	@FXML
	void backHandler(ActionEvent event) throws IOException {
		if(Main.typeOfUser==2) {//check type of menu to open
			//open new frame inside current stage -> Open CSR Main Menu
			AnchorPane pane = FXMLLoader.load(getClass().getResource("CsrMenu.fxml"));
			anchore1.getChildren().setAll(pane);
		}
		if(Main.typeOfUser==0) {//check type of menu to open
			AnchorPane pane = FXMLLoader.load(getClass().getResource("AdminMenu.fxml"));
			anchore1.getChildren().setAll(pane);	
		}
	}
	
	/**
	 * Method To Initialize Data In Form
	 */
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		//initialize employee type combo box
		ObservableList<String> load = FXCollections.observableArrayList("Free","Nrvermined");
		this.comboLoad.setItems(load);
		this.comboCovid.setItems(load);
		//image resource
		Image i = new Image(getClass().getResourceAsStream("/home.jpg"));
		this.image.setImage(i);
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
	}

}
