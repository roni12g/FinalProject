package application;

import java.awt.Desktop;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.net.URL;
import java.sql.SQLException;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.ResourceBundle;

import javax.swing.JOptionPane;

import Core.Travel;
import Utils.Allerts;
import Utils.Constants;
import Utils.MethodsCheckInput;
import Utils.SQL;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuItem;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.DatePicker;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
/**
 * class that represent Manager Menu Form -> Controller  
 * @version 1.0 
 * @project - Final Project 2021  
 * @Date 07.09.2021
 */
public class ManagerMenuController extends Application implements Initializable{

	//************************************************************Class Members*********************************************************//
	/**
	 * DB SingleTone Object
	 */
	public static  Travel travel= Main.getInstance();

	//************************************************************Java FX Components*********************************************************//

	@FXML
	private AnchorPane anchore;
	@FXML
	private ImageView image;

	@FXML
	private MenuItem closeBtn;
	@FXML
	private ImageView user;

	@FXML
	private MenuItem aboutBtn;

	@FXML
	private MenuItem switchUserBtn;

	@FXML
	private MenuItem runReportBtn;

	@FXML
	private MenuItem changePassword;

	@FXML
	private MenuItem myInfoBtn;

	@FXML
	private Label idLabel;

	@FXML
	private Menu notification;

	@FXML
	private MenuItem notifications;

	@FXML
	private DatePicker dateToday;

	@FXML
	private BarChart<String, Number> barChart;

	@FXML
	private CategoryAxis x;

	@FXML
	private NumberAxis y;

	@FXML
	private ImageView imageFB;

	@FXML
	private ImageView imageChrome;



	//************************************************************Java FX Handlers*********************************************************//

	/**
	 * Method that open about form
	 * @param event
	 * @throws IOException
	 */
	@FXML
	void aboutHandler(ActionEvent event) throws IOException {
		//update type of menu (admin/manager) for next window
		Main.typeOfUser=1;
		//open new frame inside current stage
		AnchorPane pane = FXMLLoader.load(getClass().getResource("AboutFrame.fxml"));
		anchore.getChildren().setAll(pane);
	}

	/**
	 * Method that open form to change password
	 * @param event
	 * @throws IOException
	 */
	@FXML
	void changerPasswordHandler(ActionEvent event) throws IOException {
		//update type of menu (admin/manager) for next window
		Main.typeOfUser=1;
		//open new frame inside current stage
		AnchorPane pane = FXMLLoader.load(getClass().getResource("ChangeEmpPassword.fxml"));
		anchore.getChildren().setAll(pane);
	}

	/**
	 * Method that close system
	 * @param event
	 */
	@FXML
	void closeHandler(ActionEvent event) {
		//allert
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setTitle("Bye Bye");
		alert.setHeaderText(null);
		alert.setContentText("Bye!");
		alert.showAndWait();
		System.exit(0);
	}

	/**
	 * Method that open info form 
	 * @param event
	 * @throws IOException
	 */
	@FXML
	void myInfoHandler(ActionEvent event) throws IOException {
			//update type of menu (admin/manager/csr) for next window
			Main.typeOfUser=1;
			//open new frame inside current stage
			AnchorPane pane = FXMLLoader.load(getClass().getResource("ManagerDetails.fxml"));
			anchore.getChildren().setAll(pane);	
	}

	/**
	 * Method that open form to run reports by manager
	 * @param event
	 * @throws IOException
	 */
	@FXML
	void runReportHandler(ActionEvent event) throws IOException {
		//update type of menu (admin/manager) for next window
		Main.typeOfUser=1;
		//open new frame inside current stage
		AnchorPane pane = FXMLLoader.load(getClass().getResource("Report.fxml"));
		anchore.getChildren().setAll(pane);
	}


	/**
	 * Method that open form to change user
	 * @param event
	 * @throws IOException
	 */
	@FXML
	void switchHandler(ActionEvent event) throws IOException {
		//update type of menu (admin/manager) for next window
		Main.typeOfUser=-1;
		//open new frame inside current stage
		AnchorPane pane = FXMLLoader.load(getClass().getResource("LoginMenu.fxml"));
		anchore.getChildren().setAll(pane);
	}


	/**
	 * Method To Initialize Data In Form
	 */
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		idLabel.setText(LoginController.m.getEmail());
		//image resources
		Image i = new Image(getClass().getResourceAsStream("/home.jpg"));
		this.image.setImage(i);
		Image i1 = new Image(getClass().getResourceAsStream("/user.jpg"));
		this.user.setImage(i1);
		Image k = new Image(getClass().getResourceAsStream("/fb.jpg"));
		this.imageFB.setImage(k);
		Image n = new Image(getClass().getResourceAsStream("/chrome.jpg"));
		this.imageChrome.setImage(n);


		//set time and date parameter to date picker
		String day = String.valueOf(new Date().getDate());
		String month = String.valueOf(new Date().getMonth()+1);
		String year = String.valueOf(new Date().getYear()+1900);
		if(day.length()<2)
			day = "0"+day;
		if(month.length()<2)
			month = "0"+month;

		LocalDate l = MethodsCheckInput.localDate(day+"-"+month+"-"+year);
		this.dateToday.setValue(l);

		Date d = new Date();
		int monthDash = d.getMonth()+1;
		String m = "";
		if(monthDash<10) {
			m="0"+String.valueOf(monthDash);
		}
		else {
			m=String.valueOf(monthDash);
		}

		int yearDash = d.getYear()+1900;
		int firstDay =1;

		//set strings with current month details
		String date = String.valueOf(firstDay)+"-"+m+"-"+String.valueOf(yearDash);
		String lastDay = null;
		try {
			lastDay = MethodsCheckInput.getLastDay(date);
		} catch (ParseException e2) {
			e2.printStackTrace();
		}
		int last = Integer.parseInt(lastDay);


		//dash board variable
		int numberOfCustomers=0;
		int numOfCustSearches=0;
		int numOfPotentialSearches=0;
		int redLineUses=0;
		int greenLineUses=0;
		int purpleLineUses=0;
		float income = 0;


		//count method to count number customers in db in current month
		try {
			numberOfCustomers = SQL.countCustInDBInThisMonth(new Date());
		} catch (ParseException e1) {
			e1.printStackTrace();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}

		//count method to count number of new customers searches in db in current month
		try {
			numOfCustSearches = SQL.countCustSearchesInDBInThisMonth(new Date());
		} catch (ParseException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		//count method to count number of random customers searches in db in current month
		try {
			numOfPotentialSearches = SQL.countPotentialCustomersSearchesInDBInThisMonth(new Date());
		} catch (ParseException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		//count number of travels in red line
		try {
			redLineUses = SQL.countXLineUsesInDBInThisMonth(new Date(),"Red");
		} catch (ParseException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		//count number of travels in green line

		try {
			greenLineUses = SQL.countXLineUsesInDBInThisMonth(new Date(),"Green");
		} catch (ParseException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		//count number of travels in purple line

		try {
			purpleLineUses = SQL.countXLineUsesInDBInThisMonth(new Date(),"Purple");
		} catch (ParseException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
 
		//income calculator
		income = (redLineUses+greenLineUses+purpleLineUses)*Constants.pricePerTravel;

		XYChart.Series<String,Number> series1 = new XYChart.Series<>();
		XYChart.Series<String,Number> series2 = new XYChart.Series<>();
		XYChart.Series<String,Number> series3 = new XYChart.Series<>();

		//add date to bar chart
		series1.setName(monthDash+"-"+yearDash+" Statistics");
		series1.getData().add(new XYChart.Data<>("New Customers",numberOfCustomers));
		series1.getData().add(new XYChart.Data<>("Income",income));

		series2.setName(monthDash+"-"+yearDash+" Search Statistics");
		series2.getData().add(new XYChart.Data<>("Customers",numOfCustSearches));
		series2.getData().add(new XYChart.Data<>("Random",numOfPotentialSearches));

		series3.setName(monthDash+"-"+yearDash+" Lines Uses");		
		series3.getData().add(new XYChart.Data<>("Red",redLineUses));
		series3.getData().add(new XYChart.Data<>("Green",greenLineUses));
		series3.getData().add(new XYChart.Data<>("Purple",purpleLineUses));
		//set data to bar chart in form
		barChart.getData().add(series1);
		barChart.getData().add(series2);
		barChart.getData().add(series3);
		barChart.setBarGap(-30);

	}



	@Override
	public void start(Stage arg0) throws Exception {
	}

	/**
	 * Method that open form to change/add/edit notifacations in system
	 * @param event
	 * @throws IOException
	 */
	@FXML
	void notificationsHandler(ActionEvent event) throws IOException {
		//update type of menu (admin/manager) for next window
		Main.typeOfUser=1;
		//open new frame inside current stage
		AnchorPane pane = FXMLLoader.load(getClass().getResource("Notifacations.fxml"));
		anchore.getChildren().setAll(pane);
	}

	/**
	 * Method that open calculator
	 * @param event
	 * @throws IOException
	 */
	@FXML
	void calcHandler(ActionEvent event) throws IOException {
		AnchorPane pane = FXMLLoader.load(getClass().getResource("Calculator.fxml"));
		anchore.getChildren().setAll(pane);
	}

	/**
	 * Method that log off from user
	 * @param event
	 * @throws IOException 
	 */
	@FXML
	void logOffHandler(ActionEvent event) throws IOException {
		//update type of menu (admin/manager) for next window
		Main.typeOfUser=-1;
		//open new frame inside current stage
		AnchorPane pane = FXMLLoader.load(getClass().getResource("LoginMenu.fxml"));
		anchore.getChildren().setAll(pane);
	}

	/**
	 * Method that open dash boards
	 * @param event
	 * @throws IOException 
	 */
	@FXML
	void dashHandler(ActionEvent event) throws IOException {
		Main.typeOfUser=1;
		//open new frame inside current stage
		AnchorPane pane = FXMLLoader.load(getClass().getResource("DashBoard.fxml"));
		anchore.getChildren().setAll(pane);
	}

	/**
	 * Open FB Site -> System FB Web Site For System Customers And Potential Customers
	 * @param event
	 * @throws URISyntaxException 
	 * @throws IOException 
	 * @throws MalformedURLException 
	 */
	@FXML
	void fbHandler(MouseEvent event) throws MalformedURLException, IOException, URISyntaxException {
		Desktop.getDesktop().browse(new URL("https://www.facebook.com/NTAIsrael").toURI());
	}


	/**
	 * Open Web Site -> System Web Site For System Customers And Potential Customers
	 * @param event
	 * @throws URISyntaxException 
	 * @throws IOException 
	 * @throws MalformedURLException 
	 */
	@FXML
	void chromeHandler(MouseEvent event) throws MalformedURLException, IOException, URISyntaxException {
		Desktop.getDesktop().browse(new URL("http://62.90.44.179/travel/index.php").toURI());
	}

}
