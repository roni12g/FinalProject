package application;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.Date;
import java.util.ResourceBundle;

import javax.swing.JOptionPane;

import Core.Travel;
import Utils.Allerts;
import Utils.MethodsCheckInput;
import Utils.SQL;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
/**
 * class that represent Menu Form For Editing Employee Data In System -> Controller  
 * @version 1.0 
 * @project - Final Project 2021  
 * @Date 07.09.2021
 */
public class EditDetailsController extends Application implements Initializable {

	//************************************************************Class Members*********************************************************//
	/**
	 * DB SingleTone Object
	 */
	public static  Travel travel= Main.getInstance();

	//************************************************************Java FX Components*********************************************************//

	@FXML
	private AnchorPane anchore1;

	@FXML
	private AnchorPane anchore;

	@FXML
	private TextField txtFname;

	@FXML
	private TextField txtLname;

	@FXML
	private TextField txtEmail;

	@FXML
	private TextField txtStartWorkingDate;

	@FXML
	private TextField txtPhone;

	@FXML
	private ImageView image;
	@FXML
	private ImageView user;

	@FXML
	private Label idLabel;

	@FXML
	private TextField txtID;

	@FXML
	private Button applyBtn;

	@FXML
	private Button backBtn;

	@FXML
	private TextField txtAge;

	@FXML
	private Button editBtn;


	//************************************************************Java FX Handlers*********************************************************//

	/**
	 * edit button handler
	 * @param event
	 */
	@FXML
	void editHandler(ActionEvent event) {
		//fields visibility change
		this.editBtn.setVisible(false);
		this.txtFname.setEditable(true);
		this.txtLname.setEditable(true);
		this.txtPhone.setEditable(true);
		this.applyBtn.setVisible(true);

	}

	/**
	 * Apply Button Handler ->Add/Save/Modify Data In DB
	 * @param event
	 * @throws SQLException
	 */
	@FXML
	void applyHandler(ActionEvent event) throws IOException {
		if(Main.typeOfUser==1) {

			//check input -> first name
			if(!MethodsCheckInput.validateName(txtFname.getText())) {
				Allerts.errorAlert("Error","First Name Isn't Valid , Enter Only Characters , Try Again");
				txtFname.setText(LoginController.m.getfName());
			}
			//check input -> last name
			else if(!MethodsCheckInput.validateName(txtLname.getText())) {
				Allerts.errorAlert("Error","Last Name Isn't Valid , Enter Only Characters , Try Again");
				txtLname.setText(LoginController.m.getlName());

			}

			//check input -> phone number
			else if(!MethodsCheckInput.validatePhoneNumber(txtPhone.getText())) {
				Allerts.errorAlert("Error","Phone Number Isn't Valid , Enter Only 10 Digits , Try Again");
				txtPhone.setText(LoginController.m.getPhone());

			}

			else {

				if(txtPhone.getText().length()>=9) {
					//update input data in internal db -> first name , last name , phone number
					LoginController.m.setfName(txtFname.getText());
					LoginController.m.setlName(txtLname.getText());
					LoginController.m.setPhone(txtPhone.getText());
					//update input data in sql db -> first name , last name , phone number
					SQL.changeManagerDetails(LoginController.m.getId(),txtFname.getText(), txtLname.getText(),txtPhone.getText());
					travel.getManagers().get(LoginController.m.getId()).setfName(txtFname.getText());
					travel.getManagers().get(LoginController.m.getId()).setlName(txtLname.getText());
					travel.getManagers().get(LoginController.m.getId()).setPhone(txtPhone.getText());
					//alert success
					Allerts.infoAllert("Success", "Manager's Details Has Been Updated ");
					//return to previous form
					AnchorPane pane = FXMLLoader.load(getClass().getResource("ManagerMenu.fxml"));
					anchore.getChildren().setAll(pane);

				}
				else if(txtPhone.getText().length()<9) {
					//input error -> empty input fields
					Allerts.errorAlert("Error","Phone Has To Be 9-10 digits , Try Again");
					//rollback data from db to prior data
					this.txtFname.setText(LoginController.m.getfName());
					this.txtLname.setText(LoginController.m.getlName());
					this.txtPhone.setText(LoginController.m.getPhone());
					//set editable option to fields
					this.txtFname.setEditable(false);
					this.txtLname.setEditable(false);
					this.txtPhone.setEditable(false);
					this.editBtn.setVisible(true);
					this.applyBtn.setVisible(false);

				}
			}
		}
		
		else if(Main.typeOfUser==2) {

			//check input -> first name
			if(!MethodsCheckInput.validateName(txtFname.getText())) {
				Allerts.errorAlert("Error","First Name Isn't Valid , Enter Only Characters , Try Again");
				txtFname.setText(LoginController.c.getfName());
			}
			//check input -> last name
			else if(!MethodsCheckInput.validateName(txtLname.getText())) {
				Allerts.errorAlert("Error","Last Name Isn't Valid , Enter Only Characters , Try Again");
				txtLname.setText(LoginController.c.getlName());

			}

			//check input -> phone number
			else if(!MethodsCheckInput.validatePhoneNumber(txtPhone.getText())) {
				Allerts.errorAlert("Error","Phone Number Isn't Valid , Enter Only 10 Digits , Try Again");
				txtPhone.setText(LoginController.c.getPhone());

			}

			else {

				if(txtPhone.getText().length()>=9) {
					//update input data in internal db -> first name , last name , phone number
					LoginController.c.setfName(txtFname.getText());
					LoginController.c.setlName(txtLname.getText());
					LoginController.c.setPhone(txtPhone.getText());
					//update input data in sql db -> first name , last name , phone number
					SQL.changeManagerDetails(LoginController.c.getId(),txtFname.getText(), txtLname.getText(),txtPhone.getText());
					travel.getCsr().get(LoginController.c.getId()).setfName(txtFname.getText());
					travel.getCsr().get(LoginController.c.getId()).setlName(txtLname.getText());
					travel.getCsr().get(LoginController.c.getId()).setPhone(txtPhone.getText());
					//alert success
					Allerts.infoAllert("Success", "Csr's Details Has Been Updated ");
					//return to previous form
					AnchorPane pane = FXMLLoader.load(getClass().getResource("CsrMenu.fxml"));
					anchore.getChildren().setAll(pane);

				}
				else if(txtPhone.getText().length()<9) {
					//input error -> empty input fields
					Allerts.errorAlert("Error","Phone Has To Be 9-10 digits , Try Again");
					//rollback data from db to prior data
					this.txtFname.setText(LoginController.c.getfName());
					this.txtLname.setText(LoginController.c.getlName());
					this.txtPhone.setText(LoginController.c.getPhone());
					//set editable option to fields
					this.txtFname.setEditable(false);
					this.txtLname.setEditable(false);
					this.txtPhone.setEditable(false);
					this.editBtn.setVisible(true);
					this.applyBtn.setVisible(false);

				}
			}
		}
	}

	/**
	 * Back Button Handler
	 */
	@FXML
	void backHandler(ActionEvent event) throws IOException {
		if(Main.typeOfUser==1) {
			//update type of menu (admin/manager/csr) for next window
			Main.typeOfUser=1;
			//open new frame inside current stage
			AnchorPane pane = FXMLLoader.load(getClass().getResource("ManagerMenu.fxml"));
			anchore.getChildren().setAll(pane);
		}
		else if(Main.typeOfUser==2) {
			//update type of menu (admin/manager/csr) for next window
			Main.typeOfUser=2;
			//open new frame inside current stage
			AnchorPane pane = FXMLLoader.load(getClass().getResource("CsrMenu.fxml"));
			anchore.getChildren().setAll(pane);
		}
	}

	/**
	 * Method To Initialize Data In Form
	 */
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		if(Main.typeOfUser==1) {
			//set data of employee in input fields
			this.idLabel.setText(LoginController.m.getEmail());
			this.txtEmail.setEditable(false);
			this.txtFname.setEditable(false);
			this.txtLname.setEditable(false);
			this.txtID.setEditable(false);
			this.txtPhone.setEditable(false);
			this.txtAge.setEditable(false);

			this.txtStartWorkingDate.setEditable(false);
			this.txtEmail.setText(LoginController.m.getEmail());
			this.txtFname.setText(LoginController.m.getfName());
			this.txtLname.setText(LoginController.m.getlName());
			this.txtID.setText(LoginController.m.getId());
			int month = LoginController.m.getStartWorkingDate().getMonth()+1;
			int year = LoginController.m.getStartWorkingDate().getYear()+1900;
			String startWork = month+"-"+year;
			this.txtStartWorkingDate.setText(startWork);
			this.txtPhone.setText(LoginController.m.getPhone());
			Date now = new Date();
			String age = String.valueOf(now.getYear()-LoginController.m.getbDate().getYear());
			this.txtAge.setText(age);
			this.applyBtn.setVisible(false);
			//image resources
			Image i = new Image(getClass().getResourceAsStream("/home.jpg"));
			this.image.setImage(i);
			Image i1 = new Image(getClass().getResourceAsStream("/user.jpg"));
			this.user.setImage(i1);
		}

		if(Main.typeOfUser==2) {
			//set data of employee in input fields
			this.idLabel.setText(LoginController.c.getEmail());
			this.txtEmail.setEditable(false);
			this.txtFname.setEditable(false);
			this.txtLname.setEditable(false);
			this.txtID.setEditable(false);
			this.txtPhone.setEditable(false);
			this.txtAge.setEditable(false);

			this.txtStartWorkingDate.setEditable(false);
			this.txtEmail.setText(LoginController.c.getEmail());
			this.txtFname.setText(LoginController.c.getfName());
			this.txtLname.setText(LoginController.c.getlName());
			this.txtID.setText(LoginController.c.getId());
			int month = LoginController.c.getStartWorkingDate().getMonth()+1;
			int year = LoginController.c.getStartWorkingDate().getYear()+1900;
			String startWork = month+"-"+year;
			this.txtStartWorkingDate.setText(startWork);
			this.txtPhone.setText(LoginController.c.getPhone());
			Date now = new Date();
			String age = String.valueOf(now.getYear()-LoginController.c.getbDate().getYear());
			this.txtAge.setText(age);
			this.applyBtn.setVisible(false);
			//image resources
			Image i = new Image(getClass().getResourceAsStream("/home.jpg"));
			this.image.setImage(i);
			Image i1 = new Image(getClass().getResourceAsStream("/user.jpg"));
			this.user.setImage(i1);
		}

	}

	@Override
	public void start(Stage primaryStage) throws Exception {
	}
}
