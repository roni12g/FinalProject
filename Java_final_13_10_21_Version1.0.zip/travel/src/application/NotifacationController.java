package application;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.ResourceBundle;
import Core.Notifacation;
import Utils.Allerts;
import Utils.SQL;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class NotifacationController extends Application implements Initializable{

	//************************************************************Class Members*********************************************************//

	//************************************************************Java FX Components*********************************************************//

	@FXML
	private AnchorPane anchore1;

	@FXML
	private AnchorPane anchore;

	@FXML
	private ImageView image;

	@FXML
	private Button backBtn;

	@FXML
	private Button applyBtn;

	@FXML
	private Label labelDel;

	@FXML
	private Label labelAll;

	@FXML
	private TableView<Notifacation> table;

	@FXML
	private TableColumn<Notifacation,Integer> colA;

	@FXML
	private TableColumn<Notifacation,String> colB;

	@FXML
	private TableColumn<Notifacation,Date> colC;

	@FXML
	private TableColumn<Notifacation,Boolean> colD;

	@FXML
	private ComboBox<String> combo;

	@FXML
	private TextArea txt;

	@FXML
	private Label label;

	@FXML
	private Button removeBtn;

	@FXML
	private Button addBtn;

	@FXML
	private Button removeBtnSubmit;

	@FXML
	private Button backAdd;

	@FXML
	private Button backRemove;

	//************************************************************Java FX Handlers*********************************************************//

	/**
	 * Method back from remove menu to notification menu
	 * @param event
	 */
	@FXML
	void backRemoveHandler(ActionEvent event) {
		//set controllers in form
		this.addBtn.setVisible(true);
		this.removeBtn.setVisible(true);
		this.backBtn.setVisible(true);
		this.label.setVisible(true);
		ArrayList<Notifacation> data = SQL.getNotifacationsFromDB();
		//show data  in table
		ObservableList<Notifacation> tableData = FXCollections.observableArrayList(data);
		//initialize data in tables columns
		colA.setCellValueFactory(new PropertyValueFactory<Notifacation, Integer>("id"));
		colB.setCellValueFactory(new PropertyValueFactory<Notifacation, String>("details"));
		colC.setCellValueFactory(new PropertyValueFactory<Notifacation,Date>("notifyDate"));
		colD.setCellValueFactory(new PropertyValueFactory<Notifacation, Boolean>("active"));
		//set controllers in form
		this.table.setItems(tableData);
		this.table.setVisible(true);
		this.removeBtnSubmit.setVisible(false);
		this.backRemove.setVisible(false);
		this.labelDel.setVisible(false);
		this.labelAll.setVisible(true);
		this.combo.setVisible(false);
		this.addBtn.setVisible(true);
		this.removeBtn.setVisible(true);
		this.backBtn.setVisible(true);
		this.label.setVisible(true);
	}

	/**
	 * Method back from add menu to notification menu
	 * @param event
	 */
	@FXML
	void backAddHandler(ActionEvent event) {
		//set controllers in form
		this.addBtn.setVisible(true);
		this.removeBtn.setVisible(true);
		this.backBtn.setVisible(true);
		this.label.setVisible(true);
		//get data of all notifications in db to arrayList
		ArrayList<Notifacation> data = SQL.getNotifacationsFromDB();
		//show data  in table
		ObservableList<Notifacation> tableData = FXCollections.observableArrayList(data);
		//initialize data in tables columns
		colA.setCellValueFactory(new PropertyValueFactory<Notifacation, Integer>("id"));
		colB.setCellValueFactory(new PropertyValueFactory<Notifacation, String>("details"));
		colC.setCellValueFactory(new PropertyValueFactory<Notifacation,Date>("notifyDate"));
		colD.setCellValueFactory(new PropertyValueFactory<Notifacation, Boolean>("active"));
		this.table.setItems(tableData);
		this.table.setVisible(true);
		this.applyBtn.setVisible(false);
		txt.setText("");
		this.backAdd.setVisible(false);

	}

	/**
	 * Method To Initialize Data In Form
	 */
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		//set controllers in form
		labelDel.setVisible(false);
		Image i = new Image(getClass().getResourceAsStream("/home.jpg"));
		this.image.setImage(i);
		//get data of all notifications in db to arrayList
		ArrayList<Notifacation> data = SQL.getNotifacationsFromDB();
		//show data  in table
		ObservableList<Notifacation> tableData = FXCollections.observableArrayList(data);
		//initialize data in tables columns
		colA.setCellValueFactory(new PropertyValueFactory<Notifacation, Integer>("id"));
		colB.setCellValueFactory(new PropertyValueFactory<Notifacation, String>("details"));
		colC.setCellValueFactory(new PropertyValueFactory<Notifacation,Date>("notifyDate"));
		colD.setCellValueFactory(new PropertyValueFactory<Notifacation, Boolean>("active"));
		this.table.setItems(tableData);
		this.table.setVisible(true);
	}

	/**
	 * Method that remove item from notifications items in db
	 * @param event
	 */
	@FXML
	void removeBtnSubmitHandler(ActionEvent event) {
		int flg=0;
		if(combo.getValue()==null) {
			flg=1;
			Allerts.errorAlert("Error","Remove Item Cann't Be Empty,Plese Choose Item To Delete From System");	
		}

		if(flg==0) {
			String comboData = combo.getValue().substring(0, combo.getValue().indexOf("-"));
			int i = Integer.parseInt(comboData);
			//remove notification from db
			SQL.removeNotification(i);
			Allerts.infoAllert("Success","Notification : "+i+" Removed From System");
			//get data of all notifications in db to arrayList
			ArrayList<Notifacation> data = SQL.getNotifacationsFromDB();
			//show data  in table
			ObservableList<Notifacation> tableData = FXCollections.observableArrayList(data);
			//initialize data in tables columns
			colA.setCellValueFactory(new PropertyValueFactory<Notifacation, Integer>("id"));
			colB.setCellValueFactory(new PropertyValueFactory<Notifacation, String>("details"));
			colC.setCellValueFactory(new PropertyValueFactory<Notifacation,Date>("notifyDate"));
			colD.setCellValueFactory(new PropertyValueFactory<Notifacation, Boolean>("active"));
			//set controllers in form
			this.table.setItems(tableData);
			this.table.setVisible(true);
			this.removeBtnSubmit.setVisible(false);
			this.backRemove.setVisible(false);
			this.combo.setVisible(false);
			this.labelDel.setVisible(false);
			this.addBtn.setVisible(true);
			this.removeBtn.setVisible(true);
			this.backBtn.setVisible(true);
			this.label.setVisible(true);

		}
	}

	/**
	 * Method that ad item to notifications items in db
	 * @param event
	 */
	@FXML
	void applyHandler(ActionEvent event) {
		String text = this.txt.getText();
		Notifacation n = new Notifacation(0,text, new Date(),true);
		int flg=0;
		//check text input
		if(text.length()==0) {
			Allerts.errorAlert("Error","Notification Cann't Be Empty , Try Again");
			flg=1;

		}
		if(flg==0) {
			//add new notification to db
			SQL.sqlAddNotifacation(n);
			Allerts.infoAllert("Success","Notifacation Added Successfully To System");
			//set controllers in form
			this.applyBtn.setVisible(false);
			this.label.setVisible(false);
			this.addBtn.setVisible(true);
			this.removeBtn.setVisible(true);
			this.backBtn.setVisible(true);
			this.txt.setVisible(false);
			//get data of all notifications in db to arrayList
			ArrayList<Notifacation> data = SQL.getNotifacationsFromDB();
			//show data  in table
			ObservableList<Notifacation> tableData = FXCollections.observableArrayList(data);
			//initialize data in tables columns
			colA.setCellValueFactory(new PropertyValueFactory<Notifacation, Integer>("id"));
			colB.setCellValueFactory(new PropertyValueFactory<Notifacation, String>("details"));
			colC.setCellValueFactory(new PropertyValueFactory<Notifacation,Date>("notifyDate"));
			colD.setCellValueFactory(new PropertyValueFactory<Notifacation, Boolean>("active"));
			this.table.setItems(tableData);
			this.table.setVisible(true);
			this.backAdd.setVisible(false);
			txt.setText("");
		}

	}

	/**
	 * Back Button Handler
	 */
	@FXML
	void backHandler(ActionEvent event) throws IOException {
		if(Main.typeOfUser==0) {//check if user is admin
			//open new frame inside current stage
			AnchorPane pane = FXMLLoader.load(getClass().getResource("AdminMenu.fxml"));
			anchore.getChildren().setAll(pane);
		}
		else if(Main.typeOfUser==1) {//check if user is finance manager
			//open new frame inside current stage
			AnchorPane pane = FXMLLoader.load(getClass().getResource("ManagerMenu.fxml"));
			anchore.getChildren().setAll(pane);
		}
	}	  

	/**
	 * add Button Handler
	 */
	@FXML
	void addHandler(ActionEvent event) {
		//set controllers in form
		this.table.setVisible(false);
		this.backBtn.setVisible(false);
		this.applyBtn.setVisible(true);
		this.removeBtnSubmit.setVisible(false);
		this.removeBtn.setVisible(false);
		this.addBtn.setVisible(false);
		this.txt.setVisible(true);
		this.label.setVisible(true);	
		this.labelAll.setVisible(false);
		this.backAdd.setVisible(true);
	}

	/**
	 * remove Button Handler
	 */
	@FXML
	void removeHandler(ActionEvent event) {
		//set controllers in form
		this.table.setVisible(false);
		this.backBtn.setVisible(false);
		this.removeBtnSubmit.setVisible(true);
		this.removeBtn.setVisible(false);
		this.addBtn.setVisible(false);
		this.txt.setVisible(false);
		this.label.setVisible(false);	
		this.labelAll.setVisible(false);
		this.labelDel.setVisible(true);
		this.combo.setVisible(true);
		this.backRemove.setVisible(true);
		//get data of all notifications in db to arrayList
		ArrayList<Notifacation> data = SQL.getNotifacationsFromDB();
		ArrayList<String> items = new ArrayList<String>();
		for(Notifacation n : data) {
			items.add(n.getId()+"-"+n.getDetails());
		}

		ObservableList<String> list = FXCollections.observableArrayList(items);
		combo.setItems(list);
	}


	@FXML
	void comboSelect(ActionEvent event) {

	}

	@Override
	public void start(Stage primaryStage) throws Exception {

	}
}
