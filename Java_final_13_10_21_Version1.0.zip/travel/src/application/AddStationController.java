package application;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javax.swing.JOptionPane;

import Core.Line;
import Core.Station;
import Core.Travel;
import Utils.Allerts;
import Utils.E_City;
import Utils.E_LineColor;
import Utils.MethodsCheckInput;
import Utils.SQL;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
/**
 * class that represent  Form For Adding Station To System  Controller  
 * @version 1.0 
 * @project - Final Project 2021  
 * @Date 07.09.2021
 */
public class AddStationController extends Application implements Initializable{
	
	//************************************************************Class Members*********************************************************//
	/**
	 * DB SingleTone Object
	 */
	public static  Travel travel= Main.getInstance();

	//************************************************************Java FX Components*********************************************************//

	@FXML
	private AnchorPane anchore1;

    @FXML
    private ImageView image;
    
    
	@FXML
	private AnchorPane anchore;

	@FXML
	private ComboBox<String> comboJunction;

	@FXML
	private TextField txtStationName;

	@FXML
	private ComboBox<String> comboCity;

	@FXML
	private ComboBox<String> comboPrimaryLine;

	@FXML
	private ComboBox<String> comboSecondaryLine;

	@FXML
	private Button applyBtn;

	@FXML
	private TextField txtStationNumber;

	@FXML
	private Button backBtn;

	@FXML
	private CheckBox checkBoxSec;


	//************************************************************Java FX Handlers*********************************************************//
	/**
	 * Apply Button Handler ->Add/Save/Modify Data In DB
	 * @param event
	 * @throws SQLException
	 */
	@FXML
	void applyHandler(ActionEvent event) throws SQLException {
		Line primary = null;
		Line secondary = null;
		boolean junctionVal = true;
		
		//check junction input field and populate it with correct data
		if(comboJunction.getValue()=="No")
			junctionVal=false;

		//update data for primary and secondary line colors 
		for(Line l : travel.getLines()) {
			if(l.getColor().toString().equals(comboPrimaryLine.getValue())) {
				primary=l;
			}
			if(l.getColor().toString().equals(comboSecondaryLine.getValue())) {
				secondary=l;
			}
		}

		//check input of station name
		if(!MethodsCheckInput.validateName(txtStationName.getText())) {
			Allerts.errorAlert("Error","Station Name Isn't Valid , Enter Only Characters , Try Again");
			txtStationName.setText("");
			txtStationNumber.setText("");
		}
		//check input of number of stations
		else if(!MethodsCheckInput.validateNumber(txtStationNumber.getText())) {
			Allerts.errorAlert("Error","Station Number Isn't Valid , Enter Only Numbers , Try Again");
			txtStationName.setText("");
			txtStationNumber.setText("");
		}
		
		//check if new station already exist in db
		else if(!travel.getStations().containsKey(txtStationName.getText())) {
			//create new station object
			Station s = new Station(Integer.parseInt(txtStationNumber.getText()),txtStationName.getText(),junctionVal,comboCity.getValue());

			//add primary line to station
			s.addLine(primary);
			//add secondary line to station
			if(secondary!=null) {
				s.addLine(secondary);
			}
			//add station to sql db
			SQL.addStation(s);
			//update current station list
			SQL.getStations();
			Allerts.infoAllert("Success","Station  : "+s.getStationName()+" Added To System");
			txtStationName.setText("");
			txtStationNumber.setText("");
		}
		else {
			//station exist already in db
			Allerts.errorAlert("Error","Station "+txtStationName.getText()+" Allready Exist In System , Try Again");
			txtStationName.setText("");
			txtStationNumber.setText("");
		}
	}
	
    /**
	 * Back Button Handler
	 */
	@FXML
	void backHandler(ActionEvent event) throws IOException {
		//reutrn to admin menu form
		AnchorPane pane = FXMLLoader.load(getClass().getResource("AdminMenu.fxml"));
		anchore1.getChildren().setAll(pane);
	}
	
	
	/**
	 * Method To Initialize Data In Form
	 */
	@Override
	public void initialize(URL location, ResourceBundle resources) {

		comboSecondaryLine.setValue("");

		//initialize colors combo box
		ArrayList<String> colors = new ArrayList<String>();
		for(E_LineColor e : E_LineColor.values()) {
			colors.add(e.toString());
		}

		//initialize cisites combo box
		ArrayList<String> citiesValues = new ArrayList<String>();
		for(E_City e : E_City.values()) {
			citiesValues.add(e.getCity());
		}
		ObservableList<String> list = FXCollections.observableArrayList(colors);
		ObservableList<String> cities = FXCollections.observableArrayList(citiesValues);
		ObservableList<String> junctions = FXCollections.observableArrayList("Yes","No");

		//set combo boxes items
		this.comboJunction.setItems(junctions);
		this.comboPrimaryLine.setItems(list);
		comboSecondaryLine.setDisable(true);
		this.comboCity.setItems(cities);
		//image resource
		Image i = new Image(getClass().getResourceAsStream("/home.jpg"));
		this.image.setImage(i);
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
	}

	@FXML
	void openSecondaryOptionHandler(ActionEvent event) {

	}
	
    @FXML
    void checkBoxSecLineHandler(ActionEvent event) {
		//initialize check box of secondary line color
    	ArrayList<String> colors = new ArrayList<String>();
		for(E_LineColor e : E_LineColor.values()) {
			colors.add(e.toString());
		}

		//initialize combo box of colors for secondary line color
		//if selected check box enable combo box for secondary color pick
		if(checkBoxSec.isSelected()) {
			ObservableList<String> list = FXCollections.observableArrayList(colors);
			comboSecondaryLine.setDisable(false);
			this.comboSecondaryLine.setItems(list);
		}
		//if not selected check box disable combo box for secondary color pick
		if(!checkBoxSec.isSelected()) {
			comboSecondaryLine.setDisable(true);
			comboSecondaryLine.setValue("");
		}
    }
}
