package application;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

import javax.swing.JOptionPane;

import Utils.Allerts;
import Utils.EmailMethods;
import Utils.SQL;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
/**
 * class that represent Retrieve Password Menu Form -> Controller  
 * @version 1.0 
 * @project - Final Project 2021  
 * @Date 07.09.2021
 */
public class RetrievePasswordController extends Application implements Initializable {

	//************************************************************Class Members*********************************************************//

	//************************************************************Java FX Components*********************************************************//

	@FXML
	private AnchorPane anchore1;

	@FXML
	private AnchorPane anchore;

	@FXML
	private TextField txtID;

	@FXML
	private Button backBtn;

	@FXML
	private ImageView image;

	@FXML
	private Button applyBtn;

	@FXML
	private CheckBox checkBoxTrems;

	//************************************************************Java FX Handlers*********************************************************//
	/**
	 * Apply Button Handler ->Add/Save/Modify Data In DB
	 * @param event
	 * @throws IOException 
	 * @throws SQLException
	 */
	@FXML
	void applyHandler(ActionEvent event) throws IOException, SQLException {
		//check if check box is selected and then send email for changing password proccess
		if(checkBoxTrems.isSelected()) {
			//get user's id mail from db
			String mail = SQL.getEmail(txtID.getText()); 
			//check if user exist in system
			if(!mail.equals("")) {
				//send mail to user
				EmailMethods.generateMail(mail,txtID.getText());
				//message dialog for sending mail
				String s = mail.substring(mail.lastIndexOf("@") + 1);
				Allerts.infoAllert("Reset Password","Reset Password Email Sent to :"+mail.charAt(0)+mail.charAt(1)+"****@"+s+" ...");
				txtID.setDisable(true);
				//return to login menu
				AnchorPane pane = FXMLLoader.load(getClass().getResource("LoginMenu.fxml"));
				anchore1.getChildren().setAll(pane);
			}
			//user doesn't exist in system
			else {
				Allerts.errorAlert("Error","Id number : "+txtID.getText()+" doesn't exist in System,Try Again");
			}
		}
		else {//alert
			Allerts.errorAlert("Error", "You Have To Agree To Terms Of Use , Try Again");
		}
	}

	/**
	 * Back Button handler
	 * @param event
	 * @throws IOException
	 */
	@FXML
	void backHandler(ActionEvent event) throws IOException {
		//update type of user for next window
		Main.typeOfUser=-1;
		//open new frame inside current stage
		AnchorPane pane = FXMLLoader.load(getClass().getResource("LoginMenu.fxml"));
		anchore1.getChildren().setAll(pane);

	}

	/**
	 * Method To Initialize Data In Form
	 */
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		//image resources
		Image i = new Image(getClass().getResourceAsStream("/home.jpg"));
		this.image.setImage(i);		
	}

	@Override
	public void start(Stage primaryStage) throws Exception {		
	}


}
