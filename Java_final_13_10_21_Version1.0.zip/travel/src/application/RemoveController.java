package application;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Map.Entry;

import javax.swing.JOptionPane;

import java.util.ResourceBundle;

import Core.Line;
import Core.Manager;
import Core.Station;
import Core.Travel;
import Utils.Allerts;
import Utils.SQL;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
/**
 * class that represent Remove Item Menu Form -> Controller  
 * @version 1.0 
 * @project - Final Project 2021  
 * @Date 07.09.2021
 */
public class RemoveController extends Application implements Initializable {

	//************************************************************Class Members*********************************************************//
	/**
	 * DB SingleTone Object
	 */
	public static  Travel travel= Main.getInstance();

	/**
	 * Flag Variable For Check Type OF OPtion To Enable
	 */
	public int flg =0;

	//************************************************************Java FX Components*********************************************************//
	@FXML
	private Label itemLabel;

	@FXML
	private AnchorPane anchore1;

	@FXML
	private ImageView image;

	@FXML
	private Label removeCustLabel;

	@FXML
	private TextField txtID;

	@FXML
	private AnchorPane anchore;

	@FXML
	private ComboBox<String> comboItemType;

	@FXML
	private ComboBox<String> comboItem;

	@FXML
	private Button applyBtn;

	@FXML
	private Button backBtn;


	//************************************************************Java FX Handlers*********************************************************//

	/**
	 * Method to initialize combo boxes of data (Employee/Line/Station And Etc)
	 * @param event
	 */
	@FXML
	void comboSelector(ActionEvent event) {
		//check if selected value is Remove Finance Manager
		if(comboItemType.getValue().equals("Remove Finance Manager")) {
			this.itemLabel.setVisible(true);
			this.comboItem.setVisible(true);
			this.removeCustLabel.setVisible(false);
			this.txtID.setVisible(false);
			ArrayList<String> managers = new ArrayList<String>();
			for(Entry<String,Manager> entry: travel.getManagers().entrySet()) {
				managers.add(entry.getValue().getId()+"-"+entry.getValue().getfName()+" "+entry.getValue().getlName());
			}
			ObservableList<String> list = FXCollections.observableArrayList(managers);
			//set items of finance managers from system db
			comboItem.setItems(list);
		}
		//check if selected value is Remove Station
		else if(comboItemType.getValue().equals("Remove Station")) {
			this.itemLabel.setVisible(true);
			this.comboItem.setVisible(true);
			this.removeCustLabel.setVisible(false);
			this.txtID.setVisible(false);
			ArrayList<String> stations = new ArrayList<String>();
			for(Entry<String,Station> entry: travel.getStations().entrySet()) {
				stations.add(entry.getValue().getStationName()+"- City :"+entry.getValue().getCity());
			}
			//set items of stations from system db
			ObservableList<String> list = FXCollections.observableArrayList(stations);
			comboItem.setItems(list);
		}
		//check if selected value is Remove Line
		else if(comboItemType.getValue().equals("Remove Line")) {
			this.itemLabel.setVisible(true);
			this.comboItem.setVisible(true);
			this.removeCustLabel.setVisible(false);
			this.txtID.setVisible(false);
			ArrayList<String> lines = new ArrayList<String>();
			for(Line l: travel.getLines()) {
				lines.add(l.getColor().toString());
			}
			//set items of lines from system db
			ObservableList<String> list = FXCollections.observableArrayList(lines);
			comboItem.setItems(list);
		}

		//check if selected value is Remove CSR Employee
		else if(comboItemType.getValue().equals("Remove Csr Employee")) {
			this.itemLabel.setVisible(true);
			this.comboItem.setVisible(true);
			this.removeCustLabel.setVisible(false);
			this.txtID.setVisible(false);
			ArrayList<String> CsrEmployees = SQL.getEmployeesCSRToArrayList();

			//set items of lines from system db
			ObservableList<String> list = FXCollections.observableArrayList(CsrEmployees);
			comboItem.setItems(list);
		}

		//check if selected value is Remove Customer
		else if(comboItemType.getValue().equals("Remove Customer")) {
			this.itemLabel.setVisible(false);
			this.comboItem.setVisible(false);
			this.removeCustLabel.setVisible(true);
			this.txtID.setVisible(true);
		}
	}
	/**
	 * Apply Button Handler ->Add/Save/Modify Data In DB
	 * @param event
	 * @throws SQLException
	 */ 
	@FXML
	void applyHandler(ActionEvent event) throws SQLException {
		flg=0;
		int flgRemove=0;
		Line line = null;
		//check if combo box isn't empty
		if(comboItemType.getValue()==null)
			flg=1;
		if(flg ==1) {
			//empty combo box -> alert
			Allerts.errorAlert("Error", "Failed , You Have To Choose Item Type To Remove");
		} 
		
		if (comboItemType.getValue().equals("Remove Customer")) {
			String s = this.txtID.getText();
			String id = SQL.getCust(s);
			if(s.equals(id)) {
				SQL.removeCustomer(id);
				Allerts.infoAllert("Success","Customer : "+id+" Deleted From DB");
				txtID.setText("");
			}
			else {
				Allerts.errorAlert("Error","Customer : "+txtID.getText()+" Doesn't Exist In DB , Try Again");
				txtID.setText("");
			}
		}
		
		if(comboItem.getValue()==null) {
			flg=1;
		}
		if(flg==0) {

			if(comboItemType.getValue().equals("Remove Finance Manager")) {
				String value = comboItem.getValue().substring(0, comboItem.getValue().indexOf("-"));
				Allerts.infoAllert("Success", "Finance Manager : "+value+" "+travel.getManagers().get(value).getfName()
						+" "+travel.getManagers().get(value).getlName()+" Removed From System");
				//remove finance manager from inner and sql db
				Travel.removeItem(travel.getManagers(),value, travel.getManagers().get(value));
				SQL.removeManager(value);
				//update list of object -> finance managers from sql server
				ArrayList<String> managers = new ArrayList<String>();
				for(Entry<String,Manager> entry: travel.getManagers().entrySet()) {
					managers.add(entry.getValue().getId()+"-"+entry.getValue().getfName()+" "+entry.getValue().getlName());
				}
				ObservableList<String> list = FXCollections.observableArrayList(managers);
				comboItem.setItems(list);


			}

			else if (comboItemType.getValue().equals("Remove Csr Employee")) {
				String value = comboItem.getValue().substring(0, comboItem.getValue().indexOf("-"));
				Allerts.infoAllert("Success", "Csr Employee : "+comboItem.getValue()+" Removed From System");
				//remove finance manager from sql db
				SQL.removeCsr(value);
				//update list of object -> finance managers from sql server
				ArrayList<String> emps = SQL.getEmployeesCSRToArrayList();
				ObservableList<String> list = FXCollections.observableArrayList(emps);
				comboItem.setItems(list);
			}
			//check if remove type is Station
			else if(comboItemType.getValue().equals("Remove Station")) {
				String value = comboItem.getValue().substring(0, comboItem.getValue().indexOf("-"));
				Allerts.infoAllert("Success", "Station : "+value+" Removed From System");
				//remove station from inner and sql db
				Travel.removeItem(travel.getStations(),value, travel.getStations().get(value));
				SQL.removeStation(value);

				//update list of object -> stations from sql server
				ArrayList<String> stations = new ArrayList<String>();
				for(Entry<String,Station> entry: travel.getStations().entrySet()) {
					stations.add(entry.getValue().getStationName()+"- City :"+entry.getValue().getCity());
				}
				ObservableList<String> list = FXCollections.observableArrayList(stations);
				comboItem.setItems(list);

			}
			//check if remove type is Line
			else if(comboItemType.getValue().equals("Remove Line")) {
				//check if stations connected to line -> for removing line needed to disconnect all connected stations from line
				for(Entry<String,Station> entry: travel.getStations().entrySet()) {
					for(Line l : entry.getValue().getLines()) {
						if(l.getColor().toString().equals(comboItem.getValue())) {
							flgRemove=1;
						}
					}

				}
				if(flgRemove==1) {//error -> cann't remove line that have stations connected to it
					Allerts.errorAlert("Error", "Line : "+comboItem.getValue()+" Cann't Be Removed, Stations Stil Connected To This Line");
				}
				if(flgRemove==0) {
					//remove line from sql db
					SQL.removeLine(comboItem.getValue());
					Allerts.infoAllert("Success","Line : "+comboItem.getValue()+" Removed From System");
					for(Line l : travel.getLines()) {
						if(l.getColor().toString().equals(comboItem.getValue())) {
							line = l;
						}
					}
					//remove line from inner db
					travel.getLines().remove(line);
					//update list of lines combo box 
					ArrayList<String> lines = new ArrayList<String>();
					for(Line l: travel.getLines()) {
						lines.add(l.getColor().toString());
					}
					ObservableList<String> list = FXCollections.observableArrayList(lines);
					comboItem.setItems(list);
				}
			}	
		}
	}

	/**
	 * Back Button Handler
	 */
	@FXML
	void backHandler(ActionEvent event) throws IOException {
		//open admin menu form
		AnchorPane pane = FXMLLoader.load(getClass().getResource("AdminMenu.fxml"));
		anchore1.getChildren().setAll(pane);
	}

	/**
	 * Method To Initialize Data In Form
	 */
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		//initialize data in type of object to remove
		ObservableList<String> list = FXCollections.observableArrayList("Remove Finance Manager","Remove Station","Remove Line","Remove Csr Employee","Remove Customer");
		this.comboItemType.setItems(list);
		Image i = new Image(getClass().getResourceAsStream("/home.jpg"));
		this.image.setImage(i);

	}

	@Override
	public void start(Stage primaryStage) throws Exception {
	}

}
