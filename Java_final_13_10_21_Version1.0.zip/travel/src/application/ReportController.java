package application;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Objects;
import java.util.ResourceBundle;
import Core.Travel;
import ExcelObjects.ExcelReportCustSearches;
import ExcelObjects.ExcelReportCustUse;
import ExcelObjects.ExcelReportIncome;
import Utils.Allerts;
import Utils.Constants;
import Utils.MethodsCheckInput;
import Utils.SQL;
import Utils.WriteExcelIncome;
import Utils.WriteExcelSearchCustData;
import Utils.WriteExcelUseData;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
/**
 * class that represent Report Menu Form -> Controller  
 * @version 1.0 
 * @project - Final Project 2021  
 * @Date 07.09.2021
 */
public class ReportController extends Application implements Initializable{

	//************************************************************Class Members*********************************************************//
	/**
	 * DB SingleTone Object
	 */
	public static  Travel travel= Main.getInstance();

	//************************************************************Java FX Components*********************************************************//

	@FXML
	private AnchorPane anchore;
	@FXML
	private ImageView image;

	@FXML
	private ComboBox<String> comboItemType;

	@FXML
	private DatePicker startDatePicker;

	@FXML
	private DatePicker endDatePicker;

	@FXML
	private CheckBox checkBoxEntireMonth;

	@FXML
	private ComboBox<String> comboMonth;

	@FXML
	private ComboBox<String> comboYear;

	@FXML
	private Button backButton;

	@FXML
	private Button applyButton;

	private FileChooser fileCooser = new FileChooser();

	@FXML
	private TableView<tableData> tableSearchResults;

	@FXML
	private TableColumn<tableData, Integer> col1;

	@FXML
	private TableColumn<tableData,String> col2;

	@FXML
	private TableColumn<tableData, String> col3;

	@FXML
	private TableColumn<tableData, String> col4;

	@FXML
	private TableColumn<tableData, String> col5;

	@FXML
	private TableColumn<tableData, Integer> col6;

	@FXML
	private TableView<useTableData> table2;

	@FXML
	private TableColumn<useTableData,String> colB1;

	@FXML
	private TableColumn<useTableData, Float> colB2;

	@FXML
	private TableColumn<useTableData, Integer> colB3;

	@FXML
	private TableColumn<useTableData, Float> colB4;

	@FXML
	private TableColumn<useTableData, String> colB5;

	@FXML
	private TableColumn<useTableData, String> colB6;

	@FXML
	private TableView<IncomeTable> tableC;

	@FXML
	private TableColumn<IncomeTable,String> colC1;

	@FXML
	private TableColumn<IncomeTable,Integer> colc2;

	@FXML
	private TableColumn<IncomeTable,Float> colc3;

	//************************************************************Java FX Handlers*********************************************************//
	/**
	 * Apply Button Handler ->Add/Save/Modify Data In DB
	 * @param event
	 * @throws SQLException
	 */
	@FXML
	void applyHandler(ActionEvent event) {
		int flg=0;
		//check if combo box isn't empty
		if(comboItemType.getValue()==null) {
			flg=1;
			//empty combo box
			if(flg ==1) {
				Allerts.errorAlert("Error", "Failed , You Have To Choose Report Type");
			}	
		}

		else if(flg==0) {
			int typeOfDates = 0;
			//combo box not empty -> check type of report = search report
			if(comboItemType.getValue().equals("Search Report")) {
				//create excel file to save report
				fileCooser.setTitle("Save Report Dialog");
				Date d = new Date();
				int year = d.getYear()+1900;
				int month = d.getMonth()+1;
				//name for report Month+Year+type of report
				fileCooser.setInitialFileName("SearchReport_"+year+"_"+month+"_");
				fileCooser.getExtensionFilters().addAll(new FileChooser.ExtensionFilter("Excel file", "*xlsx"),
						new FileChooser.ExtensionFilter("CSV file", "*csv"));

				try {//create excel report
					File file = fileCooser.showSaveDialog(null);
					fileCooser.setInitialDirectory(file);
					WriteExcelSearchCustData w = new WriteExcelSearchCustData();
					String loc = file.getPath()+".xlsx";
					Allerts.infoAllert("Success", "Report Created Successfully");
					//hide not relevant fields from form
					this.applyButton.setVisible(false);
					this.checkBoxEntireMonth.setVisible(false);
					this.comboItemType.setVisible(false);
					this.comboMonth.setVisible(false);
					this.endDatePicker.setVisible(false);
					this.startDatePicker.setVisible(false);
					this.table2.setVisible(false);
					this.checkBoxEntireMonth.setVisible(false);
					this.comboMonth.setVisible(false);
					this.comboYear.setVisible(false);

					//check if selected month or dates input
					if(this.checkBoxEntireMonth.isSelected()) {
						typeOfDates=2;

						this.endDatePicker.setDisable(true);
						this.startDatePicker.setDisable(true);
						this.comboMonth.setDisable(false);
						this.comboYear.setDisable(false);
					}
					//check if selected month or dates input
					else if(!this.checkBoxEntireMonth.isSelected()) {
						typeOfDates=1;
						this.endDatePicker.setDisable(false);
						this.startDatePicker.setDisable(false);
						this.comboMonth.setDisable(true);
						this.comboYear.setDisable(true);
					}
					ArrayList<ExcelReportCustSearches> data=null;
					if(typeOfDates==1) {
						data= SQL.getCustSearchesFromDBByDates(startDatePicker.getValue().toString(), endDatePicker.getValue().toString());
					}
					if(typeOfDates==2) {
						//sql qry for data 
						String monthVar =comboMonth.getValue();
						String yearVar =comboYear.getValue();

						String firstDate = yearVar+"-"+monthVar+"-"+"01";
						String lastDay = MethodsCheckInput.getLastDay(firstDate);
						String secondDate = yearVar+"-"+monthVar+"-"+lastDay;

						data= SQL.getCustSearchesFromDBByDates(firstDate,secondDate);
					}
					//write file to location selected
					w.writeExcelFile(loc,data);
					ArrayList<tableData> tableDataInput = new ArrayList<tableData>();

					//create table to show on screen summary of report
					for(ExcelReportCustSearches e : data) {
						tableData td = new tableData(e.getSourceStationName(),e.getDestStationName(),e.getSourceStationNameCity(),e.getDestinationStationNameCity(),1);
						int flag=0;
						for(tableData t : tableDataInput) {
							if(t.equals(td)) {
								flag=1;
								t.setSearches(t.getSearches()+1);
							}

						}
						if(flag==0) {
							tableDataInput.add(td);
						}
					}

					//show data  in table
					ObservableList<tableData> table = FXCollections.observableArrayList(tableDataInput);
					//initialize data in tables columns
					col2.setCellValueFactory(new PropertyValueFactory<tableData, String>("sourceStation"));
					col3.setCellValueFactory(new PropertyValueFactory<tableData, String>("destStation"));
					col4.setCellValueFactory(new PropertyValueFactory<tableData,String>("sourceStationCity"));
					col5.setCellValueFactory(new PropertyValueFactory<tableData, String>("destStationCity"));
					col6.setCellValueFactory(new PropertyValueFactory<tableData, Integer>("searches"));
					this.tableSearchResults.setItems(table);
					this.tableSearchResults.setVisible(true);
					//update sql tables 
					SQL.addReportId();
					int i = SQL.getMaxReportIdNumber();
					SQL.addReportToManager(i,String.valueOf(travel.getManagers().get(LoginController.m.getId()).getId()),"Search Report");

				}

				catch(Exception e) {
					System.out.println(e.getMessage());
				}
			}
			//combo box not empty -> check type of report = stations use report
			else if(comboItemType.getValue().equals("Use Report")) {
				fileCooser.setTitle("Save Report Dialog");
				//create excel file to save report
				Date d = new Date();
				int year = d.getYear()+1900;
				int month = d.getMonth()+1;
				//name for report Month+Year+type of report
				fileCooser.setInitialFileName("UseReport_"+year+"_"+month+"_");
				fileCooser.getExtensionFilters().addAll(new FileChooser.ExtensionFilter("Excel file", "*xlsx"),
						new FileChooser.ExtensionFilter("CSV file", "*csv"));

				try {//create excel report
					File file = fileCooser.showSaveDialog(null);
					fileCooser.setInitialDirectory(file);
					//create excel export file
					WriteExcelUseData w = new WriteExcelUseData();
					String loc = file.getPath()+".xlsx";
					Allerts.infoAllert("Success", "Report Created Successfully");
					//hide not relevant fields from form
					this.applyButton.setVisible(false);
					this.checkBoxEntireMonth.setVisible(false);
					this.comboItemType.setVisible(false);
					this.comboMonth.setVisible(false);
					this.endDatePicker.setVisible(false);
					this.startDatePicker.setVisible(false);
					this.checkBoxEntireMonth.setVisible(false);
					this.comboMonth.setVisible(false);
					this.comboYear.setVisible(false);
					ArrayList<ExcelReportCustUse> data =null;
					//check if selected month or dates input
					if(this.checkBoxEntireMonth.isSelected()) {
						typeOfDates=2;

						this.endDatePicker.setDisable(true);
						this.startDatePicker.setDisable(true);
						this.comboMonth.setDisable(false);
						this.comboYear.setDisable(false);
					}
					//check if selected month or dates input
					else if(!this.checkBoxEntireMonth.isSelected()) {
						typeOfDates=1;
						this.endDatePicker.setDisable(false);
						this.startDatePicker.setDisable(false);
						this.comboMonth.setDisable(true);
						this.comboYear.setDisable(true);
					}
					ArrayList<ExcelReportCustUse> data2=null;
					//sql qry for data 
					if(typeOfDates==1) {
						data2 = SQL.getCustUsesFromDBByDates(startDatePicker.getValue().toString(), endDatePicker.getValue().toString()); 
					}
					//sql qry for data 
					if(typeOfDates==2) {
						String monthVar =comboMonth.getValue();
						String yearVar =comboYear.getValue();

						String firstDate = yearVar+"-"+monthVar+"-"+"01";
						String lastDay = MethodsCheckInput.getLastDay(firstDate);
						String secondDate = yearVar+"-"+monthVar+"-"+lastDay;
						System.out.println(secondDate);

						data2= SQL.getCustUsesFromDBByDates(firstDate,secondDate);
					}

					//write file to location selected
					w.writeExcelFile(loc,data2);
					ArrayList<useTableData> useTableDataInput = new ArrayList<useTableData>();
					//create table to show on screen summary of report
					for(ExcelReportCustUse e : data2) {
						useTableData td = new useTableData(e.getStartStation(), e.getEndStation(), e.getStationName(), 1, e.getLoadParameter(),e.getCovid19InOut());
						int flag=0;
						for(useTableData t : useTableDataInput){
							if(t.equals(td)) {
								flag=1;
								t.getCovid19InOutAvg().add(e.getCovid19InOut());
								t.getLoadParameterAvg().add(e.getLoadParameter());
								t.setUseage(t.getUseage()+1);
								float f =0;
								for(int i=0;i<t.getCovid19InOutAvg().size();i++) {
									f+=t.getCovid19InOutAvg().get(i);
								}
								t.setAvgCovid19(f/t.getCovid19InOutAvg().size());
								f=0;
								for(int i=0;i<t.getLoadParameterAvg().size();i++) {
									f+=t.getLoadParameterAvg().get(i);
								}
								t.setAvgLoad(f/t.getLoadParameterAvg().size());
							}

						}
						if(flag==0) {
							td.getCovid19InOutAvg().add(e.getCovid19InOut());
							td.getLoadParameterAvg().add(e.getLoadParameter());
							td.setAvgCovid19(e.getCovid19InOut());
							td.setAvgLoad(e.getLoadParameter());
							td.setUseage(1);
							System.out.println(td);
							useTableDataInput.add(td);
						}
					}

					//show data  in table
					ObservableList<useTableData> table = FXCollections.observableArrayList(useTableDataInput);
					//initialize data in tables columns
					colB1.setCellValueFactory(new PropertyValueFactory<useTableData,String>("stationName"));
					colB2.setCellValueFactory(new PropertyValueFactory<useTableData, Float>("avgLoad"));
					colB3.setCellValueFactory(new PropertyValueFactory<useTableData, Integer>("useage"));
					colB4.setCellValueFactory(new PropertyValueFactory<useTableData,Float>("avgCovid19"));
					colB5.setCellValueFactory(new PropertyValueFactory<useTableData, String>("startStation"));
					colB6.setCellValueFactory(new PropertyValueFactory<useTableData	, String>("endStation"));
					this.table2.setItems(table);
					this.table2.setVisible(true);
					//update sql tables 
					SQL.addReportId();
					int i = SQL.getMaxReportIdNumber();
					SQL.addReportToManager(i,String.valueOf(travel.getManagers().get(LoginController.m.getId()).getId()),"Use Report");


				}

				catch(Exception e) {
					System.out.println(e.getMessage());
				}
			}
			//combo box not empty -> check type of report = income report
			else if(comboItemType.getValue().equals("Income Report")) {
				//create excel file to save report
				fileCooser.setTitle("Save Report Dialog");
				Date d = new Date();
				int year = d.getYear()+1900;
				int month = d.getMonth()+1;
				//name for report Month+Year+type of report
				fileCooser.setInitialFileName("IncomeReport_"+year+"_"+month+"_");
				fileCooser.getExtensionFilters().addAll(new FileChooser.ExtensionFilter("Excel file", "*xlsx"),
						new FileChooser.ExtensionFilter("CSV file", "*csv"));

				try {//create excel report
					File file = fileCooser.showSaveDialog(null);
					fileCooser.setInitialDirectory(file);
					//create excel export file
					WriteExcelIncome w = new WriteExcelIncome();
					String loc = file.getPath()+".xlsx";
					Allerts.infoAllert("Success", "Report Created Successfully");
					//hide not relevant fields from form
					this.applyButton.setVisible(false);
					this.checkBoxEntireMonth.setVisible(false);
					this.comboItemType.setVisible(false);
					this.comboMonth.setVisible(false);
					this.endDatePicker.setVisible(false);
					this.startDatePicker.setVisible(false);
					this.checkBoxEntireMonth.setVisible(false);
					this.comboMonth.setVisible(false);
					this.comboYear.setVisible(false);
					//check if selected month or dates input
					if(this.checkBoxEntireMonth.isSelected()) {
						typeOfDates=2;
						this.endDatePicker.setDisable(true);
						this.startDatePicker.setDisable(true);
						this.comboMonth.setDisable(false);
						this.comboYear.setDisable(false);
					}
					//check if selected month or dates input
					else if(!this.checkBoxEntireMonth.isSelected()) {
						typeOfDates=1;
						this.endDatePicker.setDisable(false);
						this.startDatePicker.setDisable(false);
						this.comboMonth.setDisable(true);
						this.comboYear.setDisable(true);
					}
					ArrayList<ExcelReportIncome> data3=null;
					if(typeOfDates==1) {
						//sql qry for data 
						data3 = SQL.getCustUsesFromDBByDatesWithIncome(startDatePicker.getValue().toString(), endDatePicker.getValue().toString()); 
					}
					if(typeOfDates==2) {
						//sql qry for data 
						String monthVar = comboMonth.getValue();
						String yearVar = comboYear.getValue();

						String firstDate = yearVar+"-"+monthVar+"-"+"01";
						String lastDay = MethodsCheckInput.getLastDay(firstDate);
						String secondDate = yearVar+"-"+monthVar+"-"+lastDay;

						data3= SQL.getCustUsesFromDBByDatesWithIncome(firstDate,secondDate);
					}
					//write file to location selected
					w.writeExcelFile(loc,data3);
					ArrayList<IncomeTable> incomeTableData = new ArrayList<IncomeTable>();

					if(data3.size()>0) {
						//create table to show on screen summary of report
						for(ExcelReportIncome e : data3) {
							String stationName = e.getStationName();
							String color = SQL.getStationColor(stationName);
							IncomeTable in = new IncomeTable(color, Constants.pricePerTravel,1); 
							int flag=0;
							for(IncomeTable t : incomeTableData){
								if(t.equals(in)) {
									flag=1;
									float incomeAmount = t.getIncomeAmount()+in.getIncomeAmount();
									t.setIncomeAmount(incomeAmount);
									int amount = t.getNumOfTravels()+1;
									t.setNumOfTravels(amount);
								}

							}
							if(flag==0) {
								incomeTableData.add(in);
							}
						}

						//show data  in table
						ObservableList<IncomeTable> table = FXCollections.observableArrayList(incomeTableData);
						//initialize data in tables columns

						colC1.setCellValueFactory(new PropertyValueFactory<IncomeTable,String>("color"));
						colc2.setCellValueFactory(new PropertyValueFactory<IncomeTable, Integer>("numOfTravels"));
						colc3.setCellValueFactory(new PropertyValueFactory<IncomeTable, Float>("incomeAmount"));

						this.tableC.setItems(table);
						this.tableC.setVisible(true);
					}
					//update sql tables 
					SQL.addReportId();
					int i = SQL.getMaxReportIdNumber();
					SQL.addReportToManager(i,String.valueOf(travel.getManagers().get(LoginController.m.getId()).getId()),"Income Report");
				}

				catch(Exception e) {
					System.out.println(e.getMessage());
				}
			}

		}    	
	}

	/**
	 * Back Button Handler
	 * @param event
	 * @throws IOException
	 */
	@FXML
	void backHandler(ActionEvent event) throws IOException {
		if(Main.typeOfUser==0) {
			//open new frame inside current stage
			AnchorPane pane = FXMLLoader.load(getClass().getResource("AdminMenu.fxml"));
			anchore.getChildren().setAll(pane);
		}
		else if(Main.typeOfUser==1) {
			//open new frame inside current stage
			AnchorPane pane = FXMLLoader.load(getClass().getResource("ManagerMenu.fxml"));
			anchore.getChildren().setAll(pane);
		}
	}

	/**
	 * Check Box Handler Method
	 * @param event
	 */
	@FXML
	void checkBoxEntireMonthHandler(ActionEvent event) {
		if(this.checkBoxEntireMonth.isSelected()) {
			this.endDatePicker.setDisable(true);
			this.startDatePicker.setDisable(true);
			this.comboMonth.setDisable(false);
			this.comboYear.setDisable(false);
		}

		else if(!this.checkBoxEntireMonth.isSelected()) {
			this.endDatePicker.setDisable(false);
			this.startDatePicker.setDisable(false);
			this.comboMonth.setDisable(true);
			this.comboYear.setDisable(true);
		}
	}

	/**
	 * Method To Initialize Data In Form
	 */
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		//initialize combo boxes
		ObservableList<String> list = FXCollections.observableArrayList("Search Report","Use Report","Income Report");
		ObservableList<String> months = FXCollections.observableArrayList("01","02","03","04","05","06","07","08","09","10","11","12");
		ObservableList<String> years = FXCollections.observableArrayList("2018","2019","2020","2021","2022");

		this.comboItemType.setItems(list);
		this.comboMonth.setItems(months);
		this.comboYear.setItems(years);		

		this.comboMonth.setDisable(true);
		this.comboYear.setDisable(true);
		//image resources
		Image i = new Image(getClass().getResourceAsStream("/home.jpg"));
		this.image.setImage(i);
		//file chooser location -> default location
		fileCooser.setInitialDirectory(new File("C:\\"));
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
	}

	//************************************************************Static Inner Classes For Tables*********************************************************//


	//*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-Class Report Searches-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-//

	/**
	 * Inner static class for table of Excel document
	 */
	public static class tableData{
		//-----------------------Class Members--------------------------------------//

		/**
		 * source Station variable
		 */
		public String sourceStation;

		/**
		 * destination Station variable
		 */
		public String destStation;

		/**
		 * source Station city variable
		 */
		public String sourceStationCity;

		/** destination Station city variable
		 * 
		 */
		public String destStationCity;

		/**
		 * searches # variable
		 */
		public int searches;

		//-----------------------Constructor--------------------------------------//

		/**
		 * constructor
		 * @param sourceStation
		 * @param destStation
		 * @param sourceStationCity
		 * @param destStationCity
		 * @param searches
		 */
		public tableData(String sourceStation, String destStation, String sourceStationCity, String destStationCity,
				int searches) {
			this.sourceStation = sourceStation;
			this.destStation = destStation;
			this.sourceStationCity = sourceStationCity;
			this.destStationCity = destStationCity;
			this.searches = searches;
		}

		//-----------------------Getters And Setters--------------------------------------//

		/**
		 * Method that get source station
		 * @return sourceStation
		 */
		public String getSourceStation() {
			return sourceStation;
		}

		/**
		 * Method that set source station
		 * @param sourceStation
		 */
		public void setSourceStation(String sourceStation) {
			this.sourceStation = sourceStation;
		}

		/**
		 * Method that get destination station
		 * @return destStation
		 */
		public String getDestStation() {
			return destStation;
		}

		/**
		 * Method that set destination station
		 * @param destStation
		 */
		public void setDestStation(String destStation) {
			this.destStation = destStation;
		}

		/**
		 * Method that get source station city 
		 * @return sourceStationCity
		 */
		public String getSourceStationCity() {
			return sourceStationCity;
		}

		/**
		 * Method that set source station city
		 * @param sourceStationCity
		 */
		public void setSourceStationCity(String sourceStationCity) {
			this.sourceStationCity = sourceStationCity;
		}

		/**
		 * Method that get destination station city
		 * @return destStationCity
		 */
		public String getDestStationCity() {
			return destStationCity;
		}

		/**
		 * Method that set destination station city
		 * @param destStationCity
		 */
		public void setDestStationCity(String destStationCity) {
			this.destStationCity = destStationCity;
		}

		/**
		 * Method that get searches#
		 * @return searches
		 */
		public int getSearches() {
			return searches;
		}

		/**
		 * Method that set searches#
		 * @param searches
		 */
		public void setSearches(int searches) {
			this.searches = searches;
		}

		//-----------------------Other Methods--------------------------------------//

		/**
		 * hashcode method
		 */
		@Override
		public int hashCode() {
			return Objects.hash(destStation, sourceStation);
		}

		/**
		 * equals method -> check if 2 objects of this class are equal or not
		 */
		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			tableData other = (tableData) obj;
			return Objects.equals(destStation, other.destStation) && Objects.equals(sourceStation, other.sourceStation);
		}

		/**
		 * to string method
		 */
		@Override
		public String toString() {
			return "tableData [sourceStation=" + sourceStation + ", destStation=" + destStation + ", sourceStationCity="
					+ sourceStationCity + ", destStationCity=" + destStationCity + ", searches=" + searches + "]";
		}

	}

	//*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-Class Report Uses-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-//

	/**
	 * Inner static class for table of Excel document
	 */
	public static class useTableData{
		//-----------------------Class Members--------------------------------------//

		/**
		 * route start station variable
		 */
		private	String startStation ;

		/**
		 * route end station variable
		 */
		private String endStation ;

		/**
		 * current station load parameter variable
		 */
		private ArrayList<Float> loadParameterAvg;

		/**
		 * covid-19 arrayList for line(1 route)
		 */
		private ArrayList<Integer> covid19InOutAvg;

		/**
		 * current station name variable
		 */
		private String stationName;

		/**
		 * Usage # variable
		 */
		private int useage;

		/**
		 * average station load variable
		 */
		private float avgLoad;

		/**
		 * average station covid19 variable
		 */
		private float avgCovid19;

		//-----------------------Constructor--------------------------------------//

		/**
		 * constructor
		 * @param startStation
		 * @param endStation
		 * @param stationName
		 * @param useage
		 * @param avgLoad
		 * @param avgCovid19
		 */
		public useTableData(String startStation, String endStation, String stationName, int useage, float avgLoad,
				float avgCovid19) {
			this.startStation = startStation;
			this.endStation = endStation;
			this.stationName = stationName;
			this.useage = useage;
			this.avgLoad = avgLoad;
			this.avgCovid19 = avgCovid19;
			this.covid19InOutAvg =  new ArrayList<Integer>();
			this.loadParameterAvg = new ArrayList<Float>();
		}

		//-----------------------Getters And Setters--------------------------------------//

		/**
		 * Method that get line's start station
		 * @return startStation
		 */
		public String getStartStation() {
			return startStation;
		}

		/**
		 * Method that set line's start station
		 * @param startStation
		 */
		public void setStartStation(String startStation) {
			this.startStation = startStation;
		}

		/**
		 * Method that get line's end station
		 * @return endStation
		 */
		public String getEndStation() {
			return endStation;
		}

		/**
		 * Method that set line's end station
		 * @param endStation
		 */
		public void setEndStation(String endStation) {
			this.endStation = endStation;
		}

		/**
		 * Method that get line's station average load parameter 
		 * @return loadParameterAvg
		 */
		public ArrayList<Float> getLoadParameterAvg() {
			return loadParameterAvg;
		}

		/**
		 * Method that set line's station average load parameter
		 * @param loadParameterAvg
		 */
		public void setLoadParameterAvg(ArrayList<Float> loadParameterAvg) {
			this.loadParameterAvg = loadParameterAvg;
		}

		/**
		 * Method that get line's station average covid-19 arrayList
		 * @return covid19InOutAvg
		 */
		public ArrayList<Integer> getCovid19InOutAvg() {
			return covid19InOutAvg;
		}

		/**
		 * Method that set line's station average covid-19 arrayList
		 * @param covid19InOutAvg
		 */
		public void setCovid19InOutAvg(ArrayList<Integer> covid19InOutAvg) {
			this.covid19InOutAvg = covid19InOutAvg;
		}

		/**
		 * Method that get current station
		 * @return stationName
		 */
		public String getStationName() {
			return stationName;
		}

		/**
		 * Method that set current station
		 * @param stationName
		 */
		public void setStationName(String stationName) {
			this.stationName = stationName;
		}

		/**
		 * Method that get station's usage #
		 * @return useage
		 */
		public int getUseage() {
			return useage;
		}

		/**
		 * Method that set station's usage #
		 * @param useage
		 */
		public void setUseage(int useage) {
			this.useage = useage;
		}

		/**
		 * Method that get station's average load 
		 * @return avgLoad
		 */
		public float getAvgLoad() {
			return avgLoad;
		}

		/**
		 * Method that set station's average load 
		 * @param avgLoad
		 */
		public void setAvgLoad(float avgLoad) {
			this.avgLoad = avgLoad;
		}

		/**
		 * Method that get station's average covid-19 
		 * @return avgCovid19
		 */
		public float getAvgCovid19() {
			return avgCovid19;
		}

		/**
		 * Method that set station's average covid-19
		 * @param avgCovid19
		 */
		public void setAvgCovid19(float avgCovid19) {
			this.avgCovid19 = avgCovid19;
		}

		//-----------------------Other Methods--------------------------------------//

		/**
		 * hashcode method
		 */
		@Override
		public int hashCode() {
			return Objects.hash(endStation, startStation, stationName);
		}


		/**
		 * equals method -> check if 2 objects of this class are equal or not
		 */
		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			useTableData other = (useTableData) obj;
			return Objects.equals(endStation, other.endStation) && Objects.equals(startStation, other.startStation)
					&& Objects.equals(stationName, other.stationName);
		}

		/**
		 * to string method
		 */
		@Override
		public String toString() {
			return "useTableData [startStation=" + startStation + ", endStation=" + endStation + ", stationName="
					+ stationName + ", useage=" + useage + ", avgLoad=" + avgLoad + ", avgCovid19=" + avgCovid19 + "]";
		}
	}

	//*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-Class Report Income-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-//

	/**
	 * Inner static class for table of Excel document
	 */
	public static class IncomeTable{
		//-----------------------Class Members--------------------------------------//

		/**
		 * line's color variable
		 */
		private String color;

		/**
		 * income amount variable
		 */
		private float incomeAmount;

		/**
		 * income number of travels
		 */
		private int numOfTravels;

		//-----------------------Constructor--------------------------------------//

		/**
		 * constructor
		 * @param color
		 * @param incomeAmount
		 * @param numOfTravels
		 */
		public IncomeTable(String color, float incomeAmount, int numOfTravels) {
			this.color = color;
			this.incomeAmount = incomeAmount;
			this.numOfTravels = numOfTravels;
		}

		//-----------------------Getters And Setters--------------------------------------//

		/**
		 * Method that get line's color
		 * @return color
		 */
		public String getColor() {
			return color;
		}

		/**
		 * Method that set line's color
		 * @param color
		 */
		public void setColor(String color) {
			this.color = color;
		}

		/**
		 * Method that get line's income amount 
		 * @return incomeAmount
		 */
		public float getIncomeAmount() {
			return incomeAmount;
		}

		/**
		 * Method that set line's income amount 
		 * @param incomeAmount
		 */
		public void setIncomeAmount(float incomeAmount) {
			this.incomeAmount = incomeAmount;
		}

		/**
		 * Method that get line's income amount of travels
		 * @return numOfTravels
		 */
		public int getNumOfTravels() {
			return numOfTravels;
		}

		/**
		 * Method that set line's income amount of travels
		 * @param numOfTravels
		 */
		public void setNumOfTravels(int numOfTravels) {
			this.numOfTravels = numOfTravels;
		}

		//-----------------------Other Methods--------------------------------------//

		/**
		 * hashcode method
		 */
		@Override
		public int hashCode() {
			return Objects.hash(color);
		}

		/**
		 * equals method -> check if 2 objects of this class are equal or not
		 */
		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			IncomeTable other = (IncomeTable) obj;
			return Objects.equals(color, other.color);
		}

		/**
		 * to string method
		 */
		@Override
		public String toString() {
			return "IncomeTable [color=" + color + ", incomeAmount=" + incomeAmount + ", numOfTravels=" + numOfTravels
					+ "]";
		}


	}

}
