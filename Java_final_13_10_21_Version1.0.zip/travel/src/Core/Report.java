package Core;

import java.util.Date;

/**
 * class that represent report in system  
 * @version 1.0 
 * @project - Final Project 2021  
 * @Date 07.09.2021
 */
public class Report {

	//************************************************************Class Members*********************************************************//

	/**
	 * report number variable
	 */
	private int reportNumber;
	
	/**
	 * report date variable
	 */
	private Date reportDate;
	
	//************************************************************Constructor*********************************************************//

	/**
	 * Constructor
	 * @param reportNumber
	 * @param reportDate
	 */
	public Report(int reportNumber, Date reportDate) {
		this.reportNumber = reportNumber;
		this.reportDate = reportDate;
	}

	//***************************************Getters And Setters*******************************************//

	/**
	 * Method that get report number
	 * @return reportNumber
	 */
	public int getReportNumber() {
		return reportNumber;
	}

	/**
	 * Method that set report number
	 * @param reportNumber
	 */
	public void setReportNumber(int reportNumber) {
		this.reportNumber = reportNumber;
	}

	/**
	 * Method that get report date
	 * @return reportDate
	 */
	public Date getReportDate() {
		return reportDate;
	}

	/**
	 * Method that set report date
	 * @param reportDate
	 */
	public void setReportDate(Date reportDate) {
		this.reportDate = reportDate;
	}

	//************************************************************ Methods*********************************************************//

	/**
	 * hash code method
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + reportNumber;
		return result;
	}

	/**
	 * equals method -> check if 2 objects of this class are equal or not
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Report other = (Report) obj;
		if (reportNumber != other.reportNumber)
			return false;
		return true;
	}

	/**
	 * to string method
	 */
	@Override
	public String toString() {
		return "Report [reportNumber=" + reportNumber + ", reportDate=" + reportDate + "]";
	}
	
	
}
