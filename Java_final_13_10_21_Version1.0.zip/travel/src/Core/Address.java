package Core;

import java.util.Objects;

/**
 * class that represent address  
 * @version 1.0 
 * @project - Final Project 2021  
 * @Date 07.09.2021
 */
public class Address {

	//************************************************************Class Members*********************************************************//

	/**
	 * zip code variable
	 */
	private String zipCode;

	/**
	 * street variable
	 */
	private String street;

	/**
	 * building number variable
	 */
	private int buildingNumber;

	/**
	 * city variable
	 */
	private String city;

	/**
	 * department variable
	 */
	private int departmentNumber;

	//************************************************************Constructor*********************************************************//


	/**
	 * Constructor
	 * @param zipCode
	 * @param street
	 * @param buildingNumber
	 * @param city
	 */
	public Address(String zipCode, String street, int buildingNumber, String city, int departmentNumber) {
		this.zipCode = zipCode;
		this.street = street;
		this.buildingNumber = buildingNumber;
		this.city = city;
		this.departmentNumber = departmentNumber;
	}

	//***************************************Getters And Setters*******************************************//

	/**
	 * Method that get address's zip code
	 * @return zipCode
	 */
	public String getZipCode() {
		return zipCode;
	}


	/**
	 * Method that set address's zip code
	 * @param zipCode
	 */
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	/**
	 * Method that get address's street
	 * @return street
	 */
	public String getStreet() {
		return street;
	}

	/**
	 * Method that set address's street
	 * @param street
	 */
	public void setStreet(String street) {
		this.street = street;
	}

	/**
	 * Method that get address's building number
	 * @return buildingNumber
	 */
	public int getBuildingNumber() {
		return buildingNumber;
	}

	/**
	 * Method that set address's building number
	 * @param buildingNumber
	 */
	public void setBuildingNumber(int buildingNumber) {
		this.buildingNumber = buildingNumber;
	}

	/**
	 * Method that get address's city
	 * @return city
	 */
	public String getCity() {
		return city;
	}

	/**
	 * Method that set address's city
	 * @param city
	 */
	public void setCity(String city) {
		this.city = city;
	}

	/**
	 *  Method that get address's department
	 * @return departmentNumber
	 */
	public int getDepartmentNumber() {
		return departmentNumber;
	}

	/**
	 * Method that set address's department
	 * @param departmentNumber
	 */
	public void setDepartmentNumber(int departmentNumber) {
		this.departmentNumber = departmentNumber;
	}


	
	//************************************************************ Methods*********************************************************//

	/**
	 * to string method
	 */
	@Override
	public String toString() {
		return "Address [zipCode=" + zipCode + ", street=" + street + ", buildingNumber=" + buildingNumber + ", city="
				+ city + ", departmentNumber=" + departmentNumber + "]";
	}

	/**
	 * hash code method
	 */
	@Override
	public int hashCode() {
		return Objects.hash(buildingNumber, city, departmentNumber, street, zipCode);
	}

	/**
	 * equals method -> check if 2 objects of this class are equal or not
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Address other = (Address) obj;
		return buildingNumber == other.buildingNumber && Objects.equals(city, other.city)
				&& departmentNumber == other.departmentNumber && Objects.equals(street, other.street)
				&& Objects.equals(zipCode, other.zipCode);
	}
}
