package Core;

import java.util.ArrayList;
import java.util.HashMap;

import Utils.E_City;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
/**
 * class that represent Travel System DB  
 * @version 1.0 
 * @project - Final Project 2021  
 * @Date 07.09.2021
 */
public class Travel {

	//************************************************************Class Members*********************************************************//

	/**
	 * customers hash map structure variable
	 */
	private HashMap<String, Customer> customers;

	/**
	 * managers hash map structure variable
	 */
	private HashMap<String, Manager> managers;
	/**
	 * csr hash map structure variable
	 */
	private HashMap<String, Csr> csr;
	
	/**
	 * lines arrayList structure variable
	 */
	private ArrayList<Line> lines;

	/**
	 * routes hash map structure variable
	 */
	private HashMap<Integer, Route> routes;

	/**
	 * stations hash map structure variable
	 */
	private HashMap<String, Station> stations;

	/**
	 * stop in hash map structure variable
	 */
	private HashMap<Integer, StopsIn> stopsIn;

	/**
	 * trains hash map structure variable
	 */
	private HashMap<Integer, Train> trains;

	/**
	 * reports hash map structure variable
	 */
	private HashMap<Integer, Report> reports;

	/**
	 * customers exit/enter hash map structure variable
	 */
	private HashMap<Integer, CustomerExitEnter> customersExitEnter;

	/**
	 * customers searches hash map structure variable
	 */
	private HashMap<Integer, CustomerExitEnter> customersSearches;

	/**
	 * potential customers searches hash map structure variable
	 */
	private HashMap<Integer, CustomerExitEnter> potentialUsersSearches;


	//************************************************************Constructor*********************************************************//

	
	/**
	 * Constructor
	 */
	public Travel() {
		this.customers=new HashMap<String, Customer>();
		this.customersExitEnter =  new HashMap<Integer, CustomerExitEnter>();
		this.customersSearches = new HashMap<Integer, CustomerExitEnter>();
		this.lines = new ArrayList<Line>();
		this.managers = new HashMap<String, Manager>();
		this.potentialUsersSearches = new HashMap<Integer, CustomerExitEnter>();
		this.reports = new HashMap<Integer, Report>();
		this.routes = new HashMap<Integer, Route>();
		this.stations = new HashMap<String, Station>();
		this.stopsIn = new HashMap<Integer, StopsIn>();
		this.trains = new HashMap<Integer, Train>();
		this.csr = new HashMap<String,Csr>();
	}

	//***************************************Getters And Setters*******************************************//

	/**
	 * Method that get all customers from system inner db
	 * @return customers
	 */
	public HashMap<String, Customer> getCustomers() {
		return customers;
	}

	/**
	 * Method that get all csr employees from system inner db
	 * @return csr
	 */
	public HashMap<String, Csr> getCsr() {
		return csr;
	}

	/**
	 * Method that get all managers from system inner db
	 * @return managers
	 */
	public HashMap<String, Manager> getManagers() {
		return managers;
	}

	/**
	 * Method that get all lines from system inner db
	 * @return lines
	 */
	public ArrayList<Line> getLines() {
		return lines;
	}

	/**
	 * Method that get all routes from system inner db
	 * @return routes
	 */
	public HashMap<Integer, Route> getRoutes() {
		return routes;
	}

	/**
	 * Method that get all stations from system inner db
	 * @return stations
	 */
	public HashMap<String, Station> getStations() {
		return stations;
	}

	/**
	 * Method that get all stop in from system inner db
	 * @return stopsIn
	 */
	public HashMap<Integer, StopsIn> getStopsIn() {
		return stopsIn;
	}

	/**
	 * Method that get all trains from system inner db
	 * @return trains
	 */
	public HashMap<Integer, Train> getTrains() {
		return trains;
	}

	/**
	 * Method that get all reports from system inner db
	 * @return reports
	 */
	public HashMap<Integer, Report> getReports() {
		return reports;
	}
	
	/**
	 * Method that get all customers exit/enter data from system inner db
	 * @return customersExitEnter
	 */
	public HashMap<Integer, CustomerExitEnter> getCustomersExitEnter() {
		return customersExitEnter;
	}

	/**
	 * Method that get all customers searches from system inner db
	 * @return customersSearches
	 */
	public HashMap<Integer, CustomerExitEnter> getCustomersSearches() {
		return customersSearches;
	}

	/**
	 * Method that get all potential customers searches from system inner db
	 * @return potentialUsersSearches
	 */
	public HashMap<Integer, CustomerExitEnter> getPotentialUsersSearches() {
		return potentialUsersSearches;
	}

	//************************************************************ Methods*********************************************************//

	/**
	 * Add Item To Hash Map - Generic Method
	 * @param <K>
	 * @param <V>
	 * @param map
	 * @param key
	 * @param value
	 * @return true/false if succeed in adding data
	 */
	public static <K,V> boolean addItem(HashMap<K,V> map,K key,V value) {
		if(value!=null) {
			//check if item exists in hash map
			if(!map.containsKey(key)) {
				//add new item
				map.put(key,value);
				return true;
			}
			return false;

		}
		return false;	
	}
	
	
	

	//************************************************************ Methods*********************************************************//

	/**
	 * Remove Item From Hash Map - Generic Method
	 * @param <K>
	 * @param <V>
	 * @param map
	 * @param key
	 * @param value
	 * @return true/false if succeed in removing data
	 */
	
	public static <K,V> boolean removeItem(HashMap<K,V> map,K key,V value) {
		//check input
		if(value!=null) {
			//check if object exsist in db
			if(map.containsKey(key)) {
				//remove item from map
				map.remove(key, value);
				return true;
			}
			return false;
		}
		return false;	
	}

	/**
	 * Generic Method that get values from hash map -> enter data to ObservableList for setting up combo box input component
	 * @param <K>
	 * @param <V>
	 * @return data
	 */
	public static <K,V> ObservableList<V> getObjects(HashMap<K,V> map){
		//loop over data in db
		ObservableList<V> data = FXCollections.observableArrayList();
		for(V v : map.values()) {
			//add item to Observable List
			data.add(v);
		}
		return data;
	}
	

	

}
