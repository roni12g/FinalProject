package Core;

import java.util.Date;
import java.util.HashMap;
/**
 * class that represent Customer In System  
 * @version 1.0 
 * @project - Final Project 2021  
 * @Date 07.09.2021
 */
public class Customer extends SystemUser {
	
	//************************************************************Class Members*********************************************************//

	/**
	 * covid-19 value variable -> customer's preferences in system for search
	 */
	private boolean covid19Val;

	/**
	 * customer's join date variable
	 */
	private Date joinDate;

	/**
	 * train station load value variable -> customer's preferences in system for search
	 */
	private double loadVal;

	/**
	 * customer's address variable
	 */
	private Address address;

	/**
	 * customer's card variable
	 */
	private Card card;

	/**
	 * customer's searched routes
	 */
	private HashMap<Integer,Route> routesSearched;
	
	//************************************************************Constructor*********************************************************//

	/**
	 * Constructor
	 * @param id
	 * @param fName
	 * @param lNamge
	 * @param email
	 * @param bDate
	 * @param password
	 * @param phone
	 * @param covid19
	 * @param joinDate
	 * @param load
	 * @param address
	 * @param card
	 */
	public Customer(String id, String fName, String lName, String email, Date bDate, String password, String phone, boolean covid19, Date joinDate, double load, Address address, Card card) {
		super(id, fName, lName, email, bDate, password, phone);
		this.covid19Val=covid19;
		this.joinDate=joinDate;
		this.loadVal=load;
		this.address=address;
		this.card=card;
		this.routesSearched = new HashMap<Integer, Route>();
	}



	//***************************************Getters And Setters*******************************************//

	/**
	 * Method that get customer's covid-19 value
	 * @return covid19Val
	 */
	public boolean isCovid19Val() {
		return covid19Val;
	}


	/**
	 * Method that set customer's covid-19 value
	 * @param covid19Val
	 */
	public void setCovid19Val(boolean covid19Val) {
		this.covid19Val = covid19Val;
	}


	/**
	 * Method that get customer's join date
	 * @return joinDate
	 */
	public Date getJoinDate() {
		return joinDate;
	}

	/**
	 * Method that set customer's join date
	 * @param joinDate
	 */
	public void setJoinDate(Date joinDate) {
		this.joinDate = joinDate;
	}


	/**
	 * Method that get customer's load value
	 * @return loadVal
	 */
	public double getLoadVal() {
		return loadVal;
	}


	/**
	 * Method that set customer's load value
	 * @param loadVal
	 */
	public void setLoadVal(double loadVal) {
		this.loadVal = loadVal;
	}


	/**
	 * Method that get customer's address
	 * @return address
	 */
	public Address getAddress() {
		return address;
	}


	/**
	 * Method that set customer's address
	 * @param address
	 */
	public void setAddress(Address address) {
		this.address = address;
	}


	/**
	 * Method that get customer's card
	 * @return card
	 */
	public Card getCard() {
		return card;
	}


	/**
	 * Method that set customer's card
	 * @param card
	 */
	public void setCard(Card card) {
		this.card = card;
	}

	/**
	 * Method that get customer's searches arrayList
	 * @return routesSearched
	 */
	public HashMap<Integer, Route> getRoutesSearched() {
		return routesSearched;
	}


	/**
	 * Method that set customer's searches arrayList
	 * @param routesSearched
	 */
	public void setRoutesSearched(HashMap<Integer, Route> routesSearched) {
		this.routesSearched = routesSearched;
	}



	//************************************************************ Methods*********************************************************//


	/**
	 * to string method
	 */
	@Override
	public String toString() {
		return "Customer : covid19 : " + covid19Val + ", joinDate : " + joinDate + ", load : " + loadVal + ", address : " + address
				+ ", card=" + card +" "+super.toString();
	}



}
