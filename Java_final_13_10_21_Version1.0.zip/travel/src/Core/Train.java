package Core;

/**
 * class that represent Train in System  
 * @version 1.0 
 * @project - Final Project 2021  
 * @Date 07.09.2021
 */
public class Train {

	//************************************************************Class Members*********************************************************//

	/**
	 * train number variable
	 */
	private int trainNumber;
	
	/**
	 * train's max seats number variable
	 */
	private int maxSeats;
	
	//************************************************************Constructor*********************************************************//

	/**Constructor
	 * 
	 * @param trainNumber
	 * @param maxSeats
	 */
	public Train(int trainNumber, int maxSeats) {
		this.trainNumber = trainNumber;
		this.maxSeats = maxSeats;
	}

	//***************************************Getters And Setters*******************************************//

	/**
	 * Method that get train number
	 * @return trainNumber
	 */
	public int getTrainNumber() {
		return trainNumber;
	}

	/**
	 * Method that set train number
	 * @param trainNumber
	 */
	public void setTrainNumber(int trainNumber) {
		this.trainNumber = trainNumber;
	}

	/**
	 * Method that get train's max seats number
	 * @return maxSeats
	 */
	public int getMaxSeats() {
		return maxSeats;
	}

	/**
	 * Method that set train's max seats number
	 * @param maxSeats
	 */
	public void setMaxSeats(int maxSeats) {
		this.maxSeats = maxSeats;
	}

	//************************************************************ Methods*********************************************************//

	/**
	 * hash code method
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + trainNumber;
		return result;
	}

	/**
	 * equals method -> check if 2 objects of this class are equal or not
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Train other = (Train) obj;
		if (trainNumber != other.trainNumber)
			return false;
		return true;
	}

	/**
	 * to string method
	 */
	@Override
	public String toString() {
		return "Train : " + trainNumber + ", maxSeats : " + maxSeats;
	}
	
}
