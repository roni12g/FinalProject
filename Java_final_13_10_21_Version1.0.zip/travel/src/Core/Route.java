package Core;

import java.util.Date;

/**
 * class that represent route in system  
 * @version 1.0 
 * @project - Final Project 2021  
 * @Date 07.09.2021
 */
public class Route {

	//************************************************************Class Members*********************************************************//

	/**
	 * route number variable
	 */
	private int routeNumber;
	
	/**
	 * route length variable
	 */
	private double length;
	
	/**
	 * date variable
	 */
	private Date date;
	
	/**
	 * start hour variable
	 */
	private int startHour;
	
	/**
	 * end hour variable
	 */
	private int endHour;
	
	/**
	 * source station variable
	 */
	private Station sourceStation;
	
	/**
	 * destination station variable
	 */
	private Station destStation;
	
	//************************************************************Constructor*********************************************************//

	
	/**
	 * Constructor
	 * @param routeNumber
	 * @param length
	 * @param date
	 * @param startHour
	 * @param endHour
	 * @param sourceStation
	 * @param destStation
	 */
	public Route(int routeNumber, double length, Date date, int startHour, int endHour, Station sourceStation,
			Station destStation) {
		this.routeNumber = routeNumber;
		this.length = length;
		this.date = date;
		this.startHour = startHour;
		this.endHour = endHour;
		this.sourceStation = sourceStation;
		this.destStation = destStation;
	}

	//***************************************Getters And Setters*******************************************//

	/**
	 * Method that get route number
	 * @return routeNumber
	 */
	public int getRouteNumber() {
		return routeNumber;
	}

	/**
	 * Method that set route number
	 * @param routeNumber
	 */
	public void setRouteNumber(int routeNumber) {
		this.routeNumber = routeNumber;
	}

	/**
	 * Method that get route length
	 * @return length
	 */
	public double getLength() {
		return length;
	}

	/**
	 * Method that set route length
	 * @param length
	 */
	public void setLength(double length) {
		this.length = length;
	}

	/**
	 * Method that get route date
	 * @return date
	 */
	public Date getDate() {
		return date;
	}

	/**
	 * Method that set route date
	 * @param date
	 */
	public void setDate(Date date) {
		this.date = date;
	}

	/**
	 * Method that get route start hour
	 * @return startHour
	 */
	public int getStartHour() {
		return startHour;
	}

	/**
	 * Method that set route start hour
	 * @param startHour
	 */
	public void setStartHour(int startHour) {
		this.startHour = startHour;
	}

	/**
	 * Method that get route end hour
	 * @return endHour
	 */
	public int getEndHour() {
		return endHour;
	}

	/**
	 * Method that set route end hour
	 * @param endHour
	 */
	public void setEndHour(int endHour) {
		this.endHour = endHour;
	}

	/**
	 * Method that get route source station
	 * @return 
	 */
	public Station getSourceStation() {
		return sourceStation;
	}

	/**
	 * Method that set route source station
	 * @param sourceStation
	 */
	public void setSourceStation(Station sourceStation) {
		this.sourceStation = sourceStation;
	}

	/**
	 * Method that get route destination station
	 * @return destStation
	 */
	public Station getDestStation() {
		return destStation;
	}

	/**
	 * Method that set route destination station
	 * @param destStation
	 */
	public void setDestStation(Station destStation) {
		this.destStation = destStation;
	}

	//************************************************************ Methods*********************************************************//

	/**
	 * hash code method
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + routeNumber;
		return result;
	}

	/**
	 * equals method -> check if 2 objects of this class are equal or not
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Route other = (Route) obj;
		if (routeNumber != other.routeNumber)
			return false;
		return true;
	}

	/**
	 * to string method
	 */
	@Override
	public String toString() {
		return "Route : " + routeNumber + " length : " + length + " date : " + date + ", startHour : "
				+ startHour  + "end Hour : "+ endHour + ", source Station : " + sourceStation.getStationName() + "destStation : "
				+ destStation;
	}
	
	
}
