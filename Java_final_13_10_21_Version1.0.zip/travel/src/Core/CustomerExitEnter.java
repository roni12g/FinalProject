package Core;

import java.util.Date;

/**
 * class that represent Customer's Uses In System  
 * @version 1.0 
 * @project - Final Project 2021  
 * @Date 07.09.2021
 */
public class CustomerExitEnter {

	//************************************************************Class Members*********************************************************//

	/**
	 * customer's enter/exit id number varibale
	 */
	private int custEnterExitId;
	
	/**
	 * customer variable
	 */
	private Customer customer;
	
	/**
	 * station stop in variable
	 */
	private StopsIn stopsIn;
	
	/**
	 * date variable
	 */
	private Date date;
	
	/**
	 * hour variable
	 */
	private int hour;
	
	/**
	 * minute variable
	 */
	private int minute;
	
	/**
	 * exit/enter variable
	 */
	private boolean exit_enter;
	
	//************************************************************Constructor*********************************************************//

	/**
	 * Constructor
	 * @param custEnterExitId
	 * @param customer
	 * @param stopsIn
	 * @param date
	 * @param hour
	 * @param minute
	 * @param exit_enter
	 */
	public CustomerExitEnter(int custEnterExitId, Customer customer, StopsIn stopsIn, Date date, int hour, int minute,boolean exit_enter) {
		this.custEnterExitId = custEnterExitId;
		this.customer = customer;
		this.stopsIn = stopsIn;
		this.date = date;
		this.hour = hour;
		this.minute = minute;
		this.exit_enter = exit_enter;
	}

	//***************************************Getters And Setters*******************************************//

	/**
	 * Method that get customer's enter/exit number
	 * @return custEnterExitId
	 */
	public int getCustEnterExitId() {
		return custEnterExitId;
	}

	/**
	 * Method that set customer's enter/exit number
	 * @param custEnterExitId
	 */
	public void setCustEnterExitId(int custEnterExitId) {
		this.custEnterExitId = custEnterExitId;
	}

	/**
	 * Method that get customer
	 * @return customer
	 */
	public Customer getCustomer() {
		return customer;
	}

	/**
	 * Method that set customer
	 * @param customer
	 */
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	/**
	 * Method that get stop in
	 * @return stopsIn
	 */
	public StopsIn getStopsIn() {
		return stopsIn;
	}

	/**
	 * Method that set stop in
	 * @param stopsIn
	 */
	public void setStopsIn(StopsIn stopsIn) {
		this.stopsIn = stopsIn;
	}

	/**
	 * Method that get date
	 * @return date
	 */
	public Date getDate() {
		return date;
	}

	/**
	 * Method that set date
	 * @param date
	 */
	public void setDate(Date date) {
		this.date = date;
	}

	/**
	 * Method that get hour
	 * @return hour
	 */
	public int getHour() {
		return hour;
	}

	/**
	 * Method that set hour
	 * @param hour
	 */
	public void setHour(int hour) {
		this.hour = hour;
	}

	/**
	 * Method that get minute
	 * @return minute
	 */
	public int getMinute() {
		return minute;
	}

	/**
	 * Method that set minute
	 * @param minute
	 */
	public void setMinute(int minute) {
		this.minute = minute;
	}

	//************************************************************ Methods*********************************************************//

	/**
	 * hash code method
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + custEnterExitId;
		return result;
	}

	/**
	 * 
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CustomerExitEnter other = (CustomerExitEnter) obj;
		if (custEnterExitId != other.custEnterExitId)
			return false;
		return true;
	}

	/**
	 * to string method
	 */
	@Override
	public String toString() {
		String exit = "Enter";
		if(!exit_enter) 
			exit="Exit";
		
		return "customer : " + customer.getId() + ", exit ? : "
				+ exit +"Station : "+stopsIn.getStation().getStationName()+", date : " + date + ", hour : " + hour + ", minute : " + minute;
	}
	
	
	
}

