package Core;

import java.util.Date;
/**
 * class that represent Manager In System  
 * @version 1.0 
 * @project - Final Project 2021  
 * @Date 07.09.2021
 */
public class Csr extends SystemUser {

	//************************************************************Class Members*********************************************************//

	/**
	 * start working date variable
	 */
	private Date StartWorkingDate;

	
	//************************************************************Constructor*********************************************************//

	/**
	 * Constructor
	 * @param id
	 * @param fName
	 * @param lNamge
	 * @param email
	 * @param bDate
	 * @param password
	 * @param phone
	 * @param StartWorkingDate
	 */
	public Csr(String id, String fName, String lNamge, String email, Date bDate, String password, String phone, Date StartWorkingDate) {
		super(id, fName, lNamge, email, bDate, password, phone);
		this.StartWorkingDate=StartWorkingDate;
	}

	//***************************************Getters And Setters*******************************************//

	/**
	 * Method that get manager's start working date
	 * @return StartWorkingDate
	 */
	public Date getStartWorkingDate() {
		return StartWorkingDate;
	}

	/**
	 * Method that set manager's start working date
	 * @param startWorkingDate
	 */
	public void setStartWorkingDate(Date startWorkingDate) {
		StartWorkingDate = startWorkingDate;
	}
	
	

	//************************************************************ Methods*********************************************************//

	/**
	 * to string method
	 */
	@Override
	public String toString() {
		return "Csr Start Working Date : " + StartWorkingDate +" "+super.toString();
	}
}
