package Core;

import Utils.E_LineColor;
/**
 * class that represent Line  
 * @version 1.0 
 * @project - Final Project 2021  
 * @Date 07.09.2021
 */
public class Line {

	//************************************************************Class Members*********************************************************//

	/**
	 * line's color variable
	 */
	private E_LineColor color;
	
	/**
	 * station number variable
	 */
	private int stationSum ;
	
	//************************************************************Constructor*********************************************************//

	/**
	 * Constructor
	 * @param color
	 * @param stationSum
	 */
	public Line(E_LineColor color, int stationSum) {
		this.color = color;
		this.stationSum = stationSum;
	}

	//***************************************Getters And Setters*******************************************//

	/**
	 * Method that get line's color
	 * @return
	 */
	public E_LineColor getColor() {
		return color;
	}

	/**
	 * Method that set line's color
	 * @param color
	 */
	public void setColor(E_LineColor color) {
		this.color = color;
	}

	/**
	 * Method that get line's # of stations
	 * @return stationSum
	 */
	public int getStationSum() {
		return stationSum;
	}

	/**
	 * Method that set line's # of stations
	 * @param stationSum
	 */
	public void setStationSum(int stationSum) {
		this.stationSum = stationSum;
	}

	//************************************************************ Methods*********************************************************//

	/**
	 * hash code method
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((color == null) ? 0 : color.hashCode());
		return result;
	}

	/**
	 * equals method -> check if 2 objects of this class are equal or not
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Line other = (Line) obj;
		if (color != other.color)
			return false;
		return true;
	}

	/**
	 * to string method
	 */
	@Override
	public String toString() {
		return "Line : " + color + ", station Sum : " + stationSum;
	}
}
