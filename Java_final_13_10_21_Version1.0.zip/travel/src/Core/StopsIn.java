package Core;

import java.util.Date;

/**
 * class that represent train stops in system  
 * @version 1.0 
 * @project - Final Project 2021  
 * @Date 07.09.2021
 */
public class StopsIn {

	//************************************************************Class Members*********************************************************//

	/**
	 * stops in id variable
	 */
	private int stopsInId;

	/**
	 * train variable
	 */
	private Train train;
	
	/**
	 * station variable
	 */
	private Station station;
	
	/**
	 * date variable
	 */
	private Date date;
	
	/**
	 * hour variable
	 */
	private int hour;
	
	/**
	 * minute variable
	 */
	private int minute;
	
	/**
	 * passengers # in train variable
	 */
	private int passengersInTrain;

	
	//************************************************************Constructor*********************************************************//
	/**
	 * Constructor
	 * @param stopsInId
	 * @param train
	 * @param station
	 * @param date
	 * @param hour
	 * @param minute
	 * @param passengersInTrain
	 */
	public StopsIn(int stopsInId, Train train, Station station, Date date, int hour, int minute,
			int passengersInTrain) {
		
		this.stopsInId = stopsInId;
		this.train = train;
		this.station = station;
		this.date = date;
		this.hour = hour;
		this.minute = minute;
		this.passengersInTrain = passengersInTrain;
	}
	
	
	/**
	 * Method that get train 
	 * @return train
	 */
	public Train getTrain() {
		return train;
	}

	/**
	 * Method that set train
	 * @param train
	 */
	public void setTrain(Train train) {
		this.train = train;
	}

	/**
	 * Method that get station
	 * @return station
	 */
	public Station getStation() {
		return station;
	}

	/**
	 * Method that set station
	 * @param station
	 */
	public void setStation(Station station) {
		this.station = station;
	}

	/**
	 * Method that get date
	 * @return date
	 */
	public Date getDate() {
		return date;
	}

	/**
	 * Method that set date
	 * @param date
	 */
	public void setDate(Date date) {
		this.date = date;
	}

	/**
	 * Method that get hour
	 * @return hour
	 */
	public int getHour() {
		return hour;
	}

	/**
	 * Method that set hour
	 * @param hour
	 */
	public void setHour(int hour) {
		this.hour = hour;
	}

	/**
	 * Method that get minute
	 * @return minute
	 */
	public int getMinute() {
		return minute;
	}

	/**
	 * Method that set minute
	 * @param minute
	 */
	public void setMinute(int minute) {
		this.minute = minute;
	}

	/**
	 * Method that get # of passengers in train
	 * @return passengersInTrain
	 */
	public int getPassengersInTrain() {
		return passengersInTrain;
	}

	/**
	 * Method that set # of passengers in train
	 * @param passengersInTrain
	 */
	public void setPassengersInTrain(int passengersInTrain) {
		this.passengersInTrain = passengersInTrain;
	}

	/**
	 * Method that get stops in id number
	 * @return stopsInId
	 */
	public int getStopsInId() {
		return stopsInId;
	}

	/**
	 * Method that set stops in id number
	 * @param stopsInId
	 */
	public void setStopsInId(int stopsInId) {
		this.stopsInId = stopsInId;
	}


	//************************************************************ Methods*********************************************************//


	/**
	 * hash code method
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + stopsInId;
		return result;
	}



	/**
	 * equals method -> check if 2 objects of this class are equal or not
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		StopsIn other = (StopsIn) obj;
		if (stopsInId != other.stopsInId)
			return false;
		return true;
	}



	/**
	 * to string method
	 */
	@Override
	public String toString() {
		return "StopsIn : "+ stopsInId + ", train : " + train.getTrainNumber() + ", station : " + station.getStationName() + ", date : " + date
				+ ", hour : " + hour + ", minute : " + minute + ", passengers In Train : " + passengersInTrain;
	}
	
	
	
	
}
