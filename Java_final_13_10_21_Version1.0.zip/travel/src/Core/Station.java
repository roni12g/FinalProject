package Core;

import java.util.ArrayList;

import Utils.Constants;
/**
 * class that represent station in system  
 * @version 1.0 
 * @project - Final Project 2021  
 * @Date 07.09.2021
 */
public class Station {

	//************************************************************Class Members*********************************************************//

	/**
	 * station name variable
	 */
	private String stationName;

	/**
	 * station number variable
	 */
	private int stationNumber;

	/**
	 * junction variable
	 */
	private boolean junction;

	/**
	 * lines arrayList variable
	 */
	private ArrayList<Line>lines;

	/**
	 * city variable
	 */
	private String city;
	
	//************************************************************Constructor*********************************************************//

	/**
	 * Constructor
	 * @param stationNumber
	 * @param stationName
	 * @param junction
	 * @param city
	 */
	public Station(int stationNumber, String stationName, boolean junction, String city) {
		this.stationNumber = stationNumber;
		this.stationName = stationName;
		this.junction = junction;
		this.city = city;
		this.lines = new ArrayList<Line>(2);
	}
	
	//***************************************Getters And Setters*******************************************//

	/**
	 *  Method that get station number
	 * @return stationNumber
	 */
	public int getStationNumber() {
		return stationNumber;
	}

	/**
	 *  Method that set station number
	 * @param stationNumber
	 */
	public void setStationNumber(int stationNumber) {
		this.stationNumber = stationNumber;
	}

	/**
	 *  Method that get station name
	 * @return stationName
	 */
	public String getStationName() {
		return stationName;
	}

	/**
	 * Method that set station name
	 * @param stationName
	 */
	public void setStationName(String stationName) {
		this.stationName = stationName;
	}

	/**
	 * Method that return if station is junction station
	 * @return junction
	 */
	public boolean isJunction() {
		return junction;
	}

	/**
	 * Method that set if station is junction station
	 * @param junction
	 */
	public void setJunction(boolean junction) {
		this.junction = junction;
	}

	/**
	 * Method that get lines of station
	 * @return lines
	 */
	public ArrayList<Line> getLines() {
		return lines;
	}

	/**
	 * Method that set lines of station
	 * @param lines
	 */
	public void setLines(ArrayList<Line> lines) {
		this.lines = lines;
	}

	/**
	 * Method that get station's city
	 * @return city
	 */
	public String getCity() {
		return city;
	}

	/**
	 * Method that set station's city
	 * @param city
	 */
	public void setCity(String city) {
		this.city = city;
	}


	//************************************************************ Methods*********************************************************//


	/**
	 * hash code method
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((stationName == null) ? 0 : stationName.hashCode());
		return result;
	}

	/**
	 * equals method -> check if 2 objects of this class are equal or not
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Station other = (Station) obj;
		if (stationName == null) {
			if (other.stationName != null)
				return false;
		} else if (!stationName.equals(other.stationName))
			return false;
		return true;
	}

	/**
	 * to string method
	 */
	@Override
	public String toString() {
		String junctionVal = "Yes";
		if(!this.junction)
			junctionVal="No";
		return "Station :  "+stationNumber + ", stationName : " + stationName + ", junction : " + junctionVal+", city : " + city;
	}

	/**
	 * Method that add line to station
	 * max 2 line for station
	 * @param l
	 * @return
	 */
	public boolean addLine(Line l) {
		if(l!=null) {
			//add line to station that didn't reach max stations #
			if(this.lines.size()==Constants.stationsNumber) {
				return false;
			}
			if(!this.lines.contains(l)) {
				return this.lines.add(l);
			}
		}
		return false;
	}

	/**
	 * Method that remove line from station
	 * @param l
	 * @return
	 */
	public boolean removeLine(Line l) {
		if(l!=null) {
			//check if there is lines connected to station 
			if(this.lines.size()==0)
				return false;
			else {
				//remove line from station
				return this.lines.remove(l);
			}
		}
		return false;
	}



}
