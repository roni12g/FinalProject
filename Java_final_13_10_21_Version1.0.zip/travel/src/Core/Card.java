package Core;

import java.util.Date;
/**
 * class that represent Card For Sysetem Uses  
 * @version 1.0 
 * @project - Final Project 2021  
 * @Date 07.09.2021
 */
public class Card {

	//************************************************************Class Members*********************************************************//

	/**
	 * card number variable
	 */
	private int cardNumber;
	
	/**
	 * money amount number variable
	 */
	private double moneyAmount;
	
	/**
	 * join date variable 
	 */
	private Date joinDate;
	
	/**
	 * count variable
	 */
	private static int count=0;

	
	//************************************************************Constructor*********************************************************//


	/**
	 * Constructor
	 * @param cardNumber
	 * @param moneyAmount
	 * @param joinDate
	 */
	public Card(int cardNumber, double moneyAmount, Date joinDate) {
		super();
		this.cardNumber = cardNumber;
		this.moneyAmount = moneyAmount;
		this.joinDate = joinDate;
	}

	//***************************************Getters And Setters*******************************************//

	/**
	 * Method that get card's money amount
	 * @return moneyAmount
	 */
	public double getMoneyAmount() {
		return moneyAmount;
	}

	/**
	 * Method that set card's money amount
	 * @param moneyAmount
	 */
	public void setMoneyAmount(double moneyAmount) {
		this.moneyAmount = moneyAmount;
	}

	/**
	 * Method that get card's join date
	 * @return joinDate
	 */
	public Date getJoinDate() {
		return joinDate;
	}

	/**
	 * Method that set card's join date
	 * @param joinDate
	 */
	public void setJoinDate(Date joinDate) {
		this.joinDate = joinDate;
	}

	/**
	 * Method that get card's number
	 * @return cardNumber
	 */
	public int getCardNumber() {
		return cardNumber;
	}

	//************************************************************ Methods*********************************************************//

	/**
	 * hash code method
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + cardNumber;
		return result;
	}

	/**
	 * equals method -> check if 2 objects of this class are equal or not
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Card other = (Card) obj;
		if (cardNumber != other.cardNumber)
			return false;
		return true;
	}

	/**
	 * to string method
	 */
	@Override
	public String toString() {
		return "Card : "+ cardNumber + " ,money amount : " + moneyAmount + " ,join dat : " + joinDate;
	}
	
	
}
