package Core;

import java.util.Date;
import java.util.Objects;

/**
 * Class that represent notifications in system
 * @version 1.0 
 * @project - Final Project 2021  
 * @Date 07.09.2021
 */
public  class Notifacation{

	//************************************************************Class Members*********************************************************//

	/**
	 * 
	 */
	private int id;
	
	/**
	 * 
	 */
	private String details;
	
	/**
	 * 
	 */
	private Date notifyDate;
	
	/**
	 * 
	 */
	private boolean active;

	//************************************************************Constructor*********************************************************//

	
	/**
	 * 
	 * @param id
	 * @param details
	 * @param notifyDate
	 * @param active
	 */
	public Notifacation(int id, String details, Date notifyDate, boolean active) {
		this.id = id;
		this.details = details;
		this.notifyDate = notifyDate;
		this.active = active;
	}

	
	
	//***************************************Getters And Setters*******************************************//

	/**
	 * Method that get notification id number
	 * @return id
	 */
	public int getId() {
		return id;
	}


	/**
	 * Method that set notification id number
	 * @param id
	 */
	public void setId(int id) {
		this.id = id;
	}


	/**
	 * Method that get notification details
	 * @return details
	 */
	public String getDetails() {
		return details;
	}


	/**
	 * Method that set notification details
	 * @param details
	 */
	public void setDetails(String details) {
		this.details = details;
	}


	/**
	 * Method that get notification date
	 * @return notifyDate
	 */
	public Date getNotifyDate() {
		return notifyDate;
	}


	/**
	 * Method that set notification date
	 * @param notifyDate
	 */
	public void setNotifyDate(Date notifyDate) {
		this.notifyDate = notifyDate;
	}


	/**
	 * Method that return if notification is active
	 * @return active
	 */
	public boolean isActive() {
		return active;
	}


	/**
	 * Method that set if notification is active
	 * @param active
	 */
	public void setActive(boolean active) {
		this.active = active;
	}

	//************************************************************ Methods*********************************************************//

	/**
	 * hash code method
	 */
	@Override
	public int hashCode() {
		return Objects.hash(id);
	}

	/**
	 * equals method -> check if 2 objects of this class are equal or not
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Notifacation other = (Notifacation) obj;
		return id == other.id;
	}

	/**
	 * to string method
	 */
	@Override
	public String toString() {
		return "TableData [id=" + id + ", details=" + details + ", notifyDate=" + notifyDate + ", active=" + active
				+ "]";
	}
	
}
