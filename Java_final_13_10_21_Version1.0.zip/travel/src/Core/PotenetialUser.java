package Core;

/**
 * class that represent potential user in system  
 * @version 1.0 
 * @project - Final Project 2021  
 * @Date 07.09.2021
 */
public class PotenetialUser {

	//************************************************************Class Members*********************************************************//

	/**
	 * potential customer id number(automatic number) variable
	 */
	private int number;
	
	/**
	 * counter variable
	 */
	private static int count=0;
	
	//************************************************************Constructor*********************************************************//

	/**
	 * Constructor
	 */
	public PotenetialUser() {
		this.number = ++count;
	}

	//***************************************Getters And Setters*******************************************//

	/**
	 * Method that get potential customer's id number
	 * @return number
	 */
	public int getNumber() {
		return number;
	}

	//************************************************************ Methods*********************************************************//

	/**
	 * hash code method
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + number;
		return result;
	}

	/**
	 * equals method -> check if 2 objects of this class are equal or not
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PotenetialUser other = (PotenetialUser) obj;
		if (number != other.number)
			return false;
		return true;
	}

	/**
	 * to string method
	 */
	@Override
	public String toString() {
		return "Potenetial User" + number;
	}
	
	
	
}
