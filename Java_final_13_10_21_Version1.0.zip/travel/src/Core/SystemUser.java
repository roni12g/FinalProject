package Core;

import java.util.Date;

/**
 * class that represent System User  
 * @version 1.0 
 * @project - Final Project 2021  
 * @Date 07.09.2021
 */
public class SystemUser {

	//************************************************************Class Members*********************************************************//

	/**
	 * id number variable
	 */
	private String id;
	
	/**
	 * first name variable
	 */	
	private String fName;
	
	/**
	 * last name variable
	 */
	private String lName;
	
	/**
	 * email variable
	 */
	private String email;
	
	/**
	 * birth date variable
	 */
	private Date bDate;
	
	/**
	 * password variable
	 */
	private String password;
		
	/**
	 * phone number variable
	 */
	private String phone;
	
	//************************************************************Constructor*********************************************************//

	/**
	 * Constructor
	 * @param id
	 * @param fName
	 * @param lName
	 * @param email
	 * @param bDate
	 * @param password
	 * @param phone
	 */
	public SystemUser(String id,String fName, String lName, String email, Date bDate, String password, String phone) {
		this.id=id;
		this.fName = fName;
		this.lName = lName;
		this.email = email;
		this.bDate = bDate;
		this.password = password;
		this.phone = phone;
	}

	//***************************************Getters And Setters*******************************************//

	/**
	 * Method that get id number
	 * @return id
	 */
	public String getId() {
		return id;
	}

	/**
	 * Method that set id number
	 * @param id
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * Method that get first name
	 * @return fName
	 */
	public String getfName() {
		return fName;
	}

	/**
	 * Method that set first name
	 * @param fName
	 */
	public void setfName(String fName) {
		this.fName = fName;
	}

	/**
	 * Method that get last name
	 * @return lName
	 */
	public String getlName() {
		return lName;
	}

	/**
	 * Method that set last name
	 * @param lName
	 */
	public void setlName(String lName) {
		this.lName = lName;
	}

	/**
	 * Method that get email
	 * @return email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * Method that set email
	 * @param email
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * Method that get birth date
	 * @return bDate
	 */
	public Date getbDate() {
		return bDate;
	}

	/**
	 * Method that set birth date
	 * @param bDate
	 */
	public void setbDate(Date bDate) {
		this.bDate = bDate;
	}

	/**
	 * Method that get password
	 * @return password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * Method that set password
	 * @param password
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * Method that get phone number
	 * @return phone
	 */
	public String getPhone() {
		return phone;
	}

	/**
	 * Method that set phone number
	 * @param phone
	 */
	public void setPhone(String phone) {
		this.phone = phone;
	}

	//************************************************************ Methods*********************************************************//

	/**
	 * hash code method
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	/**
	 * equals method -> check if 2 objects of this class are equal or not
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SystemUser other = (SystemUser) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

	/**
	 * to string method
	 */
	@Override
	public String toString() {
		return "id : " + id + ", first name : " + fName + ", last name : " + lName + ", email : " + email + ", birth date="
				+ bDate + ", password : " + password + ", phone : " + phone;
	}
	
	
}
