package ExcelObjects;

import java.util.Date;
import java.util.Objects;

/**
 * class that represent Objects In Excel Export File For Customers Searches In System  
 * @version 1.0 
 * @project - Final Project 2021  
 * @Date 07.09.2021
 */
public class ExcelReportCustSearches {

	//************************************************************Class Members*********************************************************//

	/**
	 * customer's id number variable
	 */
	private String id ;
	
	/**
	 * date variable
	 */
	private Date custDate ;
	
	/**
	 * hour variable
	 */
	private int custHour;
	
	/**
	 * minute variable
	 */
	private float custMinute;
	
	/**
	 * route source station name variable
	 */
	private String sourceStationName;
	
	/**
	 * route destination station name variable
	 */
	private String destStationName;
	
	/**
	 * route source station name city variable
	 */
	private String sourceStationNameCity;
	
	/**
	 * route destination station name city variable
	 */
	private String destinationStationNameCity;
	
	/**
	 * route search covid-19 variable
	 */
	private int covid;

	/**
	 * route search train load variable
	 */
	private float load;

	
	//************************************************************Constructor*********************************************************//

	/**
	 * Constructor
	 * @param id
	 * @param custDate
	 * @param custHour
	 * @param custMinute
	 * @param sourceStationName
	 * @param destStationName
	 * @param sourceStationNameCity
	 * @param destinationStationNameCity
	 * @param covid
	 * @param load
	 */
	public ExcelReportCustSearches(String id, Date custDate, int custHour, float custMinute, String sourceStationName,
			String destStationName, String sourceStationNameCity, String destinationStationNameCity, int covid,
			float load) {
		this.id = id;
		this.custDate = custDate;
		this.custHour = custHour;
		this.custMinute = custMinute;
		this.sourceStationName = sourceStationName;
		this.destStationName = destStationName;
		this.sourceStationNameCity = sourceStationNameCity;
		this.destinationStationNameCity = destinationStationNameCity;
		this.covid = covid;
		this.load = load;
	}
	//***************************************Getters And Setters*******************************************//

	/**
	 * Method that get customer's id number
	 * @return id
	 */
	public String getId() {
		return id;
	}

	/**
	 * Method that set customer's id number
	 * @param id
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * Method that get customer's search date
	 * @return custDate
	 */
	public Date getCustDate() {
		return custDate;
	}

	/**
	 * Method that set customer's search date
	 * @param custDate
	 */
	public void setCustDate(Date custDate) {
		this.custDate = custDate;
	}

	/**
	 * Method that get customer's search hour
	 * @return custHour
	 */
	public int getCustHour() {
		return custHour;
	}

	/**
	 * Method that set customer's search hour
	 * @param custHour
	 */
	public void setCustHour(int custHour) {
		this.custHour = custHour;
	}

	/**
	 * Method that get customer's search minute
	 * @return custMinute
	 */
	public float getCustMinute() {
		return custMinute;
	}

	/**
	 * Method that set customer's search minute
	 * @param custMinute
	 */
	public void setCustMinute(float custMinute) {
		this.custMinute = custMinute;
	}

	/**
	 * Method that get search source station 
	 * @return sourceStationName
	 */
	public String getSourceStationName() {
		return sourceStationName;
	}

	/**
	 * Method that set search source station name
	 * @param sourceStationName
	 */
	public void setSourceStationName(String sourceStationName) {
		this.sourceStationName = sourceStationName;
	}

	/**
	 * Method that get search destination station name
	 * @return destStationName
	 */
	public String getDestStationName() {
		return destStationName;
	}

	/**
	 * Method that set search destination station name
	 * @param destStationName
	 */
	public void setDestStationName(String destStationName) {
		this.destStationName = destStationName;
	}

	/**
	 * Method that get search source station city 
	 * @return sourceStationNameCity
	 */
	public String getSourceStationNameCity() {
		return sourceStationNameCity;
	}

	/**
	 * Method that set search source station city
	 * @param sourceStationNameCity
	 */
	public void setSourceStationNameCity(String sourceStationNameCity) {
		this.sourceStationNameCity = sourceStationNameCity;
	}

	/**
	 * Method that get search destination station city
	 * @return destinationStationNameCity
	 */
	public String getDestinationStationNameCity() {
		return destinationStationNameCity;
	}

	/**
	 * Method that set search destination station city
	 * @param destinationStationNameCity
	 */
	public void setDestinationStationNameCity(String destinationStationNameCity) {
		this.destinationStationNameCity = destinationStationNameCity;
	}

	/**
	 * Method that get search covid-19 value
	 * @return covid
	 */
	public int getCovid() {
		return covid;
	}

	/**
	 * Method that set search covid-19 value
	 * @param covid
	 */
	public void setCovid(int covid) {
		this.covid = covid;
	}

	/**
	 * Method that get search train load value
	 * @return load
	 */
	public float getLoad() {
		return load;
	}

	/**
	 * Method that set search train load value
	 * @param load load
	 */
	public void setLoad(float load) {
		this.load = load;
	}
	
	//************************************************************ Methods*********************************************************//

	/**
	 * hash code method
	 */
	@Override
	public int hashCode() {
		return Objects.hash(custDate, custHour, custMinute, destStationName, id, sourceStationName);
	}

	/**
	 * equals method -> check if 2 objects of this class are equal or not
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ExcelReportCustSearches other = (ExcelReportCustSearches) obj;
		return Objects.equals(custDate, other.custDate) && custHour == other.custHour
				&& Float.floatToIntBits(custMinute) == Float.floatToIntBits(other.custMinute)
				&& Objects.equals(destStationName, other.destStationName) && Objects.equals(id, other.id)
				&& Objects.equals(sourceStationName, other.sourceStationName);
	}

	/**
	 * to string method
	 */
	@Override
	public String toString() {
		return "ExcelReportCustSearches [id=" + id + ", custDate=" + custDate + ", custHour=" + custHour
				+ ", custMinute=" + custMinute + ", sourceStationName=" + sourceStationName + ", destStationName="
				+ destStationName + ", sourceStationNameCity=" + sourceStationNameCity + ", destinationStationNameCity="
				+ destinationStationNameCity + ", covid=" + covid + ", load=" + load + "]";
	}


	
}
