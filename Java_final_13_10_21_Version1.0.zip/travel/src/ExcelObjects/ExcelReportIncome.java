package ExcelObjects;

import java.util.Date;
import java.util.Objects;
/**
 * class that represent Objects In Excel Export File For Customers Uses For Income In System  
 * @version 1.0 
 * @project - Final Project 2021  
 * @Date 07.09.2021
 */
public class ExcelReportIncome {

	//************************************************************Class Members*********************************************************//

	/**
	 * customer's enter/exit id number variable
	 */
	private int custEnterExitId;

	/**
	 * customer's id number variable
	 */
	private int id;

	/**
	 * stop's enter/exit id number variable
	 */
	private int stopsInId;

	/**
	 * date variable
	 */
	private Date exitEnterDate;

	/**
	 * hour variable
	 */
	private int exitEnterHour;

	/**
	 * minute variable
	 */
	private float exitEnterMinute;

	/**
	 * exit/enter variable
	 */
	private boolean exitEnter;

	/**
	 * route's start station variable
	 */
	private	String startStation ;

	/**
	 * route's end station variable
	 */
	private String endStation ;

	/**
	 * route's train number variable
	 */
	private int trainNumber;

	/**
	 * station's load value variable
	 */
	private float loadParameter;

	/**
	 * station's covid-19 value variable
	 */
	private int covid19InOut;

	/**
	 * route's direction variable
	 */
	private int direction ;

	/**
	 * route's from city variable
	 */
	private String fromCity;

	/**
	 * route's to city variable
	 */
	private String toCity;

	/**
	 * route's current station name variable(customer exit/enter from this station)
	 */
	private String stationName;

	/**
	 * route's price
	 */
	private double price;

	//************************************************************Constructor*********************************************************//

	/**
	 * Constructor
	 * @param custEnterExitId
	 * @param id
	 * @param stopsInId
	 * @param exitEnterDate
	 * @param exitEnterHour
	 * @param exitEnterMinute
	 * @param exitEnter
	 * @param startStation
	 * @param endStation
	 * @param trainNumber
	 * @param loadParameter
	 * @param covid19InOut
	 * @param direction
	 * @param fromCity
	 * @param toCity
	 * @param stationName
	 * @param price
	 */
	public ExcelReportIncome(int custEnterExitId, int id, int stopsInId, Date exitEnterDate, int exitEnterHour,
			float exitEnterMinute, boolean exitEnter, String startStation, String endStation, int trainNumber,
			float loadParameter, int covid19InOut, int direction, String fromCity, String toCity, String stationName,
			double price) {

		this.custEnterExitId = custEnterExitId;
		this.id = id;
		this.stopsInId = stopsInId;
		this.exitEnterDate = exitEnterDate;
		this.exitEnterHour = exitEnterHour;
		this.exitEnterMinute = exitEnterMinute;
		this.exitEnter = exitEnter;
		this.startStation = startStation;
		this.endStation = endStation;
		this.trainNumber = trainNumber;
		this.loadParameter = loadParameter;
		this.covid19InOut = covid19InOut;
		this.direction = direction;
		this.fromCity = fromCity;
		this.toCity = toCity;
		this.stationName = stationName;
		this.price = price;
	}

	//***************************************Getters And Setters*******************************************//

	/**
	 * Method that get customer's exit/enter id number
	 * @return custEnterExitId
	 */
	public int getCustEnterExitId() {
		return custEnterExitId;
	}

	/**
	 * Method that set customer's exit/enter id number
	 * @param custEnterExitId
	 */
	public void setCustEnterExitId(int custEnterExitId) {
		this.custEnterExitId = custEnterExitId;
	}

	/**
	 * Method that get customer's in id number
	 * @return id
	 */
	public int getId() {
		return id;
	}

	/**
	 * Method that set customer's id number
	 * @param id
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * Method that get stop in id number
	 * @return stopsInId
	 */
	public int getStopsInId() {
		return stopsInId;
	}

	/**
	 * Method that set stop in id number
	 * @param stopsInId
	 */
	public void setStopsInId(int stopsInId) {
		this.stopsInId = stopsInId;
	}

	/**
	 * Method that get exit/enter date
	 * @return exitEnterDate
	 */
	public Date getExitEnterDate() {
		return exitEnterDate;
	}

	/**
	 * Method that set exit/enter date
	 * @param exitEnterDate
	 */
	public void setExitEnterDate(Date exitEnterDate) {
		this.exitEnterDate = exitEnterDate;
	}

	/**
	 * Method that get exit/enter hour
	 * @return exitEnterHour
	 */
	public int getExitEnterHour() {
		return exitEnterHour;
	}

	/**
	 * Method that set exit/enter hour
	 * @param exitEnterHour
	 */
	public void setExitEnterHour(int exitEnterHour) {
		this.exitEnterHour = exitEnterHour;
	}

	/**
	 * Method that get exit/enter minute
	 * @return exitEnterMinute
	 */
	public float getExitEnterMinute() {
		return exitEnterMinute;
	}

	/**
	 * Method that set exit/enter minute
	 * @param exitEnterMinute
	 */
	public void setExitEnterMinute(float exitEnterMinute) {
		this.exitEnterMinute = exitEnterMinute;
	}

	/**
	 * Method that return if customer exit/enter
	 * @return exitEnter
	 */
	public boolean isExitEnter() {
		return exitEnter;
	}

	/**
	 * Method that set if customer exit/enter
	 * @param exitEnter
	 */
	public void setExitEnter(boolean exitEnter) {
		this.exitEnter = exitEnter;
	}

	/**
	 * Method that get start station
	 * @return startStation
	 */
	public String getStartStation() {
		return startStation;
	}

	/**
	 * Method that set start station
	 * @param startStation
	 */
	public void setStartStation(String startStation) {
		this.startStation = startStation;
	}

	/**
	 * Method that get end station
	 * @return endStation
	 */
	public String getEndStation() {
		return endStation;
	}

	/**
	 * Method that set end station
	 * @param endStation
	 */
	public void setEndStation(String endStation) {
		this.endStation = endStation;
	}

	/**
	 * Method that get start station
	 * @return trainNumber
	 */
	public int getTrainNumber() {
		return trainNumber;
	}

	/**
	 * Method that set start station
	 * @param trainNumber
	 */
	public void setTrainNumber(int trainNumber) {
		this.trainNumber = trainNumber;
	}

	/**
	 * Method that get train load value
	 * @return loadParameter
	 */
	public float getLoadParameter() {
		return loadParameter;
	}

	/**
	 * Method that set train load value
	 * @param loadParameter
	 */
	public void setLoadParameter(float loadParameter) {
		this.loadParameter = loadParameter;
	}

	/**
	 * Method that get train covid-19 value
	 * @return covid19InOut
	 */ 
	public int getCovid19InOut() {
		return covid19InOut;
	}

	/**
	 * Method that set train covid-19 value
	 * @param covid19InOut
	 */
	public void setCovid19InOut(int covid19InOut) {
		this.covid19InOut = covid19InOut;
	}

	/**
	 * Method that get train direction
	 * @return direction
	 */
	public int getDirection() {
		return direction;
	}

	/**
	 * Method that set train direction
	 * @param direction
	 */
	public void setDirection(int direction) {
		this.direction = direction;
	}

	/**
	 * Method that get from city name
	 * @return fromCity
	 */
	public String getFromCity() {
		return fromCity;
	}

	/**
	 * Method that set from city name
	 * @param fromCity
	 */
	public void setFromCity(String fromCity) {
		this.fromCity = fromCity;
	}

	/**
	 * Method that get to city name
	 * @return toCity
	 */
	public String getToCity() {
		return toCity;
	}

	/**
	 * Method that set to city name
	 * @param toCity
	 */
	public void setToCity(String toCity) {
		this.toCity = toCity;
	}

	/**
	 * Method that get station name(current station customer exit/enter to train)
	 * @return stationName
	 */
	public String getStationName() {
		return stationName;
	}

	/**
	 * Method that set station name(current station customer exit/enter to train)
	 * @param stationName
	 */
	public void setStationName(String stationName) {
		this.stationName = stationName;
	}

	/**
	 * Method that get route price
	 * @return price
	 */
	public double getPrice() {
		return price;
	}

	/**
	 * Method that set route price
	 * @param price
	 */
	public void setPrice(double price) {
		this.price = price;
	}

	//************************************************************ Methods*********************************************************//

	/**
	 * hash code method
	 */
	@Override
	public int hashCode() {
		return Objects.hash(exitEnterDate, exitEnterHour, exitEnterMinute, id);
	}

	/**
	 * equals method -> check if 2 objects of this class are equal or not
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ExcelReportIncome other = (ExcelReportIncome) obj;
		return Objects.equals(exitEnterDate, other.exitEnterDate) && exitEnterHour == other.exitEnterHour
				&& Float.floatToIntBits(exitEnterMinute) == Float.floatToIntBits(other.exitEnterMinute)
				&& id == other.id;
	}

	/**
	 * to string method
	 */
	@Override
	public String toString() {
		return "ExcelReportIncome [custEnterExitId=" + custEnterExitId + ", id=" + id + ", stopsInId=" + stopsInId
				+ ", exitEnterDate=" + exitEnterDate + ", exitEnterHour=" + exitEnterHour + ", exitEnterMinute="
				+ exitEnterMinute + ", exitEnter=" + exitEnter + ", startStation=" + startStation + ", endStation="
				+ endStation + ", trainNumber=" + trainNumber + ", loadParameter=" + loadParameter + ", covid19InOut="
				+ covid19InOut + ", direction=" + direction + ", fromCity=" + fromCity + ", toCity=" + toCity
				+ ", stationName=" + stationName + ", price=" + price + "]";
	}

}
