<?php 	

    /** 
     * This file contains the "home page"/first page of the registered user
     */

    //Start Session 
    session_start(); 
    
    //Check if session is set, if not:(User is not signed in) -> redirect to index.php
    if(!isset($_SESSION['username']) ){
        session_destroy();    
        header("Location: index.php");
    }

    //If Session is set:---------------------------------
    include 'customer_layout.php';


    ?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Document</title>
    <link rel="stylesheet" href="Styles/customer_page.css">

</head>

<!-- Styling settings -->
<style>
    .user-pic {
        padding: 0px;
    }

    .logo {
        display: block;
        margin-left: auto;
        margin-right: auto;
        text-align: center;
        width: fit-content;
        cursor: pointer;
    }

    .row {
        content: "";
        display: flex;
        clear: both;
        width: 80%;
        text-align: center;
    }

    .column {
        width: auto;
        margin: auto;
    }

    .side-bar {
        float: right;
        width: 25%;
        height: 400px;
        border-left: 1px solid black;
        padding: 0 1em;
    }

    h2 {
        font-size: initial;
    }

    label {
        display: inline-block;
        max-width: 100%;
        margin-bottom: 5px;
        font-weight: 700;
        font-size: 14px;
    }

    .form-group {
        margin-top: 10px;
        margin-bottom: 15px;
    }

    .form-control {
        /* width: 196.8px; */
        padding: 6px 12px;
        font-size: 14px;
        font-family: cursive;
        display: inherit;
        border-radius: 4px;
        border: 1px solid #ccc;
        text-align: center;
        outline: none;
    }

    .form-control:focus {
        border: 1px solid #66afe9;
    }

    input{
        width: 192px;
    }

    .apply_btn {
        color: #fff;
        background-color: #5cb85c;
        border-color: #4cae4c;
        display: inline-block;
        margin-bottom: 0;
        font-weight: 400;
        text-align: center;
        white-space: nowrap;
        vertical-align: middle;
        touch-action: manipulation;
        cursor: pointer;
        background-image: none;
        border: 1px solid transparent;
        padding: 6px 12px;
        font-size: 14px;
        line-height: 1.42857143;
        border-radius: 4px;
        margin-left: 35%;
        font-family: cursive;
    }

    .apply_btn:hover {
        background-color: #4CAF50;
        color: white
    }
</style>

<script>

     /**
     * function which checks if the source station and destination station are identical
     */
    function checkIfSame(){

        // Getting the inserted values of the source station and destination input fields
        var chosen_source_station = document.getElementById('source_station').value;
        var chosen_destination_station = document.getElementById('destination_station').value;

        // Check wether the source station value and destination station value are identical
        if(chosen_source_station == chosen_destination_station){ // If they are the same
            alert("Source Station And Destination station are the same \n Please change one of them."); // Alert the user to change one of these inputs
            return false;
        }

        else{ // Soucre station & destination station are different 
            document.getElementById("form").submit(); // Submit the form to the search algorithm file
        }
    }


        /**
         * function that gets fired by event that returns only numbers input -> disables other characters 
         * @event onclick entering data input in form
         * @param evt 
         * @return boolean
         */
        function onlyNumberKey(evt) {
                
                // Only ASCII character in that range allowed
                var ASCIICode = (evt.which) ? evt.which : evt.keyCode

                // Check if the inserted charcter is a number in ASCII code
                if (ASCIICode > 31 && (ASCIICode < 48 || ASCIICode > 57))
                    return false;
                return true;
        }

        /**
         * function that gets fired by event that returns only letters input -> disables other characters 
         * @event onclick entering data input in form
         * @param evt 
         * @return boolean
         */
        function onlyLettersKey(evt) {
                
                // Only ASCII character in that range allowed
                var ASCIICode = (evt.which) ? evt.which : evt.keyCode

                // Check if the inserted charcter is a letter in ASCII code
                if ((ASCIICode > 64 && ASCIICode < 91) || (ASCIICode > 96 && ASCIICode < 123))
                    return true;
                return false;
        }

</script>






<body>

    <?php

            /**
             * Including/Calling DB connection
             * @return connection
             */
            require 'databaseconnection.php';

            // Initialize stations array
            $stations_array = array();

            /**
             * Query for getting station names and its cities
             */
            $sql = "SELECT stationName, city FROM TblStation order by city";
            $result = sqlsrv_query( $conn , $sql, array(), array("Scrollable" => 'static'));

            if( $result === false  ) {
                die( print_r( sqlsrv_errors(), true));
            }
    
            if( sqlsrv_fetch( $result ) === false) {
                die( print_r( sqlsrv_errors(), true));
            }

            /** 
             * Looping over the result set -> Inserting each row data into the stations array
             * @param stations_array -> array
             * @param selectedItem -> query result row
             */
            while ($selectedItem = sqlsrv_fetch_array($result)) {
                

                // Braeking down the current result set to station name and city
                $station_name = $selectedItem['city'];
                $station_city = $selectedItem['stationName'];
                
                // Conctinating the station name and its city
                $station_details = $station_name.", ".$station_city;
    
                /**
                 * Pushing the new created station details varianle to the station array
                 * @param stations_array
                 * @param station_details
                 */
                array_push($stations_array, $station_details);
            }

            
            $user_id = $_SESSION['username']; // Get users id

            /**
             * Query for getting user's Covid19 & Load Preferences From Registration
             * @param user_id -> Users ID
             */
            $sql = "SELECT covid19Val, loadCust FROM TblCustomer where id=$user_id";
            $result = sqlsrv_query( $conn , $sql, array(), array("Scrollable" => 'static'));
            $users_preferences = sqlsrv_fetch_array($result);

            if( $result === false  ) {
                die( print_r( sqlsrv_errors(), true));
            }
    
            if( sqlsrv_fetch( $result ) === false) {
                die( print_r( sqlsrv_errors(), true));
            }


            // Converting the users_covid19_val parameter from number to string accrodingly
            if($users_preferences[0] >= 0 && $users_preferences[0] <= 0.5 )
                $users_covid19_val = "Covid Free";
            else{
                $users_covid19_val = "Nevermind";
            }

            // Converting the loadParameter parameter from number to string accrodingly
            if($users_preferences[1] >= 0 && $users_preferences[1] <= 0.5)
                $users_load = "Free";
            else{
                $users_load = "Nevermind";

            }
            
            /**
             * Code section for user notifications and updates 
             */

            // Initialize notifications array
            $notifictionDate_array = array();

            /**
             * Query for getting notifications and updates 
             */
            $sql3 = "SELECT*  from TblNotification";
            $result3 = sqlsrv_query( $conn , $sql3, array(), array("Scrollable" => 'static'));

            /** 
             * Looping over the result set -> Inserting each row data into the array
             * @param notifictionDate_array -> array
             * @param selectedItem3 -> query result row
             */
            while ($selectedItem3 = sqlsrv_fetch_array($result3)) {
                array_push($notifictionDate_array, $selectedItem3);
            }
            ?>
      
    <!-- Search Route form which contains 6 inputs -->
    <form action="customerSearch.php" method="post" id="form" style="width: 60%; height: 400px; float:left" onsubmit="return checkIfSame()">

        <input type="hidden" name="text" value="<?php echo $_SESSION['username']; ?>">

        <div class="form-group">
            <div class="row">

                <!-- Code section of of first column -->
                <div class="column">

                    <!-- First input: source station code -->
                    <div class="form-group">
                        <div class="source_datalist">
                            <label> Source Station</label>
                            <!-- <input list="source_station" class="form-control" name="source_station" /> -->
                            <select id="source_station" autocomplete="on" list="source_station" class="form-control" name="source_station" required>
                                <?php     
                                            $former_opt_group = "Bat Yam";
                                            echo "<option> </option>";
        
                                            echo "<optgroup label='{$former_opt_group}'>";
        
                                            foreach ($stations_array as $value) {
                                                $city = explode(",",$value)[0];
                                                echo $city;
                                                $station = end(explode(",",$value));
        
                                                if($city != $former_opt_group){
                                                    echo "</optgroup>";
                                                    $city = explode(",",$value)[0];
                                                    $former_opt_group = $city;
        
                                                    echo "<optgroup label='{$city}'>";
                                                }
        
                                                echo "<option = {$station}> {$station} </option>";
                                            }
                                        
                                        
                                        ?>
                            </select>
                        </div>
                    </div> <!-- End of first input -->

                    <!-- Second input: travel date code -->
                    <div class="form-group">
                        <label for="travelDate"> Travel Date: </label>
                        <input type="date" id="travelDate" class="form-control" name="travelDate"
                            value="<?php echo date('Y-m-d');?>" required min=<?php echo date('Y-m-d');?>
                        >
                    </div><!-- End of second input -->

                    <!-- Third input: load parameter code -->
                    <div class="form-group">
                        <label for="load"> Load: </label>
                        <input list="load_list" id="load" class="form-control" value="<?php echo $users_load; ?>"
                            name="load" pattern="Nevermind|Free" required onkeypress="return onlyLettersKey(event)" >
                        <datalist id="load_list">

                            <option value="Nevermind"> Nevermind </option>
                            <option value="Free"> Free </option>
                        </datalist>

                    </div> <!-- End of second input -->


                </div> <!-- End of fisrt column -->

                <!-- Code section of of second column -->
                <div class="column">

                    <!-- Fourth input: destination code -->
                    <div class="form-group">
                        <label> Destination Station</label>
                        <!-- <input list="destination_station" class="form-control" name="destination_station" /> -->
                        <select id="destination_station" list="destination_station" class="form-control" name="destination_station"
                        autocomplete="on" required>
                            <?php 
                                
                                    $former_opt_group = "Bat Yam";
                                    echo "<option> </option>";

                                    echo "<optgroup label='{$former_opt_group}'>";

                                    foreach ($stations_array as $value) {
                                        $city = explode(",",$value)[0];
                                        echo $city;
                                        $station = end(explode(",",$value));

                                        if($city != $former_opt_group){
                                            echo "</optgroup>";
                                            $city = explode(",",$value)[0];
                                            $former_opt_group = $city;

                                            echo "<optgroup label='{$city}'>";
                                        }

                                        echo "<option = {$station}> {$station} </option>";
                                    }
                                        
                                    ?>
                        </select>
                    </div> <!-- End of fourth input -->

                    <!-- Fifth input: time code -->
                    <div class="form-group">
                        <label for="time"> Time: </label>

                        <input type="time" id="time" class="form-control" name="time" min="07:00" max="22:00" required>
                    </div> <!-- End of fifth input -->

                    <!-- Sixth input: covid19 val code -->
                    <div class="form-group">
                        <label for="covid19Value"> Covid-19: </label>
                        <input list="covid19List" id="covid19Value" class="form-control" value="<?php echo $users_covid19_val; ?>"
                             name="covid19Value"
                             pattern="Nevermind|Covid Free" required onkeypress="return onlyLettersKey(event)" >
                        <datalist id="covid19List">

                            <option value= "Nevermind"> Nevermind </option>
                            <option value= "Covid Free"> Covid Free </option>
                        </datalist>

                    </div> <!-- End of sixth input -->



                </div> <!-- End of fisrt column -->
            </div>
        </div>
        <button class=apply_btn type="submit" id="Create new acc btn">Search</button>

    </form>  <!-- End of fom Code section -->


    <!-- Code section for updates and news slide bar-->
    <div class="side-bar" style="font-size: 12px">
        <h2>Upadates and News:</h2>

        <!-- Side bar settings -->
        <marquee behavior=scroll direction="up" scrollamount="3" onmouseover="this.stop();" onmouseout="this.start()"
            style="height: 85%;">
            <?php     

                
                foreach ($notifictionDate_array as $value) {
                    echo nl2br("{$value['notifyDate']->format('d/m/Y')}: {$value['details']} <br><br><hr><br>"); 
                }
            ?>
        </marquee>
    </div>

</body>

</html>