<?php
	
    /** 
     * This file contains the functionality of changing users password in DB. 
     * Files is reachable from the system an from the email recovery email (after authentication) 
     */

    //Start Session:
    session_start(); 
    
    /**
     * Including/Calling DB connection
     * @return connection
     */
	include 'databaseconnection.php';


    if(!isset($_SESSION['username']) ){ // User came form password recovery email form
        
        // Get form input fields 
        $user_id = $_POST['id_number']; // User id number
        $new_password = $_POST['new_password']; // New Password
        $new_password_copy = $_POST['new_password_copy']; // The repeated password


        /**
         * Query for checking if the inserted id by the user exists 
         * @param user
         */
        $sql = "SELECT id FROM TblSystemUser WHERE id = '$user_id' ";
        $result = sqlsrv_query( $conn , $sql, array(), array("Scrollable" => 'static'));
        
        if( $result === false ) {
            die( print_r( sqlsrv_errors(), true));
        }

        if( sqlsrv_fetch( $result ) === false) {
            die( print_r( sqlsrv_errors(), true));
        }

        if(sqlsrv_num_rows($result) == 1){ // If exactly only one user has been found with the given id

            if(isset($new_password) && isset($new_password_copy) ){// If two password inputs are setted

                if($new_password == $new_password_copy){ // If the password and its repeatment are identical


                    /**
                     * Query for upadting the password in the TblSystemUser DB table 
                     * @param new_password
                     * @param user_id
                     */
                    $sql = "UPDATE TblSystemUser
                            SET pass= $new_password
                            WHERE id = $user_id";

                    $options =  array('Scrollable' => SQLSRV_CURSOR_FORWARD);
                    $result = sqlsrv_query( $conn , $sql);

                    if( $sql ) { // If the query is successful
                        sqlsrv_commit( $conn );  // Commit transaction
                        header("Location: password_change.php?msg=success");
                    } 

                    else { // Query is not successful
                        sqlsrv_rollback( $conn ); //Rollback Database
                        header("Location: password_change.php?msg=failed"); // Redirect and show the user failure alert

                    }

                } 
                     
                else{ // If the password and its repeatment are NOT identical
                    header("Location: password_change.php?msg=failed"); // Redirect and show the user failure alert
                }
            }
        }

        else // If no user has been found with the given id
            header("Location: password_change.php?msg=failed");

    }

    else{ // If user came from password change page (from inside the system)
        
        // include 'customer_layout.php';

        // Get form input fields 
        $user_id = $_SESSION['username'];
        $old_Password = $_POST['old_password'];
        $new_password = $_POST['new_password']; 
        $new_password_copy = $_POST['new_password_copy'];;
        

        // $login_string = hash('sha512', $newUsername . $_SERVER['HTTP_USER_AGENT'] . time());

        /**
         * Query for getting the connected users password from TblSystemUser DB table 
         * @param user_id
         */
        $sql = "SELECT pass FROM TblSystemUser WHERE id = '$user_id' ";
        $result = sqlsrv_query( $conn , $sql, array(), array("Scrollable" => 'static'));
        
        if( $result === false ) {
            die( print_r( sqlsrv_errors(), true));
        }

        if( sqlsrv_fetch( $result ) === false) {
            die( print_r( sqlsrv_errors(), true));
        }

        // Get the query result field
        $actual_password = sqlsrv_get_field( $result, 0);

        if(isset($old_Password) && isset($new_password) && isset($new_password_copy) ){ // If all changing password detials are set

            if($new_password == $new_password_copy){ // If the password and its repeatment are identical

                if($actual_password == $old_Password){ // If actual password and inserted password are identical

                    if(isset($new_password) && isset($new_password_copy)){


                    /**
                     * Query for upadting the password in the TblSystemUser DB table 
                     * @param new_password
                     * @param user_id
                     */
                        $sql = "UPDATE TblSystemUser
                                SET pass= $new_password
                                WHERE id = $user_id";

                        $options =  array('Scrollable' => SQLSRV_CURSOR_FORWARD);
                        $result = sqlsrv_query( $conn , $sql);

                        if( $sql ) {  // If the query is successful
                            sqlsrv_commit( $conn );  // Commit transaction
                            header("Location: password_change.php?msg=success");

                        } 

                        else { // Query is not successful
                            sqlsrv_rollback( $conn ); //Rollback Database
                            header("Location: password_change.php?msg=failed"); // Redirect and show the user failure alert

                            // echo "Didn'y succeed";	
                        }

                    }
                
                    
                }
                
                else{ // Actual password and inserted password are NOT identical

                    $_SESSION["wrong_current_pass"] = "wrong_current_pass"; // Set new variable in the session
                    header("Location: password_change.php?msg=failed"); // Redirect and show the user failure alert
                }
            }
            else{ // The password and its repeatment are NOT identical
                header("Location: password_change.php?msg=not_identical");  // Redirect and show the user failure alert
            }
        }

        else{ // Password changing detials are NOT  set
            header("Location: password_change.php?msg=failed"); // Redirect and show the user failure alert
        }
    }


?>