<?php 	

    /** 
     * This file contains the password recovery email form code of the Hebrew version
     */


    // Calling the Hebrew layout and including it
    include 'index_layout.php';
    
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign in</title>
    <!-- <link rel="stylesheet" href="design.css"> -->
    <link rel="stylesheet" href="Styles/password_recovery.css">

    <!-- Style Settings -->
    <style>
        input,
        label {
            display: block;
            margin: auto;
            width: 50%;
        }

        .sign-in-form {
            border: 3px solid gray;
        }
    </style>
</head>

<body>
    

    <?php 

            /**
             * This code section refers to faulire / success messages
             */
            if (isset($_GET["msg"]) && $_GET["msg"] == 'success') {  // If recovery email successfully sent, show success alert in this page

                // Echo the success alert

                echo"

                <div class='alert alert-success alert-dismissible fade show' role='alert'>
                    <strong>Email message successfully sent!</strong> You should check your inbox/spam.
                    <button type='button class='close' data-dismiss='alert' aria-label='Close'>
                        <span aria-hidden='true'>&times;</span>
                    </button>
                </div> ";
    
            }
            
            if (isset($_GET["msg"]) && $_GET["msg"] == 'failed') {  // If recovery email unsuccessfully sent, show failure alert in this page

                // Echo the failure alert

                echo"

                <div class='alert alert-danger alert-dismissible fade show' role='alert'>
                    <strong>Wrong Email!</strong> Please try again or contact our agancy
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                        <span aria-hidden='true'>&times;</span>
                    </button>
                </div>";
            }
    
    ?>
    

    <div class="sign-in-form">
    <!-- MAILTO:email-address -->

        <!-- Form contains 1 input filed for email address -->
        <form action="password_recovery_mail.php" method="post" >

            <!-- Input field: password recovery -->
            <h2><b> Password Recovery </b></h2>
            <div class="input-group">
                <label for="email-address" class="input-group" id=input-label> רשום את כתובת המייל שאיתה נרשמת למערכת: </label>
                <input type="email" class="input-group" id="input-text" name="email-address" required>
            </div>


            <!-- Foem send button -> action: 'password_recovery_mail' file  -->
            <button class="btn btn-success" name="send_pass_btn" id="send_pass_btn" type="submit"> שלח </button>


        </form>
    </div>

    
</body>

</html>


