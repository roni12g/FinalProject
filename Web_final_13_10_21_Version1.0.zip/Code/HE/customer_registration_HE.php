<?php 

    /** 
     * This file contains the Hebrew version of the the registration form
     */

    // Calling the Hebrew layout and including it
    include 'index_layout.php'; ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Registration Form</title>
</head>

<!-- Styling Settings -->
<style>
    body {
        background-color: #eee;
    }

    .form-control {
        height: 40px;
        box-shadow: none;
        color: #969fa4;
    }

    .form-control:focus {
        border-color: #5cb85c;
    }

    .form-control,
    .btn {
        border-radius: 3px;
    }

    .signup-form {
        width: 1000px;
        margin: 0 auto;
        padding: 30px 0;
    }

    .signup-form h2 {
        color: #636363;
        margin: 0 0 15px;
        position: relative;
        text-align: center;
    }

    .signup-form h2:before,
    .signup-form h2:after {
        content: "";
        height: 2px;
        width: 30%;
        background: #d4d4d4;
        position: absolute;
        top: 50%;
        z-index: 2;
    }

    .signup-form h2:before {
        left: 0;
    }

    .signup-form h2:after {
        right: 0;
    }

    .signup-form .hint-text {
        color: #999;
        margin-bottom: 30px;
        text-align: center;
    }

    .signup-form form {
        color: #999;
        border-radius: 3px;
        margin-bottom: 15px;
        background: #f2f3f7;
        box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
        padding: 30px;
    }

    .signup-form .form-group {
        margin-bottom: 20px;
    }

    .signup-form input[type="checkbox"] {
        margin-top: 3px;
    }

    .signup-form .btn {
        font-size: 16px;
        font-weight: bold;
        min-width: 140px;
        outline: none !important;
    }

    .signup-form a {
        color: #fff;
        text-decoration: underline;
    }

    .signup-form a:hover {
        text-decoration: none;
    }

    .signup-form form a {
        color: #5cb85c;
        text-decoration: none;
    }

    .signup-form form a:hover {
        text-decoration: underline;
    }
</style>
<script>

    /**
     * function that gets fired by event that returns only numbers input -> disables other characters 
     * @event onclick entering data input in form
     * @param evt 
     * @return boolean
     */
    function onlyNumberKey(evt) {

        // Only ASCII character in that range allowed
        var ASCIICode = (evt.which) ? evt.which : evt.keyCode

        // Check if the inserted charcter is a number in ASCII code
        if (ASCIICode > 31 && (ASCIICode < 48 || ASCIICode > 57))
            return false;
        return true;
    }

    /**
     * function that gets fired by event that returns only letters input -> disables other characters 
     * @event onclick entering data input in form
     * @param evt 
     * @return boolean
     */
    function onlyLettersKey(evt) {

        // Only ASCII character in that range allowed
        var ASCIICode = (evt.which) ? evt.which : evt.keyCode

        // Check if the inserted charcter is a letter in ASCII code
        if ((ASCIICode > 64 && ASCIICode < 91) || (ASCIICode > 96 && ASCIICode < 123))
            return true;
        return false;
    }

</script>


<body>
    <div class="signup-form">

        <!-- Sign up form which contains several inputs -->
        <form action="signup.php" method="post">
            <h2>הרשמה</h2>
            <p class="hint-text">צור את המשתמש שלך. זה בחינם ולוקח רק דקה.</p>
            <div class="form-group">
                <div class="row">
                    <!-- div representing "row" as one chunk -->

                    <div class="col-sm-6">
                        <!-- First Column -->

                        <div class="form-group">
                            <input type="text" class="form-control" name="building_number" placeholder="מספר בניין"
                                onkeypress="return onlyNumberKey(event)" pattern="\d*" maxlength="2"
                                required="required">
                        </div>

                        <div class="form-group">
                            <input type="text" class="form-control" name="apartment_number"
                                placeholder="מספר דירה" onkeypress="return onlyNumberKey(event)" pattern="\d*"
                                maxlength="2" required="required">
                        </div>

                        <div class="form-group">
                            <input type="date" class="form-control" name="birthDate" required="required"
                                required="required" style="text-align: right;">
                        </div>

                        <div class="form-group">

                            <input list="load_datalist" id="load" name="load" class="form-control" placeholder="load"
                                required>

                            <datalist id="load_datalist">

                                <option> Nevermind </option>
                                <option> Free Of Load </option>

                            </datalist>
                        </div>

                        <div class="form-group">

                            <input list="covid19List" id="covid19Value" placeholder="קוביד19 " name="covid19Value"
                                class="form-control" name="covid19Value" required>
                            <datalist id="covid19List">

                                <option> לא חשוב </option>
                                <option> ללא </option>
                            </datalist>
                        </div>

                        <div class="form-group">
                            <input type="password" pattern=".{8,}" class="form-control" name="password"
                                placeholder="סיסמא (חייבת להכיל לפחות 8 תווים)">
                        </div>

                        <div class="form-group">
                            <input type="password" class="form-control" name="confirm_password"
                                placeholder="חזור על הסיסמא" required="required">
                        </div>
                    </div><!-- End of First column -->

                    <div class="col-sm-6">
                        <!-- Second Column -->

                        <div class="form-group">
                            <input type="text" class="form-control" name="id" pattern="[0-9]{9}" placeholder="מספר מזהה"
                                onkeypress="return onlyNumberKey(event)" maxlength="9" required="required">
                        </div>

                        <div class="form-group">
                            <input type="text" class="form-control" name="FirstName" placeholder="שם פרטי"
                                onkeypress="return onlyLettersKey(event)" maxlength="15">
                        </div>

                        <div class="form-group">
                            <input type="text" class="form-control" name="LastName" placeholder="שם משפחה"
                                onkeypress="return onlyLettersKey(event)" maxlength="15" required="required">
                        </div>

                        <div class="form-group">
                            <input type="email" class="form-control" name="Email"
                                pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" placeholder="אימייל"
                                required="required">
                        </div>

                        <div class="form-group">
                            <input type="tel" class="form-control" name="phoneNumber" pattern="[0-9]{10}"
                                placeholder="טלפון" maxlength="10" onkeypress="return onlyNumberKey(event)"
                                required="required">
                        </div>

                        <div class="form-group">
                            <input list="City" class="form-control" name="City" placeholder="בחר עיר:" required>
                            <datalist id="City">
                                <?php 
                            
                                require 'databaseconnection.php';
                                $cities_array = array();
                                $sql = "SELECT city FROM TblCity";
                                $result = sqlsrv_query( $conn , $sql, array(), array("Scrollable" => 'static'));
                                
                                while ($row = sqlsrv_fetch_array($result)) {
                                    
                                    array_push($cities_array, $row);
                                }
            
                                foreach ($cities_array as $value) {
                                    
                                    echo "<option> {$value['city']} </option>";
                                }
                            ?>
                            </datalist>
                        </div>

                        <div class="form-group">
                            <input type="text" class="form-control" name="Street" placeholder="רחוב"
                                required="required">
                        </div>

                        <div class="form-group">
                            <input type="text" class="form-control" name="zip_code" placeholder="מיקוד"
                                onkeypress="return onlyNumberKey(event)" pattern="\d*" maxlength="5"
                                required="required">
                        </div>

                    </div> <!-- End of Second column -->

                </div> <!-- End of row div -->
            </div>

            <label for="img1">בחר תמונה:</label>
            <input type="file" name="file" accept="image/*" onchange="loadFile(event)" height="20" width="20">
            <img id="output" />
            <script>
                var loadFile = function (event) {
                    var output = document.getElementById('output');
                    output.style.height = '100px';
                    output.style.width = '100px';
                    output.src = URL.createObjectURL(event.target.files[0]);
                    output.onload = function () {
                        URL.revokeObjectURL(output.src) // free memory
                    }
                };
            </script>

            <!-- Div section for terms & conditions checkbox -->
            <div class="form-group">
                <label class="checkbox-inline"><input type="checkbox" required="required"> אני מאשר את <a
                        href="terms_and_conditions.html" target="_blank">תנאי השימוש</a></label>
            </div>

            <!-- Div section for registering button  -->
            <div class="form-group">
                <button type="submit" class="btn btn-success btn-lg btn-block">הרשמה</button>
            </div>

            <!-- Div section for having account button -->
            <div class="text-center">כבר יש לך חשבון? <a href="user_login_HE.php">התחבר כאן</a></div>
        </form>
    </div>

</body>

</html>