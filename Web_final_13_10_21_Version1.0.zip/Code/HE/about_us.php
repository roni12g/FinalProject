<?php 

    /** 
     * This file contains the "About us" of the Hebrew version
     */

    // Calling the Hebrew layout and including it
    include "index_layout.php";

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous"> -->
    <link rel="stylesheet" href="../Styles/about_us.css">

    <title>Document</title>

    <!-- Styling Settings -->
    <style>

        p{
            text-align: center;
            font-size: large;
        }
        
        /*      
        .container { 
            height: 50vh;
            position: relative;
        }
        .center {
            margin: 0;
            position: absolute;
            top: 50%;
            left: 50%;
            -ms-transform: translate(-50%, -50%);
            transform: translate(-50%, -50%);
            
        }

        .row {
          display: flex;
        }

        .column {
          padding: 105px;
          margin-top: 0px;
        } */

        .center{
          margin-left: auto;
          margin-right:auto;
          display: block;
          margin: 0;
            position: absolute;
            top: 50%;
            left: 50%;
            -ms-transform: translate(-50%, -50%);
            transform: translate(-50%, -50%);
        }

        .center1{text-align: center;
            font-size: 20px;}

        .row {
          display: flex;
          align: center;

        }

        .column {
            flex: 30%;
            margin-top: 0px;
            width: 100px;
            padding-left: 10;
        }
        
    </style>

    
</head>
<body>
    
    <!-- <div class="d-flex justify-content-center">Hello there</div> -->



<br><br>
<div  class="description">

    <!-- About us text -->
    <p class="center1"> 
         ברוכים הבאים למערכת חיפוש נסיעות iTravel<br>
        אנו שלושה סטודנטים מהמכללה האקדמית עמק יזרעאל  <br>
        זה הפרוייקט הגמר שלנו עבור התואר שלנו שמתמקד בתחום התחבורה הציבורית <br> iTravel הינה פלטפורמה למציאת מסלולים לנוסעי הרכבת הקלה
        <br>
        מערכת iTravel מציגה לא רק מסלולים רלוונטיים ותכנון מסלולים, אלא גם נותנת לנוסעים הרשומים את האפשרות לקבל את המסלולים המותאמים ביותר עבורם  .
    </p>

</div>




<!-- Team members code section -->
<h2 class="center1"> <u> Team members </u> </h2>

<div class="row"> <!-- Code row -->

    <div align="center" class="column"> <!-- Team members flipping cards -->

        <!-- Roni Guzovsky flipping card -->
        <div class="flip-card">
            <div class="flip-card-inner">

                <div class="flip-card-front"> <!-- Front side of the flipping card settings -->
                    <img src="../images/user.jpeg" alt="Avatar" style="width:200px;height:200px;">
                </div>

                <div class="flip-card-back"> <!-- Back side of the flipping card settings -->
                    <h1> רוני גוזובסקי</h1> 
                    <p> מפתח צד לקוח-שרת</p> 
                    <p></p>
                </div>
            </div>
        </div>
    </div>


    <div align="center" class="column">

        <!-- Andreas Nser flipping card -->
        <div class="flip-card">
            <div class="flip-card-inner">
                <div class="flip-card-front"> <!-- Front side of the flipping card settings -->
                    <img src="../images/user.jpeg" alt="Avatar" style="width:200px;height:200px;">
                </div>
                <div class="flip-card-back"> <!-- Back side of the flipping card settings -->
                    <h1> אנדריאס נסיר</h1> 
                    <p>  מפתח צד לקוח-שרת</p> 
                    <p></p>
                </div>
            </div>
        </div>
    </div>


    <div align="center" class="column">

        <!-- Sharon Garmay flipping card -->
        <div class="flip-card">
            <div class="flip-card-inner">

                <div class="flip-card-front"> <!-- Front side of the flipping card settings -->
                    <img src="../images/user.jpeg" alt="Avatar" style="width:200px;height:200px;">
                </div>

                <div class="flip-card-back"> <!-- Back side of the flipping card settings -->
                    <h1> שרון גרמאי</h1> 
                    <p>  מפתח צד לקוח ועיצוב</p> 
                    <p></p>
                </div>
            </div>
        </div>
    </div>


</body>
</html>