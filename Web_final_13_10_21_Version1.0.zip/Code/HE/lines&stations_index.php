<?php 

    /** 
     * This file contains the Lines& Station code of the Hebrew version
     */
    
     
    // Calling the Hebrew layout and including it
    include 'index_layout.php';
    ?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../Styles/lines&stations.css">

</head>

<body>
    <!-- <div class="contant"> -->
    <div class="line-list">
        <ul style="display: flex; margin-top: 50px; margin-left: 20%;">


            <!-- First Class -> Red line -->
            <div class="red-line" style="padding: 0 1em; margin-left: 30px;">
                <li id="red" onClick="showMap(this.id)"> קו אדום</li> <!-- Show red line station map -->
                <p>מפתח תקווה דרך בני ברק, <br> רמת גן ותל אביב עד בת ים</p><!-- Line description -->
                <a href="../images/linesAndStations/red-line.jpg" target="_blank"><!-- Linking to map picture -->
                    <img class="pic" id="red-pic" src="../images/linesAndStations/red-line.jpg" alt="">
                </a>

            </div>

            <!-- Second Class -> Green line -->
            <div class="green-line" style="padding: 0 1em; margin-left: 30px;"> 
                <li id="green" onClick="showMap(this.id)"> קו ירוק</li>  <!-- Show green line station map -->
                <p>מהרצליה דרך תל אביב <br> וחולון ועד לראשון לציון</p><!-- Line description -->
                <a href="../images/linesAndStations/green-line.jpg" target="_blank">
                    <img class="pic" id="green-pic" src="../images/linesAndStations/green-line.jpg" alt=""></a>
            </div>

            <!-- Third Class -> Purple line -->
            <div class="purple-line" style="padding: 0 1em; margin-left: 30px;">
                <li id="purple" onClick="showMap(this.id)"> קו סגול</li> <!-- Show purple line station map -->
                <p> מתל אביב דרך רמת גן <br>גבעת שמואל, אור יהודה עד ליהוד  </p><!-- Line description -->
                <a href="../images/linesAndStations/purple-line.jpg" target="_blank"> <!-- Linking to map picture -->
                    <img class="pic" id="purple-pic" src="../images/linesAndStations/purple-line.jpg" alt=""></a>
            </div>

        </ul>
    </div>


    <!-- <div class="side-pic">
            <img src="images/map.png" alt="" style="float: right;" width="30%"
            height="100%">
        </div> -->
    <!-- </div> -->
</body>

<script>

    /**
     * function that is called once one of the lines names is clicked
     * @param clicked_id {event}
     */
    function showMap(clicked_id) {
        let color = clicked_id; // Get the color of the clicked title via its id
        document.getElementById(color + "-pic").classList.toggle('show'); // Toggle the selected map 
    }

</script>

</html>