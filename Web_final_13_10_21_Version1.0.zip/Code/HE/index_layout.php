<?php 
    
    /** 
     * This file contains the main page layout of the Hebrew version
     */
    
    
    /**
     * Including/Calling DB connection
     * @return connection
     */
    include "../databaseconnection.php"; ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>i-Travel</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="icon" type="image/ico" href="../images/favicon.ico">
    <link rel="stylesheet" href="../Styles/index_layout_HE.css">

</head>

<body dir="rtl" style="background-color: #eee;">
    <div class="all_site">
        <div class="header" style="display: flex;">
            <div class="user-pic" style="position: fixed; z-index: 1;">

                <!-- Login & Registration buttons settings -->
                <a href="user_login_HE.php" type="button" class="btn btn-outline-secondary">התחברות </a>
                <a href="customer_registration_HE.php" type="button" class="btn btn-outline-secondary"> הרשמה </a>

            </div>

            <!-- Company's Logo section -->
            <div class="logo">
                <img src="../images/logo.JPG" onclick="window.location.href='index.php'" alt="company logo" width="300"
                    height="100">
            </div>


        </div>


     

        <!-- Menu Settings -->
        <div class="topnav">
            <!-- English dropdown settings -->
            <a href="#cust2" onclick="window.location.href ='../index.php';"> EN </a>

            <!-- Right (Hebrew) dropdown settings -->
            <div class="topnav-right">
                
                <!-- Contact us menu tab -->
                <a href="https://www.nta.co.il/en/contact-us" target="_blank"> צור קשר</a>
                
                <!-- Tenders menu tab -->
                <a href="https://www.nta.co.il/tenders" target="_blank">מכרזים</a>
                

                <!-- Lines & Stations menu tab -->
                <a href="lines&stations_index.php"> קווים ותחנות </a>
                
                <!-- About us menu tab -->
                <a href="about_us.php" target="_self">אודות</a>
                

                <!-- Search route tab -->
                <a class="active" href="index.php">חפש מסלול </a>

            </div>
        </div>

        <!-- <hr> -->

        <!-- Page footer (left) social media -->
        <div class="footer">
            <div class="exetrnal-links" style="margin-left: 50px;">
                <div id="social-media">
                    <a href="https://www.facebook.com/NTAIsrael" target="_blank" class="fa fa-facebook"
                        style="width: 36.86px;"></a>
                    <a href="https://www.youtube.com/user/ntalines" target="_blank" class="fa fa-youtube"
                        style="width: 36.86px;"></a>
                    <a href="https://www.instagram.com/nta_israel" target="_blank" class="fa fa-instagram"
                        style="width: 36.86px;"></a>
                </div>
            </div>

            <!-- Page footer (center)  settings -->
            <p style="position: fixed; font-size:20px; left:0; bottom:0; width: 100%; text-align: center; height: auto"> &copy; המכללה האקדמית עמק יזרעאל - פרוייקט סופי
                <script>
                    let d = new Date();
                    let m = d.getMonth() + 1;
                    document.write(" " + d.getDate() + "/" + m + "/" + d.getFullYear());
                </script>
            </p>

            <!-- <a href="https://www.nta.co.il/" target="_blank" style="text-decoration: underline; color: #337ab7;">צור קשר
                </a> -->
        </div>

        <div>
            <p class="clear"></p>
        </div>
    </div>

</body>

</html>