<?php

    /** 
     * This file contains the search algorithm of the Hebrew version
     */

// Slicing Input Source Station & City
// $source_station_before_slice=$_POST['source_station'];
// $source_station_before_slice = explode(",",$source_station_before_slice);
// $source_station= end($source_station_before_slice);

// echo($source_station);

// // Slicing Input Source Station & City
// $destination_station_before_slice=
// $destination_station_before_slice = explode(",",$destination_station_before_slice);
// end($destination_station_before_slice);

// echo($destination_station);

require '../databaseconnection.php';

$source_station=$_POST['source_station'];
$destination_station= $_POST['destination_station'];
$travelDate=$_POST['travelDate'];
$time=$_POST['time'];
$sameLineColor=0;

// require '../databaseconnection.php';



/*source primary station*/
$sql = "select TblStation.primaryLine from TblStation where TblStation.stationName like '$source_station'";
$stmt = sqlsrv_query( $conn, $sql);

   if( $stmt === false ) {
     die( print_r( sqlsrv_errors(), true));
   }

   if( sqlsrv_fetch( $stmt ) === false) {
     die( print_r( sqlsrv_errors(), true));
   }
   $sourcePrimaryStation = sqlsrv_get_field( $stmt, 0);

/*source secondary station*/
   $sql = "select TblStation.secondaryLine from TblStation where TblStation.stationName like '$source_station'";
   $stmt = sqlsrv_query( $conn, $sql);
      if( $stmt === false ) {
        die( print_r( sqlsrv_errors(), true));
      }

      if( sqlsrv_fetch( $stmt ) === false) {
        die( print_r( sqlsrv_errors(), true));
      }
    $sourceSecondaryStation = sqlsrv_get_field( $stmt, 0);


/*destination primary station*/
$sql = "select TblStation.primaryLine from TblStation where TblStation.stationName like '$destination_station'";
$stmt = sqlsrv_query( $conn, $sql);


   if( $stmt === false ) {
     die( print_r( sqlsrv_errors(), true));
   }

   if( sqlsrv_fetch( $stmt ) === false) {
     die( print_r( sqlsrv_errors(), true));
   }
   $destinationPrimaryStation = sqlsrv_get_field( $stmt, 0);

/*destination secondary station*/
   $sql = "select TblStation.secondaryLine from TblStation where TblStation.stationName like '$destination_station'";
   $stmt = sqlsrv_query( $conn, $sql);
      if( $stmt === false ) {
        die( print_r( sqlsrv_errors(), true));
      }

      if( sqlsrv_fetch( $stmt ) === false) {
        die( print_r( sqlsrv_errors(), true));
      }
    $destinationSecondaryStation = sqlsrv_get_field( $stmt, 0);

/*get hour and minute*/
$hour = substr($time,0,2);
$min = substr($time,3,5);
$max = $min+20;

$junctionFirstSameAsSecondColor='a';
/*case if junction station is first station-> like same line colors*/
   $sql = "select t.secondaryStationName from TblStation as t where t.isJunction=1 and t.secondaryLine='$destinationPrimaryStation' and t.stationName = '$source_station'";
   $stmt = sqlsrv_query( $conn, $sql);
      if( $stmt === false ) {
        die( print_r( sqlsrv_errors(), true));
      }

      if( sqlsrv_fetch( $stmt ) === false) {
        die( print_r( sqlsrv_errors(), true));
      }
    $junctionFirstSameAsSecondColor = sqlsrv_get_field( $stmt, 0);


if($junctionFirstSameAsSecondColor != ''){
    $source_station = $junctionFirstSameAsSecondColor;
    $sourcePrimaryStation=$destinationPrimaryStation;
}


/*serch result for same line color*/
if($sourcePrimaryStation==$destinationPrimaryStation){
$sameLineColor=1;
/*check direction*/
  /*check source station number*/
   $sql = "select TblStation.stationNumber from TblStation where TblStation.stationName like '$source_station' ";
   $stmt = sqlsrv_query( $conn, $sql);
      if( $stmt === false ) {
        die( print_r( sqlsrv_errors(), true));
      }

      if( sqlsrv_fetch( $stmt ) === false) {
        die( print_r( sqlsrv_errors(), true));
      }
    $sourceStationNumber = sqlsrv_get_field( $stmt, 0);

  /*check destination station number*/

   $sql = "select TblStation.stationNumber from TblStation where TblStation.stationName like '$destination_station' ";
   $stmt = sqlsrv_query( $conn, $sql);
      if( $stmt === false ) {
        die( print_r( sqlsrv_errors(), true));
      }

      if( sqlsrv_fetch( $stmt ) === false) {
        die( print_r( sqlsrv_errors(), true));
      }
    $destinationStationNumber = sqlsrv_get_field( $stmt, 0);

    if(($destinationStationNumber-$sourceStationNumber)>0){
      $direction=0;
    }
    if (($destinationStationNumber-$sourceStationNumber)<0){
      $direction=1;
    }

        $searchRes = array();
        $sql = "select distinct s.*
                from TblRoute r inner join TblStopsIn s on r.sourceStationName=s.startStation and r.destStationName=s.endStation and r.routeDate=s.stopDate
                where r.routeDate like '$travelDate' and r.startHour = $hour and r.endHour = $hour and s.stationName like '$source_station' and s.stopMinute>=$min and s.stopHour=$hour and s.direction=$direction
                and s.stopMinute<=$max";

        $result = sqlsrv_query( $conn , $sql, array(), array("Scrollable" => 'static'));

        while ($selectedItem = sqlsrv_fetch_array($result)) {
            array_push($searchRes, $selectedItem);
        }

                if(count($searchRes)==0){
                    $sameLineColor=-1;
                    echo "
                    <div class='alert alert-danger alert-dismissible fade show' role='alert'>
                    <strong>Routes Not Found ,Try Different Stations/Time
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                      <span aria-hidden='true'>&times;</span>
                    </button>
                  </div>";

                    // echo "<div class='alert alert-danger' role='alert'>
                    //         Routes Not Found ,Try Different Stations/Time
                    //      </div>";
                    // echo "<script type='text/javascript'> alert('Routes Not Found ,Try Different Stations/Time')</script>";

                }


        $sql1 = "INSERT INTO TblPotentialUser  VALUES ('$travelDate')";
			$params1 = array();
			$options1 =  array('Scrollable' => SQLSRV_CURSOR_FORWARD);
			$result1 = sqlsrv_query( $conn , $sql1, $params1);


        $sql = "select top 1 TblPotentialUser.potentialNumber from TblPotentialUser  order by  TblPotentialUser.potentialNumber desc";
        $stmt = sqlsrv_query( $conn, $sql);
        if( $stmt === false ) {
         die( print_r( sqlsrv_errors(), true));
        }

       if( sqlsrv_fetch( $stmt ) === false) {
         die( print_r( sqlsrv_errors(), true));
        }
      $id = sqlsrv_get_field( $stmt, 0);


 $sql = "SELECT DATEPART(HOUR, GETDATE())";
        $stmt = sqlsrv_query( $conn, $sql);
        if( $stmt === false ) {
         die( print_r( sqlsrv_errors(), true));
        }

       if( sqlsrv_fetch( $stmt ) === false) {
         die( print_r( sqlsrv_errors(), true));
        }
      $nowHour = sqlsrv_get_field( $stmt, 0);

 $sql = "SELECT DATEPART(MINUTE, GETDATE())";
        $stmt = sqlsrv_query( $conn, $sql);
        if( $stmt === false ) {
         die( print_r( sqlsrv_errors(), true));
        }

       if( sqlsrv_fetch( $stmt ) === false) {
         die( print_r( sqlsrv_errors(), true));
        }
      $nowMinute = sqlsrv_get_field( $stmt, 0);

 $sql = "SELECT Convert(varchar(10), GETDATE(),120) ";
        $stmt = sqlsrv_query( $conn, $sql);
        if( $stmt === false ) {
         die( print_r( sqlsrv_errors(), true));
        }

       if( sqlsrv_fetch( $stmt ) === false) {
         die( print_r( sqlsrv_errors(), true));
        }
      $nowDate = sqlsrv_get_field( $stmt, 0);


       $sql1 = "INSERT INTO TblPotentialUserSearch  VALUES ($id,'$nowDate',$nowHour,$nowMinute,'$source_station','$destination_station')";
			$params1 = array();
			$options1 =  array('Scrollable' => SQLSRV_CURSOR_FORWARD);
			$result1 = sqlsrv_query( $conn , $sql1, $params1);


			if($sql1) {
				sqlsrv_commit( $conn );
			}
}

if($sourcePrimaryStation!=$destinationPrimaryStation){
$sourceInd=0;
$destInd=0;
$junctionStationName='a';
$junctionStationInd=0;
$sameLineColor=0;

 $sql = "select TblStation.stationNumber from TblStation where TblStation.stationName like '$source_station' ";
 $stmt = sqlsrv_query( $conn, $sql);
    if( $stmt === false ) {
      die( print_r( sqlsrv_errors(), true));
    }

    if( sqlsrv_fetch( $stmt ) === false) {
      die( print_r( sqlsrv_errors(), true));
    }
 $sourceInd = sqlsrv_get_field( $stmt, 0);

 $sql = "select TblStation.stationNumber from TblStation where TblStation.stationName like '$destination_station' ";
 $stmt = sqlsrv_query( $conn, $sql);
    if( $stmt === false ) {
      die( print_r( sqlsrv_errors(), true));
    }

    if( sqlsrv_fetch( $stmt ) === false) {
      die( print_r( sqlsrv_errors(), true));
    }
 $destInd = sqlsrv_get_field( $stmt, 0);



 $junctionRes = array();
 $sql = "select top 1 s.stationNumber,s.stationName,s.secondaryStationName, abs($sourceInd-s.stationNumber) as sourceStationFromHtml
           from TblStation as s
           where s.isJunction=1 and s.primaryLine='$sourcePrimaryStation' and s.secondaryLine='$destinationPrimaryStation'
           order by sourceStationFromHtml";

$result = sqlsrv_query( $conn , $sql, array(), array("Scrollable" => 'static'));

           while ($selectedItem = sqlsrv_fetch_array($result)) {
               array_push($junctionRes, $selectedItem);
           }


$junctionStationNumber =  $junctionRes[0]['stationNumber'] ;
$junctionPrimaryStation = $junctionRes[0]['stationName'] ;
$junctionSecondaryStation = $junctionRes[0]['secondaryStationName'];

 $sql = "select TblStation.stationNumber from TblStation where TblStation.stationName like '$junctionSecondaryStation' ";
 $stmt = sqlsrv_query( $conn, $sql);
    if( $stmt === false ) {
      die( print_r( sqlsrv_errors(), true));
    }

    if( sqlsrv_fetch( $stmt ) === false) {
      die( print_r( sqlsrv_errors(), true));
    }
 $junc2ndStationNumber= sqlsrv_get_field( $stmt, 0);

 if($sourceInd < $junctionStationNumber){
         $direction=0;
 }
 if($sourceInd > $junctionStationNumber){
         $direction=1 ;
 }

  if($junc2ndStationNumber < $destInd){
         $direction2ndLine=0;
 }
 if($junc2ndStationNumber > $destInd){
         $direction2ndLine=1 ;
 }


 $searchResFirstLine = array();
 $sql = "select distinct s.trainNumber,s.stationName,s.stopDate,s.passengersInTrain,s.startStation,s.endStation
           ,s.covid19InOut,s.loadParameter,s.direction,s.stopMinute,s.stopHour
             ,juncMinute=(select top 1 s1.stopMinute
           from TblRoute r1 inner join TblStopsIn s1 on r1.sourceStationName=s1.startStation and r1.destStationName=s1.endStation
              where r1.routeDate like '$travelDate' and r1.startHour = $hour and r1.endHour = $hour and s1.stationName like '$junctionPrimaryStation' and  s1.stopHour=$hour and s1.direction=$direction and s.trainNumber=s1.trainNumber
            )
            from TblRoute r inner join TblStopsIn s on r.sourceStationName=s.startStation and r.destStationName=s.endStation and r.routeDate=s.stopDate
              where r.routeDate like '$travelDate' and r.startHour = $hour and r.endHour = $hour and s.stationName like '$source_station' and s.stopMinute>=$min and s.stopHour=$hour and s.direction=$direction
              and s.stopMinute<=$max";

        $result = sqlsrv_query( $conn , $sql, array(), array("Scrollable" => 'static'));

        while ($selectedItem = sqlsrv_fetch_array($result)) {
            array_push($searchResFirstLine, $selectedItem);
        }


if(count($searchResFirstLine)==0){
            $sameLineColor=-1;
            echo " <div class='alert alert-danger alert-dismissible fade show' role='alert'>
            <strong>Routes Not Found ,Try Different Stations/Time
            <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
              <span aria-hidden='true'>&times;</span>
            </button>
          </div>";
            // echo "<script type='text/javascript'> alert('Routes Not Found ,Try Different Stations/Time')</script>";

        }
        else{
        $startSecond = $searchResFirstLine[0]['juncMinute'];
        }


 if(count($searchResFirstLine)>0){
 $searchResSecondLine = array();
 $sql = "select distinct s.trainNumber,s.stationName,s.stopDate,s.passengersInTrain,s.startStation,s.endStation
         ,s.covid19InOut,s.loadParameter,s.direction,s.stopMinute,s.stopHour
         ,endTrainTime=(select top 1 s1.stopMinute
         from TblRoute r1 inner join TblStopsIn s1 on r1.sourceStationName=s1.startStation and r1.destStationName=s1.endStation
         where r1.routeDate like '$travelDate' and r1.startHour = $hour and r1.endHour = $hour and s1.stationName like '$destination_station' and  s1.stopHour=$hour and s1.direction=$direction2ndLine and s.trainNumber=s1.trainNumber
            )
            from TblRoute r inner join TblStopsIn s on r.sourceStationName=s.startStation and r.destStationName=s.endStation and r.routeDate=s.stopDate
             where r.routeDate like '$travelDate' and r.startHour = $hour and r.endHour = $hour and s.stationName like '$junctionSecondaryStation' and s.stopMinute>=$startSecond and s.stopHour=$hour and s.direction=$direction2ndLine
           ";

        $result = sqlsrv_query( $conn , $sql, array(), array("Scrollable" => 'static'));

        while ($selectedItem1 = sqlsrv_fetch_array($result)) {
            array_push($searchResSecondLine, $selectedItem1);
        }


   $sql1 = "INSERT INTO TblPotentialUser  VALUES ('$travelDate')";
			$params1 = array();
			$options1 =  array('Scrollable' => SQLSRV_CURSOR_FORWARD);
			$result1 = sqlsrv_query( $conn , $sql1, $params1);


        $sql = "select top 1 TblPotentialUser.potentialNumber from TblPotentialUser  order by  TblPotentialUser.potentialNumber desc";
        $stmt = sqlsrv_query( $conn, $sql);
        if( $stmt === false ) {
         die( print_r( sqlsrv_errors(), true));
        }

       if( sqlsrv_fetch( $stmt ) === false) {
         die( print_r( sqlsrv_errors(), true));
        }
      $id = sqlsrv_get_field( $stmt, 0);


 $sql = "SELECT DATEPART(HOUR, GETDATE())";
        $stmt = sqlsrv_query( $conn, $sql);
        if( $stmt === false ) {
         die( print_r( sqlsrv_errors(), true));
        }

       if( sqlsrv_fetch( $stmt ) === false) {
         die( print_r( sqlsrv_errors(), true));
        }
      $nowHour = sqlsrv_get_field( $stmt, 0);

 $sql = "SELECT DATEPART(MINUTE, GETDATE())";
        $stmt = sqlsrv_query( $conn, $sql);
        if( $stmt === false ) {
         die( print_r( sqlsrv_errors(), true));
        }

       if( sqlsrv_fetch( $stmt ) === false) {
         die( print_r( sqlsrv_errors(), true));
        }
      $nowMinute = sqlsrv_get_field( $stmt, 0);

 $sql = "SELECT Convert(varchar(10), GETDATE(),120) ";
        $stmt = sqlsrv_query( $conn, $sql);
        if( $stmt === false ) {
         die( print_r( sqlsrv_errors(), true));
        }

       if( sqlsrv_fetch( $stmt ) === false) {
         die( print_r( sqlsrv_errors(), true));
        }
      $nowDate = sqlsrv_get_field( $stmt, 0);


       $sql1 = "INSERT INTO TblPotentialUserSearch  VALUES ($id,'$nowDate',$nowHour,$nowMinute,'$source_station','$destination_station')";
			$params1 = array();
			$options1 =  array('Scrollable' => SQLSRV_CURSOR_FORWARD);
			$result1 = sqlsrv_query( $conn , $sql1, $params1);


			if($sql1) {
				sqlsrv_commit( $conn );
			}

if(count($searchResSecondLine)==0){
            $sameLineColor=-1;
            echo " <div class='alert alert-danger alert-dismissible fade show' role='alert'>
            <strong>Routes Not Found ,Try Different Stations/Time
            <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
              <span aria-hidden='true'>&times;</span>
            </button>
          </div>";
            // echo "<script type='text/javascript'> alert('Routes Not Found ,Try Different Stations/Time')</script>";

        }

  }
}


/* test data
   echo $sourcePrimaryStation;
   echo $sourceSecondaryStation;
   echo $destinationPrimaryStation;
   echo $destinationSecondaryStation;
      echo $source_station;
       echo $travelDate;
       echo $destination_station;
       echo $time;
        echo count($searchRes);

        foreach($searchRes as $searchItem){
                   print_r($searchItem);
                   }

*/
?>


<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="UTF-8">
<title>Search Results</title>
<link rel="stylesheet" type="text/css" href="searchStyle.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T">


<style>

.column {
    float: left;
    width: 50%;
    padding: 10px;
    height: 150px;
    text-align: left;
}

row{
  text-align: center;
}
.print{
background-color: #3498db;
color: white;
padding: 5px 10px;
margin: 4px 0;
border: none;
cursor: pointer;
width: 6%;
text-align: center;
border-radius: 3px;
margin-left:1600px

}

 table {
     font-family: "comic sans ms MS", Arial, Helvetica, sans-serif;
     font-family: "comic sans ms MS", Arial, Helvetica, sans-serif;
     border-collapse: collapse;
     width: 100%;
     text-align: center;


 }

 table td, th {
     border: 1px solid #ddd;
     padding: 8px;
     

 }

 table tr:nth-child(even){
     background-color: #f2f2f2;
 }

 table tr:hover {background-color: #ddd;}

 table th {
     padding-top: 12px;
     padding-bottom: 12px;
     text-align: left;
     background-color: #4CAF50;
     color: white;
     text-align: center;
     font-family: "comic sans ms MS", Arial, Helvetica, sans-serif;
 }

input[type=Back] {
  background-color: #af181d;
  color: white;
  padding: 10px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 8%;
  text-align: center;
  text-align: center;
  border-radius: 10px;
 }

.button {
background-color: #4CAF50;
color: white;
padding: 10px 20px;
margin: 8px 0;
border: none;
cursor: pointer;
width: 8%;
text-align: center;
text-align: center;
border-radius: 10px;
}

.print{
  background-color: #3498db;
  color: white;
  padding: 5px 10px;
  margin: 4px 0;
  border: none;
  cursor: pointer;
  width: 6%;
  text-align: center;
  border-radius: 3px;
  margin-left:1600px
}

</style>


<script>

    /**
     * function which checks if the source station and destination station are identical
     */
      function checkIfSame(){

          // Getting the inserted values of the source station and destination input fields
          var chosen_source_station = document.getElementById('source_station').value;
          var chosen_destination_station = document.getElementById('destination_station').value;

          // Check wether the source station value and destination station value are identical
          if(chosen_source_station == chosen_destination_station){ // If they are the same
              alert(" תחנת המוצא והיעד הינן זהות. \n אנא שנה אחת מהתחנות"); // Alert the user to change one of these inputs

              return false;
          }

          else{ // Soucre station & destination station are different 
              document.getElementById("form").submit(); // Submit the form to the search algorithm file
          }
      }
      
  </script>

</head>

<body dir="rtl">

<?php
    include "‏‏index_layout_without_EN.php";

    $stations_array = array();
    $sql = "SELECT stationName, city FROM TblStation order by city";
        $result = sqlsrv_query( $conn , $sql, array(), array("Scrollable" => 'static'));
        while ($selectedItem = sqlsrv_fetch_array($result)) {
            
            $station_name = $selectedItem['city'];
            $station_city = $selectedItem['stationName'];
            
            $station_details = $station_name.", ".$station_city;

            array_push($stations_array, $station_details);
        }


 ?>

<div style="width:500px;float:right;text-align:right">
<form  style=" overflow: hidden; " action="search.php" method="post" id="form" onsubmit="return checkIfSame()">
            <div class="form-group">
                <div class="row" style="width: 100%;">
                    <div class="col-sm-6">
                       
                        <div class="form-group">
                            <div class="source_datalist">

                                <label for="source_station" > תחנת מוצא</label>
                                <!-- <input type="text" list="source_station_list" class="form-control" id="source_station"
                                    name="source_station" > -->
                                <select id="source_station" class="form-control" id="source_station"
                                    name="source_station" selected ="<?php echo $source_station; ?>" autocomplete="on" required>

                                    <?php

                                            $former_opt_group = "Bat Yam";
                                            echo "<option ={$source_station}> {$source_station} </option>";

                                            echo "<optgroup label='{$former_opt_group}'>";
                                            foreach ($stations_array as $value) {
                                                $city = explode(",",$value)[0];
                                                echo $city;
                                                $station = end(explode(",",$value));

                                                if($city != $former_opt_group){
                                                    echo "</optgroup>";
                                                    $city = explode(",",$value)[0];
                                                    $former_opt_group = $city;

                                                    echo "<optgroup label='{$city}'>";
                                                }
                                                  echo "<option = {$station} > {$station} </option>";

                                            }
                                        
                                    ?>
                                </select>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="travelDate" > תאריך נסיעה </label>
                            <input type="date" id="travelDate" class="form-control" name="travelDate"
                                value="<?php echo $travelDate; ?>" style="width: 200px" min="<?php echo date('Y-m-d');?>"
                                required>
                        </div>
                    </div>

                    <div class="col-sm-6">

                        <div class="form-group">
                            <label > תחנת יעד </label>
                            <select id="destination_station" class="form-control" name="destination_station" autocomplete="on" 
                            value ="<?php echo $destination_station; ?>" required>
                                <?php 
                                // $sql = "SELECT stationName FROM TblStation";
                                // $result = sqlsrv_query( $conn , $sql, array(), array("Scrollable" => 'static'));
                                // $selectedSourceStation = $_GET['source_station'];

                                    $former_opt_group = "Bat Yam";
                                    echo "<option = {$destination_station}> {$destination_station} </option>";

                                    echo "<optgroup label='{$former_opt_group}'>";

                                    foreach ($stations_array as $value) {
                                        $city = explode(",",$value)[0];
                                        echo $city;
                                        $station = end(explode(",",$value));

                                        if($city != $former_opt_group){
                                            echo "</optgroup>";
                                            $city = explode(",",$value)[0];
                                            $former_opt_group = $city;

                                            echo "<optgroup label='{$city}'>";
                                        }

                                        echo "<option = {$station}> {$station} </option>";
                                    }
                                
                                      
                                ?>

                            </select>

                        </div>
                        <div class="form-group">
                            <label for="time"> זמן </label>

                            <input type="time" id="time" class="form-control" name="time" min="07:00" max="22:00" 
                            value="<?php echo $time; ?>"  
                                required>
                        </div>
                    </div>
                </div>
            </div>
            <button type="submit" class="btn btn-success" style="margin-left:30px ; width:50px;">חיפוש</button>
            <button id="print" class="print" onclick="window.print()">הדפסה</button>


        </form>
</div>

<div class="container" style="background-color: #eee;">
 <div style="text-align:center">
 </div>

 <div class="row" style="text-align: right">
<form  method="post">
 <!-- <p><h3 >תוצאות חיפוש</h3></p> -->
     </form>
 </div>
</div>



<?php


if($sameLineColor==1){
echo "<table>";
echo "<tr><th>Line Color</th><th>Train Number</th><th>Source Station</th><th>Source City</th><th>Destination Station</th><th>Destination City</th><th>Date</th><th>Departure Time</th></th><th>Arrival Time</th><th>Travel Time</th><th>Direction</th></tr>";
 foreach($searchRes as $row){
 echo "<tr><td>";
 echo $sourcePrimaryStation;
 echo "</td><td>";
 $train = $row['trainNumber'];
 echo $row['trainNumber'];
 echo "</td><td>";
 echo $row['stationName'];
 echo "</td><td>";

          $sql = "select t.city from TblStation as t where t.stationName='$source_station'";
          $stmt = sqlsrv_query( $conn, $sql);
          if( $stmt === false ) {
           die( print_r( sqlsrv_errors(), true));
           }
           if( sqlsrv_fetch( $stmt ) === false) {
           die( print_r( sqlsrv_errors(), true));
           }
           $sourceCity = sqlsrv_get_field( $stmt, 0);

 echo $sourceCity;
 echo "</td><td>";
 echo $destination_station;
 echo "</td><td>";

               $sql = "select t.city from TblStation as t where t.stationName='$destination_station'";
               $stmt = sqlsrv_query( $conn, $sql);
               if( $stmt === false ) {
                die( print_r( sqlsrv_errors(), true));
                }
                if( sqlsrv_fetch( $stmt ) === false) {
                die( print_r( sqlsrv_errors(), true));
                }
                $destinationCity = sqlsrv_get_field( $stmt, 0);

 echo $destinationCity;
 echo "</td><td>";
 $Date = $row['stopDate']->format('d/m/Y');
 echo $Date;
 echo "</td><td>";

         /*check destination arrival time*/
        $sql = "select s.stopHour
                from TblRoute r inner join TblStopsIn s on r.sourceStationName=s.startStation and r.destStationName=s.endStation
                where r.routeDate like '$travelDate' and r.startHour=$hour and r.endHour =$hour and s.stationName like '$destination_station' and s.stopHour=$hour and s.direction=$direction and s.trainNumber=$train";

        $stmt = sqlsrv_query( $conn, $sql);
           if( $stmt === false ) {
             die( print_r( sqlsrv_errors(), true));
           }

           if( sqlsrv_fetch( $stmt ) === false) {
             die( print_r( sqlsrv_errors(), true));
           }
         $arrivalHour = sqlsrv_get_field( $stmt, 0);

         $sql = "select s.stopMinute
         from TblRoute r inner join TblStopsIn s on r.sourceStationName=s.startStation and r.destStationName=s.endStation
         where r.routeDate like '$travelDate' and r.startHour=$hour and r.endHour =$hour and s.stationName like '$destination_station' and s.stopHour=$hour and s.direction=$direction and s.trainNumber=$train";

         $stmt = sqlsrv_query( $conn, $sql);
          if( $stmt === false ) {
            die( print_r( sqlsrv_errors(), true));
          }

          if( sqlsrv_fetch( $stmt ) === false) {
            die( print_r( sqlsrv_errors(), true));
          }
          $arrivalMinute = sqlsrv_get_field( $stmt, 0);

          $departure_hour = $row['stopHour'];
          $departure_minute = $row['stopMinute'];
          if($departure_hour < 10)
              $departure_hour = "0".$departure_hour;
          if($departure_minute < 10)
              $departure_minute = "0".$departure_minute;
        
          $departure_time = "{$departure_hour}:{$departure_minute}";


          if($arrivalHour < 10)
              $arrivalHour = "0".$arrivalHour;
          if($arrivalMinute < 10)
              $arrivalMinute = "0".$arrivalMinute;
        
          $arrival_time = "{$arrivalHour}:{$arrivalMinute}";

 echo $departure_time;
 echo "</td><td>";
 echo $arrival_time;

 echo "</td><td>";
 $timeOfTrip = abs($arrivalMinute-$row['stopMinute']);
 echo $timeOfTrip;
 echo "</td><td>";
 echo $row['startStation'] . " --> " . $row['endStation'];


}
echo "</table>";
}
else if($sameLineColor==0){
echo "<h2>תוצאות חיפוש - הרכבת הראשונה</h2>";
echo "<table>";
echo "<tr><th>צבע קו</th><th>מספר רכבת</th><th>תחנת מוצא</th><th>עיר מוצא</th><th>תחנת יעד</th><th>עיר יעד</th><th>תחנת צומת</th><th>עיר צומת</th><th>תאריך</th><th>זמן יציאה</th><th>זמן הגעה </th><th> משך זמן</th><th>כיוון</th></tr>";

 foreach($searchResFirstLine as $row){
 echo "<tr><td>";
 echo $sourcePrimaryStation;
 echo "</td><td>";
 $train = $row['trainNumber'];
 echo $row['trainNumber'];
 echo "</td><td>";
 echo $row['stationName'];
 echo "</td><td>";

          $sql = "select t.city from TblStation as t where t.stationName='$source_station'";
          $stmt = sqlsrv_query( $conn, $sql);
          if( $stmt === false ) {
           die( print_r( sqlsrv_errors(), true));
           }
           if( sqlsrv_fetch( $stmt ) === false) {
           die( print_r( sqlsrv_errors(), true));
           }
           $sourceCity = sqlsrv_get_field( $stmt, 0);

 echo $sourceCity;
 echo "</td><td>";
 echo $destination_station;
 echo "</td><td>";

               $sql = "select t.city from TblStation as t where t.stationName='$destination_station'";
               $stmt = sqlsrv_query( $conn, $sql);
               if( $stmt === false ) {
                die( print_r( sqlsrv_errors(), true));
                }
                if( sqlsrv_fetch( $stmt ) === false) {
                die( print_r( sqlsrv_errors(), true));
                }
                $destinationCity = sqlsrv_get_field( $stmt, 0);

 echo $destinationCity;
 echo "</td><td>";

 echo $junctionPrimaryStation;
      echo "</td><td>";

                    $sql = "select t.city from TblStation as t where t.stationName='$junctionPrimaryStation'";
                    $stmt = sqlsrv_query( $conn, $sql);
                    if( $stmt === false ) {
                     die( print_r( sqlsrv_errors(), true));
                     }
                     if( sqlsrv_fetch( $stmt ) === false) {
                     die( print_r( sqlsrv_errors(), true));
                     }
                     $destinationJunctionCity = sqlsrv_get_field( $stmt, 0);

                     $departure_hour = $row['stopHour'];
                     $departure_minute = $row['stopMinute'];
                     if($departure_hour < 10)
                         $departure_hour = "0".$departure_hour;
                     if($departure_minute < 10)
                         $departure_minute = "0".$departure_minute;
                   
                     $departure_time = "{$departure_hour}:{$departure_minute}";
           
                     $arrivalHour = $row['stopHour'];
                     $arrivalMinute = $row['juncMinute'];
                     if($arrivalHour < 10)
                         $arrivalHour = "0".$arrivalHour;
                     if($arrivalMinute < 10)
                         $arrivalMinute = "0".$arrivalMinute;
                   
                     $arrival_time = "{$arrivalHour}:{$arrivalMinute}";

      echo $destinationJunctionCity;
      echo "</td><td>";

 $Date = $row['stopDate']->format('d/m/Y');
 echo $Date;
 echo "</td><td>";
 echo $departure_time;
 echo "</td><td>";
 echo $arrival_time;
 echo "</td><td>";
 $timeOfTrip = abs($row['juncMinute']-$row['stopMinute']);
 echo $timeOfTrip;
 echo "</td><td>";
 echo $row['startStation'] . " --> " . $row['endStation'];

}
echo "</table>";

echo "<h2>תוצאות חיפוש - הרכבת השנייה</h2>";
echo "<table>";
echo "<tr><th>צבע קו</th><th>מספר רכבת</th><th>תחנת מוצא</th><th>עיר מוצא</th><th>תחנת יעד</th><th>עיר יעד</th><th>תאריך</th><th>זמן יציאה</th><th>זמן הגעה </th><th> משך זמן</th><th>כיוון</th></tr>";
 foreach($searchResSecondLine as $row){
 echo "<tr><td>";
 echo $destinationPrimaryStation;
 echo "</td><td>";
 $train = $row['trainNumber'];
 echo $row['trainNumber'];
 echo "</td><td>";
 echo $row['stationName'];
 echo "</td><td>";

          $sql = "select t.city from TblStation as t where t.stationName='$junctionSecondaryStation'";
          $stmt = sqlsrv_query( $conn, $sql);
          if( $stmt === false ) {
           die( print_r( sqlsrv_errors(), true));
           }
           if( sqlsrv_fetch( $stmt ) === false) {
           die( print_r( sqlsrv_errors(), true));
           }
           $sourceCity = sqlsrv_get_field( $stmt, 0);

 echo $sourceCity;
 echo "</td><td>";
 echo $destination_station;
 echo "</td><td>";

               $sql = "select t.city from TblStation as t where t.stationName='$destination_station'";
               $stmt = sqlsrv_query( $conn, $sql);
               if( $stmt === false ) {
                die( print_r( sqlsrv_errors(), true));
                }
                if( sqlsrv_fetch( $stmt ) === false) {
                die( print_r( sqlsrv_errors(), true));
                }
                $destinationCity = sqlsrv_get_field( $stmt, 0);


                $departure_hour = $row['stopHour'];
                $departure_minute = $row['stopMinute'];
                if($departure_hour < 10)
                    $departure_hour = "0".$departure_hour;
                if($departure_minute < 10)
                    $departure_minute = "0".$departure_minute;
              
                $departure_time = "{$departure_hour}:{$departure_minute}";

                $arrivalHour = $row['stopHour'];
                if($arrivalHour < 10)
                    $arrivalHour = "0".$arrivalHour;
                $arrivalMinute = $row['endTrainTime'];
                if($arrivalMinute < 10)
                    $arrivalMinute = "0".$arrivalMinute;
              
                $arrival_time = "{$arrivalHour}:{$arrivalMinute}";

 echo $destinationCity;
 echo "</td><td>";

 $Date = $row['stopDate']->format('d/m/Y');
 echo $Date;
 echo "</td><td>";
 echo $departure_time;
 echo "</td><td>";
 echo $arrival_time;
 echo "</td><td>";
 $timeOfTrip = abs($row['endTrainTime']-$row['stopMinute']);
 echo $timeOfTrip;
 echo "</td><td>";
 echo $row['startStation'] . " --> " . $row['endStation'];

}
echo "</table>";





}
?>

<!-- Yaakov Krol  petah tikva
    data-to=<?php //echo $destination_station."street Israel" ?>
 -->
  <script>
    (function(d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        js = d.createElement(s); js.id = id;
        js.src = "https://widgets.moovit.com/wtp/en";
        fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'moovit-jsw'));
    
  </script>

  <?php

    $sql = "SELECT map from TblStationTranslateHeb where stationName='$source_station'";
    $stmt = sqlsrv_query( $conn, $sql);
    if( $stmt === false ) {
    die( print_r( sqlsrv_errors(), true));
    }
    if( sqlsrv_fetch( $stmt ) === false) {
    die( print_r( sqlsrv_errors(), true));
    }
    $sourceStationLatLong = sqlsrv_get_field( $stmt, 0);

    $sql = "SELECT map from TblStationTranslateHeb where stationName='$destination_station'";
    $stmt = sqlsrv_query( $conn, $sql);
    if( $stmt === false ) {
    die( print_r( sqlsrv_errors(), true));
    }
    if( sqlsrv_fetch( $stmt ) === false) {
    die( print_r( sqlsrv_errors(), true));
    }
    $destinationStationLatLong = sqlsrv_get_field( $stmt, 0);

    // data-metro="121"
    echo  $source_station;
    echo  $destination_station;
    
  ?>
  <div class="mv-wtp"
    data-lang="hb"
    data-from= <?php echo $source_station; ?>
    data-from-lat-long = <?php echo $sourceStationLatLong; ?>
    data-to=<?php echo $destination_station; ?>
    data-to-lat-long = <?php echo $destinationStationLatLong; ?>
  </div>

</body>
<br>
<br>
<br>

<input type="Back" onclick="window.location.href ='index.php';" value="Back">
<button id="print" class="print" onclick="window.print()">Print</button>

</html>
