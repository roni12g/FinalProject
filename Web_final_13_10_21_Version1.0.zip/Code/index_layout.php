<?php 
    /** 
     * This file contains regular user layout page elements and styling
     */


    /**
     * Including/Calling DB connection
     * @return connection
     */
    include "databaseconnection.php";

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>i-Travel</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="Styles/index_layout_EN.css">

    <link rel="icon" type="image/ico" href="images/favicon.ico">
</head>

    

<body >
    <div class="all_site">
        <div class="header" style="display: flex;">
            <div class="user-pic" style="position: fixed; z-index: 1;">
                <!-- Login & Registration buttons settings -->
                <a href="user_login.php" type="button" class="btn btn-outline-secondary"> Login </a>
                <a href="customer_registration.php" type="button" class="btn btn-outline-secondary"> Registration </a>
            </div>

            <!-- Company's Logo section -->
            <div class="logo">
                <img src="images/logo.JPG" onclick="window.location.href='index.php'" alt="company logo" width="300"
                    height="100">
            </div>

            
        </div>

        <!-- Menu Settings -->
        <div class="topnav">

            <!-- Search Route dropdown settings -->
            <a class="active" href="index.php">Home</a>
            
            <!-- About menu tab -->
            <a href="about_us.php">About Us</a>

            <!-- Lines & Stations menu tab -->
            <a href="lines&stations_index.php"> Lines & Stations</a>

            <!-- Tenders menu tab -->
            <a href="https://www.nta.co.il/en/tenders" target="_blank">Tenders</a>

            <!-- Contact us menu tab -->
            <a href="https://www.nta.co.il/en/contact-us" target="_blank">Contact us</a>

            <!-- Hebrew dropdown settings -->
            <div class="topnav-right">
                <a href="#cust2" onclick="window.location.href ='HE/index.php';"> HE </a>
            

            </div>
        </div>

        <!-- Page footer (left) social media -->
        <div class="footer">
            <div class="exetrnal-links" style="margin-left: 50px;">
                <div id="social-media">
                    <a href="https://www.facebook.com/NTAIsrael" target="_blank" class="fa fa-facebook"
                        style="width: 36.86px;"></a>
                    <a href="https://www.youtube.com/user/ntalines" target="_blank" class="fa fa-youtube"
                        style="width: 36.86px;"></a>
                    <a href="https://www.instagram.com/nta_israel" target="_blank" class="fa fa-instagram"
                        style="width: 36.86px;"></a>
                </div>
            </div>

            <!-- Page footer (center)  settings -->
            <p style="position: fixed; left:0; bottom:0; width: 100%; text-align: center; height: auto;"> &copy; YVC - Final Project
                <script>
                    let d = new Date();
                    let m = d.getMonth() + 1;
                    document.write(" " + d.getDate() + "/" + m + "/" + d.getFullYear());
                </script>
            </p>

            <!-- <a href="https://www.nta.co.il/" target="_blank" style="text-decoration: underline; color: #337ab7;">Contact
                Us</a> -->
        </div>

        <div>
            <p class="clear"></p>
        </div>
    </div>

</body>

</html>