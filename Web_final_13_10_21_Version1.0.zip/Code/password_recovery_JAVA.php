<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign in</title>
    <!-- <link rel="stylesheet" href="design.css"> -->
    <link rel="stylesheet" href="Styles/customer_layout.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" >

    <style>
        input,
        label {
            display: block;
            margin: auto;
            width: 50%;
        }

        .sign-in-form {
            border: 3px solid gray;
        }

        .header {
        width: 100%;
        height: 100px;
        display: flex;
    }

    .fa {
        width: 16px;
        padding: 12px;
        font-size: 15px;
        text-align: center;
        text-decoration: none;
        margin: 5px 2px;
        color: white;
        border-radius: 50%;
    }

    .fa:hover {
        opacity: 0.7;
    }

    .fa-facebook {
        background: #3B5998;
    }

    .fa-youtube {
        background: #bb0000;
    }

    .fa-instagram {
        background: #8a3ab9;
    }

    #lines:hover {
        background-color: #4CAF50;
        color: white;
    }
    </style>
</head>

<body>
<div class="signup-form">
    <form action="password_change_DB.php" method="post">
        <h2>Change Password</h2>
        <div class="form-group">
            <div class="row">
                <div class="col-sm-6">

                    <div class="form-group">
                        <input type="number" class="form-control" name="id_number" placeholder="ID Number" required="required">
                    </div>
                    <br>

                    <div class="form-group">
                    <input type="password" class="form-control" name="new_password" placeholder="New Password" required="required">
                    </div>
                    <br>

                    <div class="form-group">
                    <input type="password" class="form-control" name="new_password_copy" placeholder="Copy New Password" required="required">
                    </div>
                    <br>

                </div>

            </div>
        </div>

        <div class="form-group">
            <button type="submit" class="btn btn-success btn-lg btn-block"> Submit</button>
        </div>
    </form>
</div>


<div class="footer">
<div class="exetrnal-links" style="margin-left: 50px;">
    <div id="social-media">
        <a href="https://www.facebook.com/NTAIsrael" target="_blank" class="fa fa-facebook"></a>
        <a href="https://www.youtube.com/user/ntalines" target="_blank" class="fa fa-youtube"></a>
        <a href="https://www.instagram.com/nta_israel" target="_blank" class="fa fa-instagram"></a>
    </div>
</div>

<p style="width: 50%; margin-left: 240px;"> &copy; YVC - Final Project
    <script>
        let d = new Date();
        let m = d.getMonth() + 1;
        document.write(" " + d.getDate() + "/" + m + "/" + d.getFullYear());
    </script>
</p>

<a href="https://www.nta.co.il/" target="_blank" style="color: #337ab7; text-decoration: underline;">Contact
    Us</a>
</div>

<div>
<p class="clear"></p>
</div>

    
</body>

</html>


