<?php

	/** 
     * This file contains updating customers details in DB.
	 * This file is called after "Save" button in customer_profile.php is clicked
     */

	//Start Session:
	session_start(); 


	/**
	 * Including/Calling DB connection
	 * @return connection
	 */
	include 'databaseconnection.php';

	// $parent_page = $_SESSION['parent_page_session'];
	// echo $parent_page;


	$user_id = $_SESSION['username']; // Get users id number from the actuve session

	/**
	 * Getting the settings form cookies
	 */
	$email_cookie = $_COOKIE['email'];
	$phoneNumber_cookie = $_COOKIE['phoneNumber'];
	$zip_code_cookie = $_COOKIE['zip_code'];
	$city_cookie = $_COOKIE['city'];

	$load_cookie = $_COOKIE['load'];
	$covid19Value_cookie = $_COOKIE['covid19Value'];
	$street_cookie = $_COOKIE['street'];
	$building_cookie = $_COOKIE['building_number'];
	$apartment_cookie = $_COOKIE['apartment_number'];
	
	// Converting the users_covid19_val parameter from number to string accrodingly
	if($covid19Value_cookie == "Covid Free"){
		$covid19Value_cookie = 0;
	}
	else{
		$covid19Value_cookie = 1;
	}

	// Converting the loadParameter parameter from number to string accrodingly
	if($load_cookie == "Free Of Load") {
		$load_cookie = 0.5;
	}
	else{
		$load_cookie = 1;

	}

	$img_move = null;
	$x=0;
	$name = "image_name_need_still_work";

	/**
	 * Query for getting users city and zip code 
	 * @param user_id -> users id 
	 */
	$sql2 = "SELECT city, zipCode 
				FROM TblCustomer
				WHERE id = $user_id";

	// $options2 =  array('Scrollable' => SQLSRV_CURSOR_FORWARD);
	$result2 = sqlsrv_query( $conn , $sql2);
	$my_array = sqlsrv_fetch_array($result2); 

	if( $result2 === false  ) {
		die( print_r( sqlsrv_errors(), true));
	}

	if( sqlsrv_fetch( $result2 ) === false) {
		die( print_r( sqlsrv_errors(), true));
	}

	// Get query result fields
	$current_city = $my_array['city']; // User's city
	$current_zipCode = $my_array['zipCode']; // User's zip code

	/**
	 * Query for updating user's email, phone and id
	 * @param email_cookie -> user's emaul
	 * @param phoneNumber_cookie -> user's phone number
	 * @param user_id -> user's id
	 */
	$sql1 = "UPDATE TblSystemUser
				SET email= (?) , phone = (?)
				WHERE id =  (?) ";

	$params1 = array( $email_cookie, $phoneNumber_cookie , $user_id );
	$options1 =  array('Scrollable' => SQLSRV_CURSOR_FORWARD);
	$result1 = sqlsrv_query( $conn , $sql1, $params1, $options1);
	
	if( $result1 === false  ) {
		die( print_r( sqlsrv_errors(), true));
	}

	/**
	 * Query for updating user's city, zip code, street, building number, apartment number, load parameter and covid19 parameter
	 * @param city_cookie -> user's emaul
	 * @param zip_code_cookie -> user's phone number
	 * @param street_cookie -> user's emaul
	 * @param building_cookie -> user's phone number
	 * @param apartment_cookie -> user's emaul
	 * @param load_cookie -> user's phone number
	 * @param covid19Value_cookie -> user's emaul
	 * @param user_id -> user's id
	 */
	$sql4 = "UPDATE TblCustomer
				SET city= (?) , zipCode = (?), street=(?), bulidingNumber = (?), departmentNumber=(?), loadCust = (?), covid19Val = (?)
				WHERE id =(?)";

	$params4 = array( $city_cookie, $zip_code_cookie , $street_cookie, $building_cookie, $apartment_cookie, $load_cookie, $covid19Value_cookie, $user_id);
	$result4 = sqlsrv_query( $conn , $sql4, $params4);

	if( $result4 === false  ) {
		die( print_r( sqlsrv_errors(), true));
	}
	

	header("Location:customer_profile.php?msg=success");
	?>


	<!-- <div class="alert alert-success alert-dismissible fade show" role="alert">
	<strong> Updated Successfully!</strong> 
	<button type="button" class="close" data-dismiss="alert" aria-label="Close">
	  <span aria-hidden="true">&times;</span>
	</button> -->
  </div>
  
