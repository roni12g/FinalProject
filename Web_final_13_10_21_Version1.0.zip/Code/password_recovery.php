<?php 	

    /**
     * This file containes one input field form -> email address that will be sent to it recovery email 
     */

    // Include unregistered user's page layout 
    include 'index_layout.php';

    // require 'class.phpmailer.php';

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign in</title>
    <!-- <link rel="stylesheet" href="design.css"> -->
    <link rel="stylesheet" href="Styles/password_recovery.css">
    <!-- <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous"> -->

    
    
    <!-- Style Settings -->
    <style>
        input,
        label {
            display: block;
            margin: auto;
            width: 50%;
        }

        .sign-in-form {
            border: 3px solid gray;
        }
    </style>
</head>

<body>
    

    <?php 

            
    
    ?>
    

    <div class="sign-in-form">
    <!-- MAILTO:email-address -->

        <!-- Form contains 1 input filed for email address -->
        <form action="password_recovery_mail.php" method="post" >

        <?php
        /**
             * This code section refers to faulire / success messages
             */
            if (isset($_GET["msg"]) && $_GET["msg"] == 'success') { // If recovery email successfully sent, show success alert in this page

                // Echo the success alert
                
                echo"
                <div class='alert alert-success' role='alert'>
                    <strong> Password was successfully changed!</strong> From now on you have to use the new password.
                </div> ";
              
    
            }
            
            // If recovery email unsuccessfully sent, show failure alert in this page
            elseif (isset($_GET["msg"]) && $_GET["msg"] == 'failed') { 

                // Echo the failure alert
                echo"
                <div class='alert alert-danger' role='alert'>
                    <strong>Something went wrong. </strong> Please try again or contact us 
                </div> "; 
                
            }

            elseif (isset($_GET["msg"]) && $_GET["msg"] == 'not_identical') { 

                // Echo the failure alert
                echo"
                <div class='alert alert-danger' role='alert'>
                    <strong>The password and the repeat must be identical </strong> 
                </div> "; 
                
            }

            
            ?>

            <!-- Input field: password recovery -->
            <h2><b> Password Recovery </b></h2>
            <div class="input-group">
                <label for="email-address" class="input-group" id=input-label> Enter your registered email address: </label>
                <input type="email" class="input-group" id="input-text" name="email-address" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" required>
            </div>


            <!-- Foem send button -> action: 'password_recovery_mail' file  -->
            <button class="btn btn-success" name="send_pass_btn" id="send_pass_btn" type="submit"> Send </button>


        </form>
    </div>

    
</body>

</html>


