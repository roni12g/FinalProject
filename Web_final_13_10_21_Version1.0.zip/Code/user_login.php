<?php 

    /** 
     * This file contains the user login form
     */

    //Resume existing session
    session_start();

    // Include unregistered user's page layout 
    include 'index_layout.php';

    /**
     * More than 3 login attempts have been made -> handler
     * Locks the user for 10 seconds
     */
    if(isset($_SESSION["locked"])){

        // Calculate the difference between the current time to the time since the user has been locked out in seconds 
        $time_difference = time() - $_SESSION["locked"];

        if($time_difference > 600){ // If the 10 sec have been passed
            unset($_SESSION["locked"]); // Release the lock 
            unset($_SESSION["login_attempts"]); // Reset login attemots to zero
            header('location:user_login.php'); // Redirect to the current page => Refresh

        }

    }
       
    ?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign in</title>
    <link rel="stylesheet" href="Styles/user_login.css">
</head>

<!-- Styling Settings -->
<style>
    body {

        background-color: #eee;

    }
</style>

<script>

    /**
     * function that gets fired by event that returns only numbers input -> disables other characters 
     * @event onclick entering data input in form
     * @param evt 
     * @return boolean
     */
    function onlyNumberKey(evt) {
            
            // Only ASCII character in that range allowed
            var ASCIICode = (evt.which) ? evt.which : evt.keyCode
    
            // Check if the inserted charcter is a number in ASCII code
            if (ASCIICode > 31 && (ASCIICode < 48 || ASCIICode > 57))
                return false;
            return true;
        }

</script>

<body>
    <div class="login-form">

        <!--Login form which contains 2 inputs -->
        <form action="signin.php" method="post">
            <!-- <div class="error-message" role="alert"> -->
            
            <!-- Div error message code section -->
            <div class="error-message">
                <?php if (isset($_GET["msg"]) && $_GET["msg"] == 'failed') { // Ig DB authentication failed
                        // session_start();

                        if(isset($_SESSION["login_attempts"])){ // If login_attempts var has been set in the current session
                            $_SESSION["login_attempts"] += 1; // Increase the login_attempts session var by one
                            if($_SESSION["login_attempts"] >= 3){ // If the login_attempts session var value is graeter than 3 -> User tried 3 times to login
                                $_SESSION["locked"] = time(); // Set session lock by assign its value to the current time
                                echo "<p style='color: red;'> Your account is locked for 5 minutes </p>"; // Notify the user
                            }
                        }
                        else{ // If login_attempts var has is not set 
                            $_SESSION["login_attempts"] = 1; // Assign the login_attempts var to 1
                        }

                        echo "Wrong Username / Password"; 

                    ?>

                    <style>
                        .error-message {
                            color: red;
                            /* background-color:#ff7070;   */
                        }
                    </style>
                <?php
                } 
                   
            if(isset($message)) { echo $message; } ?></div>	<br>

            <h2 class="text-center">Sign In</h2>

            <div class="form-group">
                <div class="input-group">
                    <span class="input-group-addon"></span>
                    <input type="text" class="form-control" name="username" onkeypress="return onlyNumberKey(event)"  maxlength="9"  placeholder="ID Number" value="<?php if(isset($_COOKIE["member_login"])) { echo $_COOKIE["member_login"]; } ?>" required="required">
                </div>
            </div>

            <div class="form-group">
                <div class="input-group">
                    <span class="input-group-addon"></span>
                    <input type="password" class="form-control" name="password" placeholder="Password" value="" maxlength="12"
                        required="required">
                </div>
            </div>
            <?php
                // session_start();
                if(isset($_SESSION["login_attempts"]) && $_SESSION["login_attempts"] >= 3){
                    // print_r($_SESSION);
                    // echo "LOGIN ATTEMOTS IS SET";
                   
                    }
                

                else{
            ?>
            <div class="form-group">
                <button class="btn btn-success btn-lg btn-block" id="login-btn" type="submit" onclick="signin.php">Log in</button>
                <?php
                    if(isset($_SESSION["error"])){
                        $error = $_SESSION["error"];
                        echo "<span>$error</span>";
                    }
                ?>
            </div>
            <?php  }?>
            

            <!-- Element beneath the login input fileds me check box div -->
            <div class="clearfix">

                <!-- Remember me check box div -->
                <label class="pull-left checkbox-inline"><input type="checkbox" name = "remember" id="remember" <?php if(isset($_COOKIE["member_login"])) { ?> checked <?php } ?>> Remember me</label>

                <!-- Forgot password anchor div -->
                <a href="password_recovery.php" class="pull-right">Forgot Password?</a>
            </div>
            <br>

            <!-- Link to registration file if the user is not registered yet -->
            <p class="text-center small">Don't have an account? <a href="customer_registration.php">Sign up here</a>
            </p>
        </form>
    </div>
</body>

</html>