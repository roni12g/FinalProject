<?php 

    /** 
     * This file contains registered customers settings page
     */

    //Start Session:
    session_start(); 
    
    //Check if session is set, if not:(User is not signed in) -> redirect to index.php
    if(!isset($_SESSION['username']) ){
        session_destroy();    
        header("Location: index.php");
    }

    //If Session is set:---------------------------------
    include 'customer_layout.php'; 
        
    $user_session = $_SESSION['username']; // Get users id


    // If failed message has been passed -> email sending failed => Show alert message in this page
    if(isset($_GET['msg']) && ($_GET['msg']== "failed")){

        echo" 
            <div class='error-message' style='color:red;'> Something went wrong, please try again</div>
            ";
    }
    
    // If email message has been passed -> email sending succeed => Show alert message in this page
    elseif(isset($_GET['msg']) && ($_GET['msg']== "success")){

        echo"
            <div class='alert alert-success' style='color:green;' role='alert'>
            <strong> Your details were successfully updated!</strong> 
            </div> ";

        // echo" 
        //     <div class='error-message' style='color:red;'> Email successfuly sent. /n Please check your inbox/spam</div>
        //     ";
    }

   






?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="Styles/customer_profile.css">
    <!-- <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous"> -->

    
    <!-- Styling settings -->
    <style>

        .column {
            padding: 10px 20px;
            margin: 8px 0;
            height: 400px;
        }

        .lab{
            font-family: cursive;
            color: #446cb3;
            font-size: 14px;
            font-weight: bold
        }
        .column2 {
            padding-left : 110px;
            margin: 18px 0;
            height: 420px;
        }

        
        .row {
            padding: 10px 20px;
        margin: 8px 0;
        }

        .btn {
        color: white;
        padding: 10px 20px;
        margin: 8px 0;
        border: none;
        cursor: pointer;
        width: 8%;
        text-align: center;
        text-align: center;
        border-radius: 10px;
        font-family: cursive;

        }

        #save-btn {
        background-color: #4CAF50;
        color: white;
        padding: 10px 20px;
        margin: 8px 0;
        border: none;
        cursor: pointer;
        width: 8%;
        text-align: center;
        text-align: center;
        border-radius: 10px;
        font-family: cursive;

        }

        #save-btn:hover {
            background-color: #4CAF50;
            color: white
        }

        #edit-btn {
        background-color: #19b5fe;
        color: white;
        padding: 10px 20px;
        margin: 55PX 0;
        border: none;
        cursor: pointer;
        width: 10%;
        text-align: center;
        text-align: center;
        border-radius: 10px;
        font-family: cursive;

        }

        #delete-acc-btn {
        background-color: #cf000f;
        color: white;
        padding: 5px 6px;
        margin: 15PX 0;
        border: none;
        cursor: pointer;
        width: 6%;
        text-align: center;
        text-align: center;
        border-radius: 10px;
        font-family: cursive;

        }

        input[type=number] {
            -moz-appearance: textfield;
            
        }

        select{
            border-radius: 5px;
            height: 34.13px;
            width: 168.27px;
            border: 1px solid #696969
        }
        
        /* .fa {
            width: 40px;
        } */
    </style> <!-- End of styling section -->

    <script>


        var isDirty = false;
        var msg = 'You haven\'t saved your changes.';

        $(document).ready(function()
        {
            // Alert user about unsaved changes!
            $(':input').change(function(){
                if(!isDirty) isDirty = true;
            });

            window.onbeforeunload = function(){
                if(isDirty) return msg;
            };
        });


        function validateForm() {

            var email_input = document.forms["profile_edit_form"]["Email"].value;
            var phone_number_input = document.forms["profile_edit_form"]["phoneNumber"].value;
            var city_input = document.forms["profile_edit_form"]["City"].value;
            var street_input = document.forms["profile_edit_form"]["Street"].value;
            var zip_code_input = document.forms["profile_edit_form"]["zip_code"].value;
            var building_number_input = document.forms["profile_edit_form"]["building_number"].value;
            var apartment_input = document.forms["profile_edit_form"]["apartment_number"].value;
            var load_input = document.forms["profile_edit_form"]["load"].value;
            var covid19Value_input = document.forms["profile_edit_form"]["covid19Value"].value;

            var all_fileds_are_filled = true

            
            
            const inputs = [email_input, phone_number_input, city_input, street_input, zip_code_input, building_number_input, 
                                apartment_input, load_input, covid19Value_input];

            for (var i = 0; i < inputs.length; i++) {
                if (inputs[i]== null || inputs[i] == "" || inputs[i] == " ") {
                    alert("Please fill the " +  inputs[i] + " empty field. \nNo changes has been made");
                    all_fileds_are_filled=false;
                    return false;
                    break;
                }
            }

            if(!email_input.includes("@") || !email_input.includes(".com")){
                alert("Invalid email address. \nNo changes have been made");
                all_fileds_are_filled=false;
                return false;
            }


            if(phone_number_input.length < 10){
                alert("Phone number must be 10 digits. \nNo changes have been made");
                all_fileds_are_filled = false;
                return false;
            }

            if(zip_code_input.length < 5){
                alert("Phone number must be 5 digits. \nNo changes have been made");
                all_fileds_are_filled = false;
                return false;
            }

            else{
               return true;
            }

            


        } 
        
        /**
         * function that gets fired by event that returns only numbers input -> disables other characters 
         * @event onclick entering data input in form
         * @param evt 
         * @return boolean
         */
        function onlyNumberKey(evt) {
                
                // Only ASCII character in that range allowed
                var ASCIICode = (evt.which) ? evt.which : evt.keyCode

                // Check if the inserted charcter is a number in ASCII code
                if (ASCIICode > 31 && (ASCIICode < 48 || ASCIICode > 57))
                    return false;
                return true;
        }

        /**
         * function that gets fired by event that returns only letters input -> disables other characters 
         * @event onclick entering data input in form
         * @param evt 
         * @return boolean
         */
        function onlyLettersKey(evt) {
                
                // Only ASCII character in that range allowed
                var ASCIICode = (evt.which) ? evt.which : evt.keyCode

                // Check if the inserted charcter is a letter in ASCII code
                if ((ASCIICode > 64 && ASCIICode < 91) || (ASCIICode > 96 && ASCIICode < 123))
                    return true;
                return false;
        }


    </script>

</head>

<body>

    <?php 

        /**
         * Including/Calling DB connection
         * @return connection
         */
        require 'databaseconnection.php';


        /** Get parent page -> full path  */
        // $full_path_parent_page =  $_SERVER['HTTP_REFERER'];
        // $parent_page = substr($full_path_parent_page, strrpos($full_path_parent_page, '/') + 1);
        // echo $parent_page;
        // $_SESSION['parent_page_session'] =  $parent_page ;

        // Initialize cities array
        $cities_array = array();

        /**
         * Query for getting cities from TblCity table 
         */
        $city_sql = "SELECT city FROM TblCity";
        $cities_result = sqlsrv_query( $conn , $city_sql, array(), array("Scrollable" => 'static'));
        
        /** 
         * Looping over the result set -> Inserting each row data into the array
         * @param cities_array -> array
         * @param city_row -> query result row
         */
        while ($city_row = sqlsrv_fetch_array($cities_result)) {
            
            array_push($cities_array, $city_row);
        }

        // $detial = array();

        
        /**
         * Query for getting users detials -> 14 inputs 
         * @param user_session -> users id 
         */
        $sql = "SELECT tblS.id, tblS.firstName, tblS.lastName, tblS.email, tblS.phone, tblC.city, tblC.zipCode, tblC.street, tblC.bulidingNumber, tblC.departmentNumber, tblS.birthDate, tblC.loadCust, tblC.covid19Val, tblS.pass
                FROM TblCustomer as tblC join TblSystemUser as tblS on tblC.id = tblS.id
                Where tblC.id =  $user_session";
        $result = sqlsrv_query( $conn , $sql, array(), array("Scrollable" => 'static'));
        $row = sqlsrv_fetch_array($result);
       
        
        /**
         * Saving each data fie;d in a variable
         */

         // Personal information
        $user_id=  $row[0];
        $user_first_name =  $row[1];
        $user_last_name =  $row[2];
        $user_email =  $row[3];
        $user_phone =  $row[4]; 

        // Address information
        $user_city =  $row[5];
        $user_zipCode =  $row[6];
        $user_street =  $row[7];
        $user_building_number =  $row[8];
        $user_apartment_number =  $row[9];
        
        $user_birth_date =  $row[10];

        // Converting the users_covid19_val parameter from number to string accrodingly
        if($row[12] >= 0 && $row[12] <= 0.5 )
            $user_covid19_val = "Covid Free";
        else{
            $user_covid19_val = "Nevermind";
        }

        // Converting the loadParameter parameter from number to string accrodingly
        if($row[11] >= 0 && $row[11] <= 0.5)
            $user_load_customer = "Free";
        else{
            $user_load_customer = "Nevermind";
        }
        
        $user_password =  $row[13];

        $sql_address = "SELECT street
                        FROM TblAddress 
                        Where city like '$user_city' AND zipCode = '$user_zipCode'";

        $result_address = sqlsrv_query( $conn , $sql_address);

        if( $result_address === false ) {
            die( print_r( sqlsrv_errors(), true));
        }

        if( sqlsrv_fetch( $result_address ) === false) {
            die( print_r( sqlsrv_errors(), true));
        }

        $row_address = sqlsrv_get_field($result_address, 0); 
        
    ?>

    <input class="btn" type="button" name="delete-acc-btn" id="delete-acc-btn"
        value="Delete Account" onclick="deleteAccountAlert();"/> 


    <!-- Users profile form which contains 6 inputs -->
    <form action="profile_update_details.php" method="post" name="profile_edit_form" id="profile_edit_form"  enctype="multipart/form-data">
        <div class="row"> <!-- Form row section -->
            <div class="column">
             <label class = lab> Personal Information: </label>
             <br><br>

                <!-- First input field: ID Number -->
                <label for="id"> ID Number: </label>
                <input type="text" id="id" name="id" value="<?php echo $user_id; ?> "  disabled>
                <br><br>

                <!-- Second input field: First Name -->
                <label for="FirstName"> First Name: </label>
                <input type="text" id="FirstName" maxlength="15" name="FirstName"
                    value="<?php echo $user_first_name; ?> " disabled>
                <br><br>

                <!-- Third input field: Last Name -->
                <label for="LastName"> Last Name: </label>
                <input type="text" id="LastName" maxlength="15" name="LastName" value="<?php echo $user_last_name; ?> "
                    disabled>
                <br><br>

                <!-- Fourth input field: Email address -->
                <label for="Email"> Email: </label>
                <input type="text" id="Email" name="Email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" value="<?php echo $user_email; ?>" disabled>
                <br><br>

                <!-- Fifth input field: Phone number -->
                <label for="phoneNumber"> Phone Number: </label>
                <input type="tel" maxlength="10" minlength="10" onkeypress="return onlyNumberKey(event)" id="phoneNumber" name="phoneNumber"  pattern="\d{10}"
                    value="<?php echo $user_phone; ?> " required  disabled>
                <br><br>

                <!-- Sixth input field: City -->
                <label for="City"> City: </label>

                <select list="City_datalist" id="City" name="City" value="<?php echo $user_city; ?>"  onkeypress="return onlyLettersKey(event)"  disabled>

                    <?php 
                        
                        foreach ($cities_array as $value) {
                            
                            echo "<option> {$value['city']} </option>";
                        }
                    ?>
                </select>


                <br><br>

                <!-- Seventh input field: Street -->
                <label for="Street"> Street: </label>
                <input type="text" id="Street" name="Street" value="<?php echo $user_street; ?>" onkeypress="return onlyLettersKey(event)"  disabled>
                <br><br>

            </div>

            <div class="column">
                 <br>

                <!-- Eighth input field: zip code -->
                <label for="zip_code"> ZIP Code: </label>
                <input type="text" id="zip_code" name="zip_code" value="<?php echo $user_zipCode; ?>" maxlength="5" onkeypress="return onlyNumberKey(event)"  disabled>
                <br><br>

                <!-- Ninth input field: building number -->
                <label for="zip_code"> Building Number: </label>
                <input type="text" id="building_number" name="building_number" value="<?php echo $user_building_number; ?>" maxlength="3" onkeypress="return onlyNumberKey(event)"  disabled >
                <br><br>

                <!-- Tenth input field: building number -->
                <label for="zip_code"> Apartment Number: </label>
                <input type="text" id="apartment_number" name="apartment_number" value="<?php echo $user_apartment_number; ?>" maxlength="3" onkeypress="return onlyNumberKey(event)"  disabled >
                <br><br> 

                <!-- Eleventh input field: building number -->
                <label for="birthDate"> Birth Date: </label>
                <input type="text" id="birthDate" name="birthDate" 
                    value="<?php echo date_format($user_birth_date," Y/m/d") ?>" disabled >
                <br><br>

                <label class = lab> Travel Preferences: </label>
                <br><br>

                <!-- Twelfth input field: building number -->
                <div class="form-group">

                    <label for="load"> load: </label>
                    <!-- <input list="load_datalist" id="load" name="load" value="<?php// echo $user_load_customer; ?>" onkeypress="return onlyLettersKey(event)" disabled > -->

                    <select list="load_datalist" id="load" name="load" value="<?php echo $user_load_customer; ?>" onkeypress="return onlyLettersKey(event)"  disabled>

                        <option> Nevermind </option>
                        <option> Free Of Load </option>

                    </select>
                </div>
                <br><br>

                <!-- Thirteenth input field: Covid19 parameter -->
                <label for="covid19Value"> Covid-19: </label>
               
                <select list="covid19List" id="covid19Value" name="covid19Value"  name="covid19Value"
                    value="<?php echo $user_covid19_val; ?>" onkeypress="return onlyLettersKey(event)" disabled>

                    <option> Nevermind </option>
                    <option> Covid Free </option>
                </select>
                <br><br> <br><br> <br><br><br><br>

               

        
                <?php 

                    // /* Set up the Transact-SQL query. */  
                    // $tsql = "SELECT img   
                    //         FROM TblSystemUser   
                    //         WHERE id = $user_session";  
                    
                    // /* Set the parameter values and put them in an array. */  
                    // $userImageID = 70;  
                    // $params = array( $userImageID);  
                    
                    // /* Execute the query. */  
                    // $stmt = sqlsrv_query($conn, $tsql, $params);  
                    // if( $stmt === false ) {  
                    //     echo "Error in statement execution.</br>";  
                    //     die( print_r( sqlsrv_errors(), true));  
                    // }  
                    
                    // /* Retrieve and display the data.  
                    // The return data is retrieved as a binary stream. */  
                    // if ( sqlsrv_fetch( $stmt ) ) {  
                    // $image = sqlsrv_get_field( $stmt, 0,   
                    //                     SQLSRV_PHPTYPE_STREAM(SQLSRV_ENC_BINARY));  
                    // // header("Content-Type: image/jpg");  
                    // fpassthru($image);  
                    // }  
                    // else  {  
                    //     echo "Error in retrieving data.</br>";  
                    //     die(print_r( sqlsrv_errors(), true));  
                    // }  
                ?>

            </div>

            <!-- Edit fields button -->
            <button class="btn" type="submit" name="edit-btn" id="edit-btn" onclick="toggleEnable('edit-btn','Email')"
                value="Edit"> Edit </button>
            
        </div>
    </form>
    
    <script>

                    
        var loadFile = function (event) {
            var output = document.getElementById('output');
            output.style.height = '100px';
            output.style.width = '100px';
            output.src = URL.createObjectURL(event.target.files[0]);
            output.onload = function () {
                URL.revokeObjectURL(output.src) // free memory
            }
        };

        var click_counter = 0;

        /**
         * Function that is fired by onClick event which takes 2 parameters
         * @event onClick Edit button
         * @param btn {Object}
         * @param email {String}
         */
        function toggleEnable(btn, email) {

            // Get the email & edit button elements by Id
            var textbox = document.getElementById(email);
            var button = document.getElementById(btn);

            if (textbox.disabled == true) { // If the email input field is disabled
                
                // If disabled, do this :

                button.style.backgroundColor = "#5cb85c"; // Change edit buttton background color to green
                button.innerHTML = "Save"; // Change edit button text to "Save"

                // Change the relevant fields to editable (enabling them)
                document.getElementById("Email").disabled = false;
                document.getElementById("phoneNumber").disabled = false;
                document.getElementById("zip_code").disabled = false;
                document.getElementById("City").disabled = false;
                document.getElementById("Street").disabled = false;
                document.getElementById("load").disabled = false;
                document.getElementById("covid19Value").disabled = false;
                document.getElementById("building_number").disabled = false;
                document.getElementById("apartment_number").disabled = false;

                // Change the relevant fields to required fields
                document.getElementById("Email").required = true;
                document.getElementById("phoneNumber").required = true;
                document.getElementById("zip_code").required = true;
                document.getElementById("City").required = true;
                document.getElementById("Street").required = true;
                document.getElementById("load").required = true;
                document.getElementById("covid19Value").required = true;
                document.getElementById("building_number").required = true;
                document.getElementById("apartment_number").required = true;

                // Change the relevant fields border width to medium 
                document.getElementById("Email").style.borderWidth = "medium";
                document.getElementById("phoneNumber").style.borderWidth = "medium";
                document.getElementById("zip_code").style.borderWidth = "medium";
                document.getElementById("City").style.borderWidth = "medium";
                document.getElementById("Street").style.borderWidth = "medium";
                document.getElementById("load").style.borderWidth = "medium";
                document.getElementById("covid19Value").style.borderWidth = "medium";
                document.getElementById("building_number").style.borderWidth = "medium";
                document.getElementById("apartment_number").style.borderWidth = "medium";


            }

            else { // If the email input field is enabled => User changed his settings  =>Form must be sent 


                /**
                 * Getting all editable fields values (both that were changed and not)
                 */
                var email_1 = document.getElementById("Email").value;
                var phoneNumber_1 = document.getElementById("phoneNumber").value;
                var zip_code_1 = document.getElementById("zip_code").value;
                var city_1 = document.getElementById("City").value;
                var street_1 = document.getElementById("Street").value;
                var load_1 = document.getElementById("load").value;
                var covid19Value_1 = document.getElementById("covid19Value").value;
                var building_number_1 = document.getElementById("building_number").value;
                var apartment_number_1 = document.getElementById("apartment_number").value;

            
                button.style.backgroundColor = "#3e9dc9";
                button.innerHTML = "Edit";

                document.getElementById("Email").disabled = true;
                document.getElementById("phoneNumber").disabled = true;
                document.getElementById("zip_code").disabled = true;
                document.getElementById("City").disabled = true;
                document.getElementById("Street").disabled = true;
                document.getElementById("load").disabled = true;
                document.getElementById("covid19Value").disabled = true;
                document.getElementById("building_number").disabled = true;
                document.getElementById("apartment_number").disabled = true;

                /**
                * Creating cookies to be transeferd to the file that handles the form => Saving to DB
                */
                document.cookie = "email= " + email_1;
                document.cookie = "phoneNumber= " + phoneNumber_1;
                document.cookie = "zip_code= " + zip_code_1;
                document.cookie = "city= " + city_1;
                document.cookie = "load= " + load_1;
                document.cookie = "covid19Value= " + covid19Value_1;
                document.cookie = "street= " + street_1;
                document.cookie = "building_number= " + building_number_1;
                document.cookie = "apartment_number= " + apartment_number_1;

                var validation_result = validateForm();

                if(validation_result == true)
                    document.getElementById("profile_edit_form").submit();

                else{

                    button.style.backgroundColor = "#5cb85c"; // Change edit buttton background color to green
                button.innerHTML = "Save"; // Change edit button text to "Save"

                // Change the relevant fields to editable (enabling them)
                document.getElementById("Email").disabled = false;
                document.getElementById("phoneNumber").disabled = false;
                document.getElementById("zip_code").disabled = false;
                document.getElementById("City").disabled = false;
                document.getElementById("Street").disabled = false;
                document.getElementById("load").disabled = false;
                document.getElementById("covid19Value").disabled = false;
                document.getElementById("building_number").disabled = false;
                document.getElementById("apartment_number").disabled = false;

                // Change the relevant fields to required fields
                document.getElementById("Email").required = true;
                document.getElementById("phoneNumber").required = true;
                document.getElementById("zip_code").required = true;
                document.getElementById("City").required = true;
                document.getElementById("Street").required = true;
                document.getElementById("load").required = true;
                document.getElementById("covid19Value").required = true;
                document.getElementById("building_number").required = true;
                document.getElementById("apartment_number").required = true;

                // Change the relevant fields border width to medium 
                document.getElementById("Email").style.borderWidth = "medium";
                document.getElementById("phoneNumber").style.borderWidth = "medium";
                document.getElementById("zip_code").style.borderWidth = "medium";
                document.getElementById("City").style.borderWidth = "medium";
                document.getElementById("Street").style.borderWidth = "medium";
                document.getElementById("load").style.borderWidth = "medium";
                document.getElementById("covid19Value").style.borderWidth = "medium";
                document.getElementById("building_number").style.borderWidth = "medium";
                document.getElementById("apartment_number").style.borderWidth = "medium";


                }
            
            

                // return true;
                // var validation_result = validateForm();

                // if(validation_result == true){
                    // Submitting users settings form:
                        // document.getElementById("profile_edit_form").submit();
                // }

            }
        }


        /**
         * funtion that handles the delete account button alert
         * @return boolean
         */
        function deleteAccountAlert(){

            // Alerting the user about the deleting account action
            var retVal = confirm("You are about to delete your iTravel account!.\nAre you sure about that?");

            if( retVal == true ) { // If user confirmed to delete his account

                location.href = "delete_acc.php"; // Redirect to the page that handles the deleting functionality
                return true;
            } 
            else { // User clicked the cancel button
                return false; // No changes have been made
            }

        }

    </script>

    
</body>

</html>