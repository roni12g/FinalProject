<!-- <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

</html> -->

<?php 	

    /** 
     * This file contains the "phpMailer" driver -> for sending recovery emails 
     */

    // Calling the unregistered customer layout and including it
    include 'index_layout.php';

    // Get users email address from "password_recovery_mail.php" form
    $user_email_address = $_POST['email-address'];

    // require 'class.phpmailer.php';

    // Include PHPMailer sub folders
    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\SMTP;
    use PHPMailer\PHPMailer\Exception;

    // require_once __DIR__ . '\vendor\phpmailer\src\Exception.php';
    // require_once __DIR__ . '/vendor/phpmailer/src/PHPMailer.php';
    // require_once __DIR__ . '/vendor/phpmailer/src/SMTP.php';


    require 'vendor/autoload.php';


    // passing true in constructor enables exceptions in PHPMailer
    $mail = new PHPMailer(true); 

    // If the send button of "password_recovery_mail.php" form was clicked
    if(isset($_POST["send_pass_btn"])){
        
        $user_email_address = $_POST["email-address"]; // Get user's inserted email address

        /**
         * Query for checking if such inserted email address exists
         */
        $sql = "SELECT email FROM TblSystemUser WHERE email = '$user_email_address' ";
        $result = sqlsrv_query( $conn , $sql, array(), array("Scrollable" => 'static'));
        
        if( $result === false ) {
            die( print_r( sqlsrv_errors(), true));
        }

        if( sqlsrv_fetch( $result ) === false) {
            die( print_r( sqlsrv_errors(), true));
        }

        // If there is email address found
        if(sqlsrv_num_rows($result) == 1){

            try {
                // Server settings
                $mail->SMTPDebug = 0; // SMTP::DEBUG_SERVER; /* Printing connection and request-reply data */ // for detailed debug output
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com';
                $mail->SMTPAuth = true;
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port = 587;

                $mail->Username = 'itravel.no.reply1@gmail.com'; // iTravel gmail email
                $mail->Password = ' iTravel12349876'; // iTravel gmail password

                // Sender and recipient settings
                $mail->setFrom('itravel.no.reply1@gmail.com', 'iTravel');
                $mail->addAddress($user_email_address, 'User'); // Set recipient email address
                $mail->addReplyTo('itravel.no.reply1@gmail.com', 'iTravel'); // to set the reply to

                // Setting the email content
                $mail->IsHTML(true);
                $mail->Subject = "iTravel Password Recovery"; // Email subject 
                $mail->Body = 'Hello! <br>
                                Someone has requested a link to change your password. 
                                You can do this through the link below.<br>
                                <a href=http://localhost/Code/password_email_recovery_form.php> Change my password </a>.
                
                                If you didn\'t request this, please ignore this email.<br>
                
                                Your password won\'t change until you access the link above and create a new one.';

                $mail->AltBody = 'Plain text message body for non-HTML email client. Gmail SMTP email body.';

                $mail->send();
                
                echo "<script> window.open('password_recovery.php?msg=success', '_self');</script>";
                // header("location:password_recovery.php?msg=success");

                
                // echo "Email message sent.";

            } catch (Exception $e) {

                // If something went wrong:
                echo "Error in sending email. Mailer Error: {$mail->ErrorInfo}";
            }
        }
    
        else{

            // If number of one found email address is different than one 
            header("location:password_recovery.php?msg=failed");

            // echo "The Email Address You Entered, Doesn't Exist";
        }

    }
   


    


?>

