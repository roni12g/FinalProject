<?php
	
	/** 
     * This file contains the signin authentication code
     */

	//Start Session:
	session_start();

 	/**
     * Including/Calling DB connection
     * @return connection
     */	include 'databaseconnection.php';

	// Get entered id and password by user
    $newUsername = $_POST['username'];
	$newPassword = $_POST['password']; 

	$error = "Incorrect Username or Password ";
	

	$login_string = hash('sha512', $newUsername . $_SERVER['HTTP_USER_AGENT'] . time());
	
	// Check whether the remember check box was checked
	if(isset($_POST["remember me"])) {

		/**
		 * Create cookie for saving user id number
		 */
		$cookie_name  = 'user_str_session'; // Cookie name 
		$cookie_value = $login_string; // Cookie value -> login string
		setcookie($cookie_name, $cookie_value, time() + (86400 * 1), "/"); // Create the cookie
   
   }


  	/**
     * Query for retriving user's logging in details to be authenticated as logs later on 
     * @param newUsername -> Users' ID
     * @param newPassword -> User's Password
     */
	$sql = "SELECT * FROM TblSystemUser as su join TblCustomer as c on su.id=c.id WHERE su.id = '$newUsername' AND su.pass='$newPassword'";
	$result = sqlsrv_query( $conn , $sql, array(), array("Scrollable" => 'static'));
	$my_array = sqlsrv_fetch_array($result); //key:value [username:'u1']

	// Get the actual username and password from the query result
	$actual_username = $my_array["id"];
	$actual_password = $my_array["pass"];

	if(sqlsrv_num_rows($result) == 1){ // If query returned 1 row exactly => There is a user with the entered ID 
	
		
		if(isset($_POST["username"])&& isset($_POST["password"])) { // If username and password is checked
	
			// Actual authentication
			if($actual_username==$newUsername && $actual_password==$newPassword){ // If the actual id and password are suitable to the enetered id and password
				
				session_destroy(); // Destroy previous session
				session_start(); // Start a new session

				// Remember me Cookie functionality: 
				$_SESSION['username'] = $newUsername; // Set user's id as a session variable

				if(!empty($_POST["remember"])) { // If the "remember-me" check box has been checked
					setcookie ("member_login",$_POST["username"],time()+ (10 * 365 * 24 * 60 * 60)); // Set the cookie
				} 
				
				else { // If the "remember-me" check box has NOT been checked
					if(isset($_COOKIE["member_login"])) { //If the login cookie is set
						setcookie ("member_login",""); // Set the  member_login cookie's value to empty
					}
				}
				

				/**
				 * Query for getting logging in exact time that will be saved later on for logs purposes
				 */
				$sql = "SELECT CONVERT(VARCHAR(8), GETDATE(), 108);";
				$options =  array('Scrollable' => SQLSRV_CURSOR_FORWARD);
				$stmt = sqlsrv_query( $conn , $sql);
				
				if( $stmt === false ) {
					die( print_r( sqlsrv_errors(), true));
				}
			   
				if( sqlsrv_fetch( $stmt ) === false) {
				die( print_r( sqlsrv_errors(), true));
				}

				// Saving the above query result in a variables
				$current_sql_time = sqlsrv_get_field( $stmt, 0);
				
				/**
				 * Query for inserting user's logging in details to be used as logs later on 
				 * @param user_id -> Users ID
				 * @param logout string
				 * @param date
				 * @param current_sql_time
				 */
				$sql = "INSERT INTO TblLogInLogOut VALUES ( ? , ? , ? , ? );";
				$params = array( $newUsername, "login",  date("Y-m-d"), $current_sql_time );
				$options =  array('Scrollable' => SQLSRV_CURSOR_FORWARD);
				$result = sqlsrv_query( $conn , $sql, $params, $options);

				// If query is successfull 
				if( $sql ) {
					sqlsrv_commit( $conn );
				}

				// Redirect to "customer_page.pnp"
				echo "<script> window.open('customer_page.php', '_self');</script>";
			}
			
			else{ // The actual id and password are NOT identical to the enetered id and password
				

				session_start(); // Start a new session
				$_SESSION['error'] = 'ERROR: Invalid Username/Password'; // Set session var to the error message that will be shown to the user in signin file
				$_SESSION["login_attempts"] += 1; // Increased the login attempts in 1 => By 3 the system will be locked for specific time
				header('location:user_login.php?msg=failed'); // Redirect to "customer_page.pnp" with failure message

			}
		}
	}
	
	else{ // If query returned no rows =? There is no user registered with the given ID at all 
		header("location:user_login.php?msg=failed"); // Redirect to "customer_page.pnp" with failure message
	}


?>