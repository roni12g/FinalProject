
<?php


    /** 
     * This file contains the logout functionality of the registered user
     */


    //User session in ['user']


    /**
     * Including/Calling DB connection
     * @return connection
     */
    require "databaseconnection.php";

    //Start Session:
    session_start();

    $newUsername = $_SESSION["username"]; // Get users ID to be logged out from the syste,


    /**
     * Query for getting logging out exact time that will be saved later on for logs purposes
     */
    $sql = "SELECT CONVERT(VARCHAR(8), GETDATE(), 108);";
    $options =  array('Scrollable' => SQLSRV_CURSOR_FORWARD);
    $stmt = sqlsrv_query( $conn , $sql);
    
    if( $stmt === false ) {
        die( print_r( sqlsrv_errors(), true));
    }
    
    if( sqlsrv_fetch( $stmt ) === false) {
        die( print_r( sqlsrv_errors(), true));
    }

    // Saving the above query result in a variables
    $current_sql_time = sqlsrv_get_field( $stmt, 0);
   

    /**
     * Query for inserting user's logging out details to be used as logs later on 
     * @param user_id -> Users ID
     * @param logout string
     * @param date
     * @param current_sql_time
     */
    $sql = "INSERT INTO TblLogInLogOut VALUES ( ? , ? , ? , ? );";
    $params = array( $newUsername, "logout",  date("Y-m-d"), $current_sql_time ); // Parameters array
    $options =  array('Scrollable' => SQLSRV_CURSOR_FORWARD); // Setting the cursor to move one row at a time starting at starting from first row of the result set until you the end of the result set.
    $result = sqlsrv_query( $conn , $sql, $params, $options);

    // If query has been successfully executed commit 
    if( $sql ) {
        sqlsrv_commit( $conn );
    }

    /**
     * Deleting and removing all connection cookies
     */
    session_write_close();
    setcookie($_SESSION["username"],'',0,'/'); // Deleting main cookie
    unset($_SESSION["username"]);
    session_destroy();
    
    session_regenerate_id(true);
    header("Location: user_login.php"); // Redirect the user to the login page


?>