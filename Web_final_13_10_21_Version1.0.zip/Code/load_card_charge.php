<?php
	
     /** 
     * This file contains the algorithm of inserting money amount the DB
     */


     /**
     * Including/Calling DB connection
     * @return connection
     */
	include 'databaseconnection.php';


    /**
     * Saving the submitted details in variables:
     */
	$card_number = $_POST['travelCardNumber']; // Travel card number
    $wished_amount = $_POST['amount']; // Wished amount to load the card
    $current_amount = $_POST['CardNumberAmount']; // Current amount (before loading)

    $updated_amount = $current_amount + $wished_amount; // Updating money amount (current and wished amount)

    // If card number and wished amount inputs are setted
    if(isset($card_number) && isset($wished_amount)){


        /**
         * Query for updating the new money ammount 
         * @param updated_amount Integer-> New amount
         * @param card_number Integer -> Relevant card number
         */
        $sql = "UPDATE TblCard
                    SET moneyAmount = (?) 
                    WHERE cardNumber = (?) ";

        $params = array($updated_amount, $card_number);
        $result = sqlsrv_query( $conn , $sql, $params);


        if( $sql ) { // If everything is successful
            sqlsrv_commit( $conn ); // Commit transaction
            header("location:load_card.php?msg=success");

            
        } else { //Something went wrong
                sqlsrv_rollback( $conn ); // Rollbakc DB
                header("Location: load_card.php>msg=failed");
            
        }
        
    }


  
?>