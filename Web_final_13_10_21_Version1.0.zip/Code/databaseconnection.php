<?php
    

    /* This file contains Database connection info, it can be included in different pages */


    $serverName = "62.90.44.179\\sqlexpress, 1433"; //serverName\instanceName, portNumber (default is 1433)
    $connectionInfo = array( "Database"=>"travelsystem", "UID"=>"Admin", "PWD"=>"Daniel2021"); // DB Connection details
    $conn = sqlsrv_connect( $serverName, $connectionInfo); // Connection execution

    if( $conn ) { // Success case
          return $conn;
    }
    else{ // Failure Case
        echo "Connection could not be established.<br />";
        die( print_r( sqlsrv_errors(), true));
    }
     
       
?>
  