<?php 	


    include 'index_layout.php';

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign in</title>
    <!-- <link rel="stylesheet" href="design.css"> -->
    <link rel="stylesheet" href="Styles/password_recovery.css">
    
    <!-- Styling settings -->
    <style>
        input,
        label {
            display: block;
            margin: auto;
            width: 50%;
        }

        .sign-in-form {
            border: 3px solid gray;
        }
    </style>
</head>

<body>
<div class="signup-form">

    <!-- Change password form: post values  to password_change_DB.php file -->
    <form action="password_change_DB.php" method="post">

        <!-- Change password title-->
        <h2>Change Password</h2>
        
        <p class="hint-text"> Change Your Password</p>
        <div class="form-group">
            <div class="row"> <!-- Form row -->

                <div class="col-sm-6"> <!-- Form column -->

                    <div class="form-group"> <!-- First input: ID NUmber -->
                        <input type="number" class="form-control" name="id_number" placeholder="ID Number (9 Digits) " required="required">
                    </div>

                    <div class="form-group"> <!-- Second input: New Password -->
                    <input type="password" class="form-control" name="new_password" placeholder="New Password (At least 8 characters) " required="required">
                    </div>

                    <div class="form-group"> <!-- Third input: Repeat New Password -->
                    <input type="password" class="form-control" name="new_password_copy" placeholder="Copy New Password (At least 8 characters) " required="required">
                    </div>

                </div>

            </div>
        </div>

        <div class="form-group"> <!-- Submit button -->
            <button type="submit" class="btn btn-success btn-lg btn-block"> Submit</button>
        </div>
    </form>
</div>

    
</body>

</html>


