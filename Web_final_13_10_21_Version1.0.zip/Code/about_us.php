<?php 
    include "index_layout.php";

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous"> -->
    <link rel="stylesheet" href="Styles/about_us.css">

    <title>Document</title>

    <style>

        /* .container { 
            height: 50vh;
            position: relative;
        }

        p{
            text-align: center;
            font-size: large;
        }

        .center {
            margin: 0;
            position: absolute;
            top: 50%;
            left: 50%;
            -ms-transform: translate(-50%, -50%);
            transform: translate(-50%, -50%);
            
        }

        .row {
          display: flex;
        }

        .column {
          padding: 105px;
          margin-top: 0px;
        } */

        .center{
          margin-left: auto;
          margin-right:auto;
          display: block;
          margin: 0;
            position: absolute;
            top: 50%;
            left: 50%;
            -ms-transform: translate(-50%, -50%);
            transform: translate(-50%, -50%);
        }

        .center1{
            text-align: center;
            font-size: 20px;
        }

        .row {
          display: flex;
          align: center;

        }

        .column {
            flex: 33.33%;
            margin-top: 0px;
            width: 200px;
            padding-left: 10;
        }
        
    </style>

    
</head>
<body>
    
    <!-- <div class="d-flex justify-content-center">Hello there</div> -->



<br><br>
<div  class="description">

    <p class="center1"> 
        Welcome to our iTravel Routing Searching system! <br>
        We are 3 students from The Max Stern Academic College Of Emek Yezreel. <br>
        This is our B.Sc. final project which focuses on transportation scope. <br> The iTravel is a system which finds routes for the light rail passengers.
        <br>
        iTravel System does not only show relevant routes & planning routes, but also gives the registered customers the option to get the most suitable routes to their wish.

    </p>

</div>





<h2 class="center1"> <u> Team members </u> </h2>

<div class="row">

    <div align="center" class="column">

        <div class="flip-card">
            <div class="flip-card-inner">
                <div class="flip-card-front">
                    <img src="images/user.jpeg" alt="Avatar" style="width:200px;height:200px;">
                </div>
                <div class="flip-card-back">
                    <h1>Roni Guzovsky</h1> 
                    <p> Front & Back end</p> 
                    <p></p>
                </div>
            </div>
        </div>
    </div>


    <div align="center" class="column">

        <div class="flip-card">
            <div class="flip-card-inner">
                <div class="flip-card-front">
                    <img src="images/user.jpeg" alt="Avatar" style="width:200px;height:200px;">
                </div>
                <div class="flip-card-back">
                    <h1>Andreas Nseir</h1> 
                    <p> Front & Back end</p> 
                    <p></p>
                </div>
            </div>
        </div>
    </div>


    <div align="center" class="column">

        <div class="flip-card">
            <div class="flip-card-inner">
                <div class="flip-card-front">
                    <img src="images/user.jpeg" alt="Avatar" style="width:200px;height:200px;">
                </div>
                <div class="flip-card-back">
                    <h1>Sharon Garmay</h1> 
                    <p> Front end & Styling</p> 
                    <p></p>
                </div>
            </div>
        </div>
    </div>


    <!-- <h2>Roni Guzovsky</h2>
    <img src="images/user.jpeg" alt="Nabih.pic" width="150" height="150"></a>
    <b><p>22 years old</p>
    <p>Nabih_1998@hotmail.com</p>
    <p>0543833755</p></b>
  </div>


    <h2>Andreas Nusair</h2>
    <img src="images/user.jpeg" alt="Andrias.pic" width="150" height="150"></a>
    <b><p>22 years old</p>
    <p>andreasnusair@gmail.com</p>
    <p>0547784789</p></b>
  </div>

  <div align="center" class="column">
    <h2>Sharon Garmay</h2>
    <img src="images/user.jpeg" alt="images/user.jpeg" width="150" height="150"></a>
    <b><p>22 years old</p>
    <p>andreasnusair@gmail.com</p>
    <p>0547784789</p></b>
  </div>

</div> 


    <div class="container">
        <div class="center">

            <p> 
                We are 3 students from The Max Stern Academic College Of Emek Yezreel. <br>
                This is our B.Sc. final project which focuses on transportation scope. <br> The iTravel is a system which finds routes for the light rail passengers.
                <br>
                iTravel System does not only show relevant routes & planning routes, but also gives the registred customers the option to get the most suitable routes to their wish.
            </p>

        </div>

    </div> -->


<!-- 

    <div class="flip-card">

        <div class="row">

            
            <div class="column">
                <div class="flip-card-inner">
                    <div class="flip-card-front">
                        <img src="images/user.jpeg" alt="Avatar" style="width:150px;height:150px;">
                    </div>
                    <div class="flip-card-back">
                        <h1>Roni Guzovsky</h1> 
                        <p> Front & back end developer</p> 
                        <p> </p>
                    </div>
                </div>
            </div>

        

        </div>

    </div>

 -->



</body>
</html>