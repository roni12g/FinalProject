<?php 	
    
    /** 
     * This file contains the "lines & stations page of the unregistered/regular user
     */

    // Include the page layout of regular user
    include 'index_layout.php';
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="Styles/lines&stations.css">

</head>

<body>
    <!-- <div class="contant"> -->
    <div class="line-list"> <!-- Class section containing 3 sub-classes each class represents line color --> 
        <ul style="display: flex; margin-top: 50px; margin-left: 20%;">

            <!-- First Class -> Red line -->
            <div class="red-line" style="padding: 0 1em; margin-left: 30px;">
                <li id="red" onClick="showMap(this.id)">Red Line</li>  <!-- Show red line station map -->
                <p>From Petah Tikva through Bnei Brak, <br> Ramat Gan and Tel Aviv to Bat Yam</p>  <!-- Line description -->
                <a href="images/linesAndStations/red-line.jpg" target="_blank"> <!-- Linking to map picture -->
                    <img class="pic" id="red-pic" src="images/linesAndStations/red-line.jpg" alt="">
                </a>
            </div>

            <!-- Second Class -> Green line -->
            <div class="green-line" style="padding: 0 1em; margin-left: 30px;">
                <li id="green" onClick="showMap(this.id)">Green Line</li> <!-- Show green line station map -->
                <p>From Herzliya through Tel Aviv and <br> Holon to Rishon Lezion</p>  <!-- Line description -->
                <a href="images/linesAndStations/green-line.jpg" target="_blank"> <!-- Linking to map picture -->
                    <img class="pic" id="green-pic" src="images/linesAndStations/green-line.jpg" alt=""></a>
            </div>

            <!-- Third Class -> Purple line -->
            <div class="purple-line" style="padding: 0 1em; margin-left: 30px;">
                <li id="purple" onClick="showMap(this.id)">Purple Line</li>  <!-- Show purple line station map -->
                <p>From Tel Aviv through Ramat Gan,<br> Givat Shmuel, Or Yehuda to Yehud</p> <!-- Line description -->
                <a href="images/linesAndStations/purple-line.jpg" target="_blank"> <!-- Linking to map picture -->
                    <img class="pic" id="purple-pic" src="images/linesAndStations/purple-line.jpg" alt=""></a>
            </div>

        </ul>
    </div>


    <!-- <div class="side-pic">
            <img src="images/map.png" alt="" style="float: right;" width="30%"
            height="100%">
        </div> -->
    <!-- </div> -->
</body>

<script>


    /**
     * function that is called once one of the lines names is clicked
     * @param clicked_id {event}
     */
    function showMap(clicked_id) {
        let color = clicked_id; // Get the color of the clicked title via its id
        document.getElementById(color + "-pic").classList.toggle('show'); // Toggle the selected map 
    }

</script>

</html>