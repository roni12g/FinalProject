<?php 

    /** 
     * This file is the page layout code including styling for registered customers
     */

    /**
     * Including/Calling DB connection
     * @return connection
     */
    include "databaseconnection.php"; 
         
    ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Page Settings -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>i-Travel</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="icon" type="image/ico" href="images/favicon.ico">
    <link rel="stylesheet" href="Styles/customer_layout.css">
</head>

<!-- Styling settings -->
<style>
    .header {
        width: 100%;
        height: 100px;
        display: flex;
    }

    .logo {
        display: block;
        margin-left: auto;
        margin-right: auto;
        text-align: center;
        width: fit-content;
        cursor: pointer;
    }

    .fa {
        width: 16px;
        padding: 12px;
        font-size: 15px;
        text-align: center;
        text-decoration: none;
        margin: 5px 2px;
        color: white;
        border-radius: 50%;
    }

    .fa:hover {
        opacity: 0.7;
    }

    .fa-facebook {
        background: #3B5998;
    }

    .fa-youtube {
        background: #bb0000;
    }

    .fa-instagram {
        background: #8a3ab9;
    }

    #lines:hover, #search:hover {
        background-color: #4CAF50;
        color: white;
    }
</style>

<body>
    <div class="all_site">
        <div class="header">
            <?php     

            $user_id = $_SESSION["username"]; // Get users ID from the active session

            /**
             * Query for getting the users img 
             * @param user_session -> Users ID
             * @param starting_date -> First date of the report
             * @param ending_date -> Last date of the report
             */

            $sql = "SELECT img FROM TblSystemUser where id='$user_id'";
            $result = sqlsrv_query($conn, $sql);
            $my_array = sqlsrv_fetch_array($result); 

            $image_src = "images/users_images/icon.jpg";
            
            $source_dir = "images/users_images/";
            $user_img = $my_array[0];
            $img = ($source_dir.$user_img);


                ?>
            <!-- <div class="user-pic">
                <img id="user pic" src="<?php echo $image_src; ?>" alt="user picture" width="100" height="100">
            </div> -->
            <!-- Users image settings -->
            <div class="user-pic" style="display: grid; position: fixed; z-index: 1;"">
                <img id="user pic" src="images/users_images/<?php echo $user_id; ?>" onerror="this.onerror=null; this.src='./images/user.jpeg'" alt="user picture" width="65" height="60"
                    style="margin-top:20px; border-radius: 50%; margin-left:15px">

                <?php 
                    
                    echo "ID: ".$user_id; //Printing users ID number
                    ?>
            </div>
            <!-- Logo settings image -->
            <div class="logo">
                <img src="images/logo.JPG" onclick="window.location.href ='customer_page.php'" alt="company logo"
                    width="300" height="100">
            </div>
        </div>

        <!-- Menu Settings -->
        <div class="topnav">

            <!-- Search Route dropdown settings -->
            <div class="dropdown">
                <a id="search" href="customer_page.php"> Search Route</a>
            </div>

            <!-- Lines & Stations dropdown settings -->
            <div class="dropdown">
                <a id="lines" href="lines&stations_customer.php"> Lines & Stations</a>
            </div>

            <!-- My Info dropdown settings -->
            <div class="dropdown">
                <button class="dropbtn">My Info
                    <i class="fa fa-caret-down"></i>
                </button>

                <!-- My Info dropdown content settings -->
                <div class="dropdown-content">
                    <a href="#about" onclick="window.location.href ='customer_profile.php';">Profile</a>
                    <a href="#exit" onclick="window.location.href ='password_change.php';"> Change Password</a>
                    <a href="#exit" onclick="window.location.href ='load_card.php';"> Charge Card</a>

                </div>
            </div>

            <!-- Journey planner dropdown settings -->
            <div class="dropdown">
                <button class="dropbtn"> Journey Planner
                    <i class="fa fa-caret-down"></i>
                </button>

                <!-- Journey planner dropdown content settings -->
                <div class="dropdown-content">
                    <a href="#table3" onclick="window.location.href ='customer_history_search.php';"> Search History</a>
                    <a href="#exit" onclick="window.location.href ='recent_travels.php';"> Recent Travels</a>

                </div>
            </div>

            <!-- Hebrew dropdown settings -->
            <i class="fa fa-sign-out" onclick="window.location.href ='index_logout.php';" aria-hidden="true"
                style="cursor: pointer; float: right; margin-right: 30px;" data-toggle="tooltip" title="Logout"></i>
            <a href="#cust2" onclick="window.location.href ='#lang.php';" style="float: right;"> HE </a>

        </div>

        <!-- Page footer social media -->
        <div class="footer">
            <div class="exetrnal-links" style="margin-left: 50px;">
                <!-- Referncing to social media  -->
                <div id="social-media">
                    <a href="https://www.facebook.com/NTAIsrael" target="_blank" class="fa fa-facebook"></a>
                    <a href="https://www.youtube.com/user/ntalines" target="_blank" class="fa fa-youtube"></a>
                    <a href="https://www.instagram.com/nta_israel" target="_blank" class="fa fa-instagram"></a>
                </div>
            </div>

            <!-- Page footer center settings -->
            <p style="position: fixed; left:0; bottom:0; width: 100%; text-align: center; height: auto;"> &copy; YVC - Final Project
                <script>
                    let d = new Date();
                    let m = d.getMonth() + 1;
                    document.write(" " + d.getDate() + "/" + m + "/" + d.getFullYear());
                </script>
            </p>

            <a href="https://www.nta.co.il/" target="_blank" style="color: #337ab7; text-decoration: underline;">Contact
                Us</a>
        </div>

        <div>
            <p class="clear"></p>
        </div>
    </div>

</body>

</html>