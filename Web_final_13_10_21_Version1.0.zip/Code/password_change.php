<?php 

    /** 
     * This file contains the chamge password form. This form is reachable only from inside the system. 
     */

    //Start Session:
    session_start();    

    //Check if session is set, if not:(User is not signed in) -> redirect to index.php
    if(!isset($_SESSION['username']) ){
        session_destroy();    
        header("Location: index.php");
    }



    //If Session is set:---------------------------------
    include 'customer_layout.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Registration Form</title>
    <link rel="stylesheet" href="Styles/customer_registration.css">
</head>

<!-- Styling settings -->
<style>
    body {
        background-color: #eee;
    }

    .form-group {
        display: inline-flex;
        color: black;
        font-weight: 700;
        font-size: 14px;
        margin-left: 20.5%;

    }

    .form-control {
        height: 20px;
        width: 196.8px;
        padding: 6px 12px;
        font-family: cursive;
        display: inherit;
        border-radius: 4px;
        border: 1px solid #ccc;
        outline: none;

    }

    .form-control:focus {
        border: 1px solid #66afe9;
    }

    #apply_btn {
        color: #fff;
        background-color: #5cb85c;
        border-color: #4cae4c;
        display: inline-block;
        margin-bottom: 0;
        font-weight: 400;
        text-align: center;
        white-space: nowrap;
        vertical-align: middle;
        touch-action: manipulation;
        cursor: pointer;
        background-image: none;
        border: 1px solid transparent;
        padding: 6px 12px;
        font-size: 14px;
        line-height: 1.42857143;
        border-radius: 4px;
        margin-left: 42.5%;
        font-family: cursive;

    }
</style>

<script>


    /**
     * function that gets fired by event that returns only numbers input -> disables other characters 
     * @event onclick entering data input in form
     * @param evt 
     * @return boolean
     */
    function onlyNumberKey(evt) {
            
        // Only ASCII character in that range allowed
        var ASCIICode = (evt.which) ? evt.which : evt.keyCode

        // Check if the inserted charcter is a number in ASCII code
        if (ASCIICode > 31 && (ASCIICode < 48 || ASCIICode > 57))
            return false;
        return true;
    }

    /**
    * function that gets fired by event that returns only letters input -> disables other characters 
    * @event onclick entering data input in form
    * @param evt 
    * @return boolean
    */
    function onlyLettersKey(evt) {
            
        // Only ASCII character in that range allowed
        var ASCIICode = (evt.which) ? evt.which : evt.keyCode

        // Check if the inserted charcter is a letter in ASCII code
        if ((ASCIICode > 64 && ASCIICode < 91) || (ASCIICode > 96 && ASCIICode < 123))
            return true;
        return false;
    }



</script>

<body>
    
    <div class="signup-form">

        <!-- Change password form which contains 3 inputs -->
        <form action="password_change_DB.php" method="post">
            <?php
                // If failed message has been passed -> email sending failed => Show alert message in this page
                if(isset($_GET['msg']) && ($_GET['msg']== "failed")){

                    echo" 
                        <div class='error-message' style='color:red;'> Something went wrong, please try again</div>
                        ";
                }
                
                // If email message has been passed -> email sending succeed => Show alert message in this page
                if(isset($_GET['msg']) && ($_GET['msg']== "success")){

                    echo"
                        <div class='alert alert-success' style='color:green;' role='alert'>
                        <strong> Password was successfully changed!</strong> From now on you have to use the new password.
                        </div> ";

                    // echo" 
                    //     <div class='error-message' style='color:red;'> Email successfuly sent. /n Please check your inbox/spam</div>
                    //     ";
                }

                elseif(isset($_GET['msg']) && ($_GET['msg']== "not_identical")){

                    echo"
                    <div class='alert alert-danger' style='color:red;' role='alert'>
                        <strong>The password and the repeat must be identical </strong> 
                    </div> "; 

                    // echo" 
                    //     <div class='error-message' style='color:red;'> Email successfuly sent. /n Please check your inbox/spam</div>
                    //     ";
                }

            ?>

            <h2 class="hint-text" style=" color: black; font-size: 18px;"> Change Your Password</h2>
            <!-- <div class="form-group"> -->
            <div class="row"> <!-- Form row section -->
                
                <div class="col-sm-6"> <!-- Form column div -->

                    <!-- First input field: Current/actual password -->
                    <div class="form-group">
                        <label> Current Password:</label>
                        <input type="password" class="form-control"  name="old_password" required
                            style="margin-left: 37px;" placeholder="Insert your current password">
                    </div>

                    <!-- Second input field: New password that is wished to be changed to -->
                    <div class="form-group">
                        <label> New Password:</label>
                        <input type="password" class="form-control" pattern=".{8,}" name="new_password" required
                            style="margin-left: 60px;" placeholder="(At least 8 characters)">
                    </div>

                    <!-- Third input field: Repeat the new password that is wished to be changed to-->
                    <div class="form-group">
                        <label> Repeat New Password:</label>
                        <input type="password" class="form-control" pattern=".{8,}" name="new_password_copy"
                            required="required" style="margin-left: 8px;"  placeholder="Confirm Password">
                    </div>

                </div> <!-- End of form column div -->

            </div> <!-- End form row section -->
            <!-- </div> -->

            <!-- Apply form button -->
            <button id="apply_btn" type="submit" onclick="signin.php"> Apply </button>

        </form> <!-- End Of Form -->
    </div>

</body>

</html>