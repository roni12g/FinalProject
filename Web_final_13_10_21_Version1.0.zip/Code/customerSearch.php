<?php


  /** 
   * This file contains teh search algorithm for registered customers (includong load and covid19)   */

session_start(); 

if(!isset($_SESSION['username']) ){
    session_destroy();
    header("Location: index.php");
}


$source_station=$_POST['source_station'];
$travelDate=$_POST['travelDate'];
$destination_station=$_POST['destination_station'];
$time=$_POST['time'];
$sameLineColor=0;
$covid19val = $_POST['covid19Value'];
$loadValue = $_POST['load'];
$userName=$_POST['text'];
require 'databaseconnection.php';

/*source primary station*/
$sql = "select TblStation.primaryLine from TblStation where TblStation.stationName like '$source_station'";
$stmt = sqlsrv_query( $conn, $sql);


   if( $stmt === false ) {
     die( print_r( sqlsrv_errors(), true));
   }

   if( sqlsrv_fetch( $stmt ) === false) {
     die( print_r( sqlsrv_errors(), true));
   }
   $sourcePrimaryStation = sqlsrv_get_field( $stmt, 0);

/*source secondary station*/
   $sql = "select TblStation.secondaryLine from TblStation where TblStation.stationName like '$source_station'";
   $stmt = sqlsrv_query( $conn, $sql);
      if( $stmt === false ) {
        die( print_r( sqlsrv_errors(), true));
      }

      if( sqlsrv_fetch( $stmt ) === false) {
        die( print_r( sqlsrv_errors(), true));
      }
    $sourceSecondaryStation = sqlsrv_get_field( $stmt, 0);


/*destination primary station*/
$sql = "select TblStation.primaryLine from TblStation where TblStation.stationName like '$destination_station'";
$stmt = sqlsrv_query( $conn, $sql);


   if( $stmt === false ) {
     die( print_r( sqlsrv_errors(), true));
   }

   if( sqlsrv_fetch( $stmt ) === false) {
     die( print_r( sqlsrv_errors(), true));
   }
   $destinationPrimaryStation = sqlsrv_get_field( $stmt, 0);

/*destination secondary station*/
   $sql = "select TblStation.secondaryLine from TblStation where TblStation.stationName like '$destination_station'";
   $stmt = sqlsrv_query( $conn, $sql);
      if( $stmt === false ) {
        die( print_r( sqlsrv_errors(), true));
      }

      if( sqlsrv_fetch( $stmt ) === false) {
        die( print_r( sqlsrv_errors(), true));
      }
    $destinationSecondaryStation = sqlsrv_get_field( $stmt, 0);

/*get hour and minute*/
$hour = substr($time,0,2);
$min = substr($time,3,5);
$max = $min+20;

$junctionFirstSameAsSecondColor='a';
/*case if junction station is first station-> like same line colors*/
   $sql = "select t.secondaryStationName from TblStation as t where t.isJunction=1 and t.secondaryLine='$destinationPrimaryStation' and t.stationName = '$source_station'";
   $stmt = sqlsrv_query( $conn, $sql);
      if( $stmt === false ) {
        die( print_r( sqlsrv_errors(), true));
      }

      if( sqlsrv_fetch( $stmt ) === false) {
        die( print_r( sqlsrv_errors(), true));
      }
    $junctionFirstSameAsSecondColor = sqlsrv_get_field( $stmt, 0);


if($junctionFirstSameAsSecondColor != ''){
    $source_station = $junctionFirstSameAsSecondColor;
    $sourcePrimaryStation=$destinationPrimaryStation;
}


/*serch result for same line color*/
if($sourcePrimaryStation==$destinationPrimaryStation){
$sameLineColor=1;
/*check direction*/
  /*check source station number*/
   $sql = "select TblStation.stationNumber from TblStation where TblStation.stationName like '$source_station' ";
   $stmt = sqlsrv_query( $conn, $sql);
      if( $stmt === false ) {
        die( print_r( sqlsrv_errors(), true));
      }

      if( sqlsrv_fetch( $stmt ) === false) {
        die( print_r( sqlsrv_errors(), true));
      }
    $sourceStationNumber = sqlsrv_get_field( $stmt, 0);

  /*check destination station number*/

   $sql = "select TblStation.stationNumber from TblStation where TblStation.stationName like '$destination_station' ";
   $stmt = sqlsrv_query( $conn, $sql);
      if( $stmt === false ) {
        die( print_r( sqlsrv_errors(), true));
      }

      if( sqlsrv_fetch( $stmt ) === false) {
        die( print_r( sqlsrv_errors(), true));
      }
    $destinationStationNumber = sqlsrv_get_field( $stmt, 0);

    if(($destinationStationNumber-$sourceStationNumber)>0){
    $direction=0;
    }
    if (($destinationStationNumber-$sourceStationNumber)<0){
    $direction=1;
    }


    if($covid19val=="Nevermind"){
        $covid=1;
    }
    if($covid19val=="Covid Free"){
        $covid=0;
    }

    if($loadValue=="Nevermind"){
        $load=1;
    }
    if($loadValue=="Free"){
        $load=0.5;
    }

        $searchRes = array();
        if($covid==1){
        $sql = " select distinct  s.*
                from TblRoute r inner join TblStopsIn s on r.sourceStationName=s.startStation and r.destStationName=s.endStation and r.routeDate=s.stopDate
                where r.routeDate like '$travelDate' and r.startHour = $hour and r.endHour = $hour and s.stationName like '$source_station' and s.stopMinute>=$min and s.stopHour=$hour and s.direction=$direction
                and s.stopMinute<=$max and s.covid19InOut <= 1 and s.loadParameter<=$load ";

        $result = sqlsrv_query( $conn , $sql, array(), array("Scrollable" => 'static'));

        while ($selectedItem = sqlsrv_fetch_array($result)) {
            array_push($searchRes, $selectedItem);
        }
        }

        else if($covid==0){
                     $sql = " select distinct  s.*
                             from TblRoute r inner join TblStopsIn s on r.sourceStationName=s.startStation and r.destStationName=s.endStation and r.routeDate=s.stopDate
                             where r.routeDate like '$travelDate' and r.startHour = $hour and r.endHour = $hour and s.stationName like '$source_station' and s.stopMinute>=$min and s.stopHour=$hour and s.direction=$direction
                             and s.stopMinute<=$max and s.covid19InOut <= 0 and s.loadParameter<=$load ";

                     $result = sqlsrv_query( $conn , $sql, array(), array("Scrollable" => 'static'));

                     while ($selectedItem = sqlsrv_fetch_array($result)) {
                         array_push($searchRes, $selectedItem);
                     }
                     }



         $sql = "SELECT DATEPART(HOUR, GETDATE())";
                $stmt = sqlsrv_query( $conn, $sql);
                if( $stmt === false ) {
                 die( print_r( sqlsrv_errors(), true));
                }

               if( sqlsrv_fetch( $stmt ) === false) {
                 die( print_r( sqlsrv_errors(), true));
                }
              $nowHour = sqlsrv_get_field( $stmt, 0);

         $sql = "SELECT DATEPART(MINUTE, GETDATE())";
                $stmt = sqlsrv_query( $conn, $sql);
                if( $stmt === false ) {
                 die( print_r( sqlsrv_errors(), true));
                }

               if( sqlsrv_fetch( $stmt ) === false) {
                 die( print_r( sqlsrv_errors(), true));
                }
              $nowMinute = sqlsrv_get_field( $stmt, 0);

        $sql = "select t.city  from TblStation as t where t.stationName like '$source_station'";
                $stmt = sqlsrv_query( $conn, $sql);
                if( $stmt === false ) {
                 die( print_r( sqlsrv_errors(), true));
                }

               if( sqlsrv_fetch( $stmt ) === false) {
                 die( print_r( sqlsrv_errors(), true));
                }
              $sCity = sqlsrv_get_field( $stmt, 0);

                $sql = "select t.city  from TblStation as t where t.stationName like '$destination_station'";
                $stmt = sqlsrv_query( $conn, $sql);
                if( $stmt === false ) {
                 die( print_r( sqlsrv_errors(), true));
                }

               if( sqlsrv_fetch( $stmt ) === false) {
                 die( print_r( sqlsrv_errors(), true));
                }
              $dCity = sqlsrv_get_field( $stmt, 0);

 $sql = "SELECT Convert(varchar(10), GETDATE(),120) ";
        $stmt = sqlsrv_query( $conn, $sql);
        if( $stmt === false ) {
         die( print_r( sqlsrv_errors(), true));
        }

       if( sqlsrv_fetch( $stmt ) === false) {
         die( print_r( sqlsrv_errors(), true));
        }
      $nowDate = sqlsrv_get_field( $stmt, 0);

              $sql1 = "INSERT INTO TblCustSearch  VALUES ('$userName','$nowDate',$nowHour,$nowMinute,'$source_station','$destination_station'
              ,'$sCity','$dCity',$covid,$load)";

        			$params1 = array();
        			$options1 =  array('Scrollable' => SQLSRV_CURSOR_FORWARD);
        			$result1 = sqlsrv_query( $conn , $sql1, $params1);

	if($sql1) {
	sqlsrv_commit( $conn );
	}



       if(count($searchRes)==0){
            $sameLineColor=-1;
            echo"
            <div class='alert alert-danger' style='color:red; margin-bottom: 0px; font-size: 20px;' role='alert'>
                 Routes Not Found. Try Different Stations/Time  
                
            </div> ";

            // echo "<script type='text/javascript'> alert('Routes Not Found ,Try Different Stations/Time')</script>";

        }
}

if($sourcePrimaryStation!=$destinationPrimaryStation){
$sourceInd=0;
$destInd=0;
$junctionStationName='a';
$junctionStationInd=0;
$sameLineColor=0;

   if($covid19val=="Nevermind"){
        $covid=1;
    }
    if($covid19val=="Covid Free"){
        $covid=0;
    }

    if($loadValue=="Nevermind"){
        $load=1;
    }
    if($loadValue=="Free"){
        $load=0.5;
    }

 $sql = "select TblStation.stationNumber from TblStation where TblStation.stationName like '$source_station' ";
 $stmt = sqlsrv_query( $conn, $sql);
    if( $stmt === false ) {
      die( print_r( sqlsrv_errors(), true));
    }

    if( sqlsrv_fetch( $stmt ) === false) {
      die( print_r( sqlsrv_errors(), true));
    }
 $sourceInd = sqlsrv_get_field( $stmt, 0);

 $sql = "select TblStation.stationNumber from TblStation where TblStation.stationName like '$destination_station' ";
 $stmt = sqlsrv_query( $conn, $sql);
    if( $stmt === false ) {
      die( print_r( sqlsrv_errors(), true));
    }

    if( sqlsrv_fetch( $stmt ) === false) {
      die( print_r( sqlsrv_errors(), true));
    }
 $destInd = sqlsrv_get_field( $stmt, 0);



 $junctionRes = array();
 $sql = "select top 1 s.stationNumber,s.stationName,s.secondaryStationName, abs($sourceInd-s.stationNumber) as sourceStationFromHtml
           from TblStation as s
           where s.isJunction=1 and s.primaryLine='$sourcePrimaryStation' and s.secondaryLine='$destinationPrimaryStation'
           order by sourceStationFromHtml";

$result = sqlsrv_query( $conn , $sql, array(), array("Scrollable" => 'static'));

           while ($selectedItem = sqlsrv_fetch_array($result)) {
               array_push($junctionRes, $selectedItem);
           }


$junctionStationNumber =  $junctionRes[0]['stationNumber'] ;
$junctionPrimaryStation = $junctionRes[0]['stationName'] ;
$junctionSecondaryStation = $junctionRes[0]['secondaryStationName'];

 $sql = "select TblStation.stationNumber from TblStation where TblStation.stationName like '$junctionSecondaryStation' ";
 $stmt = sqlsrv_query( $conn, $sql);
    if( $stmt === false ) {
      die( print_r( sqlsrv_errors(), true));
    }

    if( sqlsrv_fetch( $stmt ) === false) {
      die( print_r( sqlsrv_errors(), true));
    }
 $junc2ndStationNumber= sqlsrv_get_field( $stmt, 0);

 if($sourceInd < $junctionStationNumber){
         $direction=0;
 }
 if($sourceInd > $junctionStationNumber){
         $direction=1 ;
 }

  if($junc2ndStationNumber < $destInd){
         $direction2ndLine=0;
 }
 if($junc2ndStationNumber > $destInd){
         $direction2ndLine=1 ;
 }



 $searchResFirstLine = array();
 if($covid==1){
 $sql = "select distinct s.trainNumber,s.stationName,s.stopDate,s.passengersInTrain,s.startStation,s.endStation
           ,s.covid19InOut,s.loadParameter,s.direction,s.stopMinute,s.stopHour
             ,juncMinute=(select top 1 s1.stopMinute
           from TblRoute r1 inner join TblStopsIn s1 on r1.sourceStationName=s1.startStation and r1.destStationName=s1.endStation
              where r1.routeDate like '$travelDate' and r1.startHour = $hour and r1.endHour = $hour and s1.stationName like '$junctionPrimaryStation' and  s1.stopHour=$hour and s1.direction=$direction and s.trainNumber=s1.trainNumber
            )
            from TblRoute r inner join TblStopsIn s on r.sourceStationName=s.startStation and r.destStationName=s.endStation and r.routeDate=s.stopDate
              where r.routeDate like '$travelDate' and r.startHour = $hour and r.endHour = $hour and s.stationName like '$source_station' and s.stopMinute>=$min and s.stopHour=$hour and s.direction=$direction
              and s.stopMinute<=$max and s.covid19InOut <= 1 and s.loadParameter<=$load";

        $result = sqlsrv_query( $conn , $sql, array(), array("Scrollable" => 'static'));
        while ($selectedItem = sqlsrv_fetch_array($result)) {
            array_push($searchResFirstLine, $selectedItem);
        }
 }

 else if($covid==0){
        $sql = "select distinct s.trainNumber,s.stationName,s.stopDate,s.passengersInTrain,s.startStation,s.endStation
                  ,s.covid19InOut,s.loadParameter,s.direction,s.stopMinute,s.stopHour
                    ,juncMinute=(select top 1 s1.stopMinute
                  from TblRoute r1 inner join TblStopsIn s1 on r1.sourceStationName=s1.startStation and r1.destStationName=s1.endStation
                     where r1.routeDate like '$travelDate' and r1.startHour = $hour and r1.endHour = $hour and s1.stationName like '$junctionPrimaryStation' and  s1.stopHour=$hour and s1.direction=$direction and s.trainNumber=s1.trainNumber
                   )
                   from TblRoute r inner join TblStopsIn s on r.sourceStationName=s.startStation and r.destStationName=s.endStation and r.routeDate=s.stopDate
                     where r.routeDate like '$travelDate' and r.startHour = $hour and r.endHour = $hour and s.stationName like '$source_station' and s.stopMinute>=$min and s.stopHour=$hour and s.direction=$direction
                     and s.stopMinute<=$max and s.covid19InOut <= 0 and s.loadParameter<=$load";

               $result = sqlsrv_query( $conn , $sql, array(), array("Scrollable" => 'static'));
               while ($selectedItem = sqlsrv_fetch_array($result)) {
                   array_push($searchResFirstLine, $selectedItem);
               }

       }

if(count($searchResFirstLine)==0){
            $sameLineColor=-1;
            echo"
            <div class='alert alert-danger' style='color:red; font-size: 20px;' role='alert'>
                Routes Not Found. Try Different Stations/Time 
            </div> ";
            
            // echo "<script type='text/javascript'> alert('Routes Not Found ,Try Different Stations/Time')</script>";

        }

        else{
        $startSecond = $searchResFirstLine[0]['juncMinute'];
        }

if(count($searchResFirstLine)>0){

 $searchResSecondLine = array();
  if($covid==1){

 $sql = "select distinct s.trainNumber,s.stationName,s.stopDate,s.passengersInTrain,s.startStation,s.endStation
         ,s.covid19InOut,s.loadParameter,s.direction,s.stopMinute,s.stopHour
         ,endTrainTime=(select top 1 s1.stopMinute
         from TblRoute r1 inner join TblStopsIn s1 on r1.sourceStationName=s1.startStation and r1.destStationName=s1.endStation
         where r1.routeDate like '$travelDate' and r1.startHour = $hour and r1.endHour = $hour and s1.stationName like '$destination_station' and  s1.stopHour=$hour and s1.direction=$direction2ndLine and s.trainNumber=s1.trainNumber
            )
            from TblRoute r inner join TblStopsIn s on r.sourceStationName=s.startStation and r.destStationName=s.endStation and r.routeDate=s.stopDate
             where r.routeDate like '$travelDate' and r.startHour = $hour and
             r.endHour = $hour and s.stationName like '$junctionSecondaryStation' and s.stopMinute>=$startSecond and s.stopHour=$hour
             and s.direction=$direction2ndLine and s.covid19InOut <= 1 and s.loadParameter<=$load";

        $result = sqlsrv_query( $conn , $sql, array(), array("Scrollable" => 'static'));

        while ($selectedItem1 = sqlsrv_fetch_array($result)) {
            array_push($searchResSecondLine, $selectedItem1);
        }

  }
  else if($covid==0){

        $sql = "select distinct s.trainNumber,s.stationName,s.stopDate,s.passengersInTrain,s.startStation,s.endStation
                ,s.covid19InOut,s.loadParameter,s.direction,s.stopMinute,s.stopHour
                ,endTrainTime=(select top 1 s1.stopMinute
                from TblRoute r1 inner join TblStopsIn s1 on r1.sourceStationName=s1.startStation and r1.destStationName=s1.endStation
                where r1.routeDate like '$travelDate' and r1.startHour = $hour and r1.endHour = $hour and s1.stationName like '$destination_station' and  s1.stopHour=$hour and s1.direction=$direction2ndLine and s.trainNumber=s1.trainNumber
                   )
                   from TblRoute r inner join TblStopsIn s on r.sourceStationName=s.startStation and r.destStationName=s.endStation and r.routeDate=s.stopDate
                    where r.routeDate like '$travelDate' and r.startHour = $hour and
                    r.endHour = $hour and s.stationName like '$junctionSecondaryStation' and s.stopMinute>=$startSecond and s.stopHour=$hour
                    and s.direction=$direction2ndLine and s.covid19InOut = 0 and s.loadParameter<=$load";

               $result = sqlsrv_query( $conn , $sql, array(), array("Scrollable" => 'static'));

               while ($selectedItem1 = sqlsrv_fetch_array($result)) {
                   array_push($searchResSecondLine, $selectedItem1);
               }

         }


          $sql = "SELECT DATEPART(HOUR, GETDATE())";
                 $stmt = sqlsrv_query( $conn, $sql);
                 if( $stmt === false ) {
                  die( print_r( sqlsrv_errors(), true));
                 }

                if( sqlsrv_fetch( $stmt ) === false) {
                  die( print_r( sqlsrv_errors(), true));
                 }
               $nowHour = sqlsrv_get_field( $stmt, 0);

          $sql = "SELECT DATEPART(MINUTE, GETDATE())";
                 $stmt = sqlsrv_query( $conn, $sql);
                 if( $stmt === false ) {
                  die( print_r( sqlsrv_errors(), true));
                 }

                if( sqlsrv_fetch( $stmt ) === false) {
                  die( print_r( sqlsrv_errors(), true));
                 }
               $nowMinute = sqlsrv_get_field( $stmt, 0);

         $sql = "select t.city  from TblStation as t where t.stationName like '$source_station'";
                 $stmt = sqlsrv_query( $conn, $sql);
                 if( $stmt === false ) {
                  die( print_r( sqlsrv_errors(), true));
                 }

                if( sqlsrv_fetch( $stmt ) === false) {
                  die( print_r( sqlsrv_errors(), true));
                 }
               $sCity = sqlsrv_get_field( $stmt, 0);

                 $sql = "select t.city  from TblStation as t where t.stationName like '$destination_station'";
                 $stmt = sqlsrv_query( $conn, $sql);
                 if( $stmt === false ) {
                  die( print_r( sqlsrv_errors(), true));
                 }

                if( sqlsrv_fetch( $stmt ) === false) {
                  die( print_r( sqlsrv_errors(), true));
                 }
               $dCity = sqlsrv_get_field( $stmt, 0);

 $sql = "SELECT Convert(varchar(10), GETDATE(),120) ";
        $stmt = sqlsrv_query( $conn, $sql);
        if( $stmt === false ) {
         die( print_r( sqlsrv_errors(), true));
        }

       if( sqlsrv_fetch( $stmt ) === false) {
         die( print_r( sqlsrv_errors(), true));
        }
      $nowDate = sqlsrv_get_field( $stmt, 0);

               $sql1 = "INSERT INTO TblCustSearch  VALUES ('$userName','$nowDate',$nowHour,$nowMinute,'$source_station','$destination_station'
               ,'$sCity','$dCity',$covid,$load)";

         			$params1 = array();
         			$options1 =  array('Scrollable' => SQLSRV_CURSOR_FORWARD);
         			$result1 = sqlsrv_query( $conn , $sql1, $params1);

                     sqlsrv_commit( $conn );


        			if($sql1) {
        				sqlsrv_commit( $conn );
        			}
if(count($searchResSecondLine)==0){
            $sameLineColor=-1;

            echo"
            <div class='alert alert-danger' style='color:red; font-size: 20px;' role='alert'>
                Routes Not Found. Try Different Stations/Time 
            </div> ";
            // echo "<script type='text/javascript'> alert('Routes Not Found ,Try Different Stations/Time')</script>";

        }
}
}


/* test data
   echo $sourcePrimaryStation;
   echo $sourceSecondaryStation;
   echo $destinationPrimaryStation;
   echo $destinationSecondaryStation;
      echo $source_station;
       echo $travelDate;
       echo $destination_station;
       echo $time;
        echo count($searchRes);

        foreach($searchRes as $searchItem){
                   print_r($searchItem);
                   }

*/

    

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title>Search Results</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">




  <style>
    .row {
      content: "";
      display: flex;
      clear: both;
      width: 80%;
      text-align: center;
    }

    .column {
      width: auto;
      margin: auto;
    }

    .form-group {
      margin-top: 10px;
      margin-bottom: 15px;
    }

    label {
      display: inline-block;
      max-width: 100%;
      margin-bottom: 5px;
      font-weight: 700;
      font-size: 14px;
    }

    .form-control {
      width: 196.8px;
      padding: 6px 12px;
      font-size: 14px;
      font-family: cursive;
      display: inherit;
      border-radius: 4px;
      border: 1px solid #ccc;
      text-align: center;
      outline: none;
    }


    table {
      font-family: "comic sans ms MS", Arial, Helvetica, sans-serif;
      font-family: "comic sans ms MS", Arial, Helvetica, sans-serif;
      border-collapse: collapse;
      width: 100%;
      text-align: center;

    }

    .button {
      background-color: #4CAF50;
      color: white;
      padding: 5px 10px;
      margin: 8px 0;
      border: none;
      cursor: pointer;
      width: 12%;
      text-align: center;
      text-align: center;
      border-radius: 10px;
    }

    table td,
    th {
      border: 1px solid #ddd;
      padding: 8px;

    }

    table tr:nth-child(even) {
      background-color: #f2f2f2;
    }

    table tr:hover {
      background-color: #ddd;
    }

    table th {
      padding-top: 12px;
      padding-bottom: 12px;
      text-align: left;
      background-color: #4CAF50;
      color: white;
      text-align: center;
      font-family: "comic sans ms MS", Arial, Helvetica, sans-serif;
    }

    .results-button {
      padding: 10px 20px;
      margin: 8px 0;
      border: none;
      cursor: pointer;
      border-radius: 10px;
      width: 8%;
      text-align: center;
    }

    #back {
      background-color: #af181d;
      color: white;
      margin-left: 5px;
    }

    .print {
      background-color: #4CAF50;
      color: white;
    }

    .fa {
      width: 40px;
    }
  </style>


  <script>

      /**
      * function which checks if the source station and destination station are identical
      */
      function checkIfSame(){

          // Getting the inserted values of the source station and destination input fields
          var chosen_source_station = document.getElementById('source_station').value;
          var chosen_destination_station = document.getElementById('destination_station').value;

          // Check wether the source station value and destination station value are identical
          if(chosen_source_station == chosen_destination_station){ // If they are the same
              alert("Source Station And Destination station are the same. \n Please change one of them."); // 
              the user to change one of these inputs
              return false;
          }

          else{ // Soucre station & destination station are different 
              document.getElementById("form").submit(); // Submit the form to the search algorithm file
          }
      }


    
      /**
        * function that gets fired by event that returns only numbers input -> disables other characters 
        * @event onclick entering data input in form
        * @param evt 
        * @return boolean
        */
      function onlyNumberKey(evt) {
              
              // Only ASCII character in that range allowed
              var ASCIICode = (evt.which) ? evt.which : evt.keyCode

              // Check if the inserted charcter is a number in ASCII code
              if (ASCIICode > 31 && (ASCIICode < 48 || ASCIICode > 57))
                  return false;
              return true;
      }

      /**
        * function that gets fired by event that returns only letters input -> disables other characters 
        * @event onclick entering data input in form
        * @param evt 
        * @return boolean
        */
      function onlyLettersKey(evt) {
              
              // Only ASCII character in that range allowed
              var ASCIICode = (evt.which) ? evt.which : evt.keyCode

              // Check if the inserted charcter is a letter in ASCII code
              if ((ASCIICode > 64 && ASCIICode < 91) || (ASCIICode > 96 && ASCIICode < 123))
                  return true;
              return false;
      }




  </script>

</head>

<body>


  <?php


    include "customer_layout.php";


    $stations_array = array();
    $sql = "SELECT stationName, city FROM TblStation order by city";
        $result = sqlsrv_query( $conn , $sql, array(), array("Scrollable" => 'static'));
        while ($selectedItem = sqlsrv_fetch_array($result)) {
            
            $station_name = $selectedItem['city'];
            $station_city = $selectedItem['stationName'];
            
            $station_details = $station_name.", ".$station_city;

            array_push($stations_array, $station_details);
        }

        $user_id = $_SESSION['username'];
        // Get User's Covid19 & Load Preferences From Registration
        $sql = "SELECT covid19Val, loadCust FROM TblCustomer where id=$user_id";
        $result = sqlsrv_query( $conn , $sql, array(), array("Scrollable" => 'static'));
        $users_preferences = sqlsrv_fetch_array($result);

        if( $result === false  ) {
            die( print_r( sqlsrv_errors(), true));
        }

        if( sqlsrv_fetch( $result ) === false) {
            die( print_r( sqlsrv_errors(), true));
        }

        if($users_preferences[0] >= 0 && $users_preferences[0] <= 0.5 )
            $users_covid19_val = "Covid Free";
        else{
            $users_covid19_val = "Nevermind";
        }

        if($users_preferences[1] >= 0 && $users_preferences[1] <= 0.5)
            $users_load = "Free";
        else{
            $users_load = "Nevermind";

        }


 ?>


  <form action="customerSearch.php" method="post" id="form" onsubmit="return checkIfSame()" style="width: 60%; height: 300px; float:left">

    <input type="hidden" name="text" value="<?php echo $_SESSION['username']; ?>">

    <div class="form-group">
      <div class="row">
        <div class="column">

          <div class="form-group">
            <div class="source_datalist">

              <label> Source Station</label>
              <!-- <input list="source_station" class="form-control" name="source_station" /> -->
              <select id="source_station" autocomplete="on" list="source_station" class="form-control"
                name="source_station" required>
                <?php     
                                    $former_opt_group = "Bat Yam";
                                    echo "<option = {$source_station} >{$source_station} </option>";

                                    echo "<optgroup label='{$former_opt_group}'>";

                                    foreach ($stations_array as $value) {
                                        $city = explode(",",$value)[0];
                                        echo $city;
                                        $station = end(explode(",",$value));

                                        if($city != $former_opt_group){
                                            echo "</optgroup>";
                                            $city = explode(",",$value)[0];
                                            $former_opt_group = $city;

                                            echo "<optgroup label='{$city}'>";
                                        }

                                        echo "<option = {$station}> {$station} </option>";
                                    }
                                
                                
                                ?>
              </select>
            </div>
          </div>


          <div class="form-group">
              <label for="load"> Load: </label>
              <input list="load_list" id="load" class="form-control" value="<?php echo $loadValue; ?>" name="load" 
                    pattern="Nevermind|Free" onkeypress="return onlyLettersKey(event)" required>
              <datalist id="load_list">
                  <option value="Nevermind"> Nevermind </option>
                  <option value="Free"> Free </option>
              </datalist>

          </div>

          <div class="form-group">
            <label for="covid19Value"> Covid-19: </label>
            <input list="covid19List" id="covid19Value" class="form-control" value="<?php echo $covid19val; ?>"
              name="covid19Value" pattern="Nevermind|Covid Free" required onkeypress="return onlyLettersKey(event)" >
            <datalist id="covid19List">
                  <option value="Nevermind"> Nevermind </option>
                  <option value="Covid Free"> Covid Free </option>
            </datalist>

          </div>


        </div>

        <div class="column">
          <div class="form-group">
            <label> Destination Station</label>
            <!-- <input list="destination_station" class="form-control" name="destination_station" /> -->
            <select id="destination_station" list="destination_station" class="form-control" name="destination_station"
              autocomplete="on" required>
              <?php 
                        
                            $former_opt_group = "Bat Yam";
                            echo "<option = {$destination_station} > {$destination_station} </option>";

                            echo "<optgroup label='{$former_opt_group}'>";

                            foreach ($stations_array as $value) {
                                $city = explode(",",$value)[0];
                                echo $city;
                                $station = end(explode(",",$value));

                                if($city != $former_opt_group){
                                    echo "</optgroup>";
                                    $city = explode(",",$value)[0];
                                    $former_opt_group = $city;

                                    echo "<optgroup label='{$city}'>";
                                }

                                echo "<option = {$station}> {$station} </option>";
                            }
                                
                            ?>
            </select>
          </div>

          <div class="form-group">
            <label for="time"> Time: </label>

            <input type="time" id="time" class="form-control" name="time" min="07:00" max="22:00"
              value="<?php echo $time; ?>" required>
          </div>



          <div class="form-group">
            <label for="travelDate"> Travel Date: </label>
            <input type="date" id="travelDate" class="form-control" name="travelDate" value="<?php echo $travelDate?>"
              style="width: 200px;margin: -1px "  min=<?php echo date('Y-m-d');?> required>
          </div>


        </div>
      </div>
    </div>
    <button type="submit" class="button" style="margin-left: 33%;">Search</button>

  </form>



  <?php

if($sameLineColor==1){
echo "<table>";
echo "<tr><th>Line Color</th><th>Train Number</th><th>Source Station</th><th>Source City</th><th>Destination Station</th><th>Destination City</th><th>Date</th><th>Departure Hour</th><th>Departure Minute</th><th>Arrival Hour</th><th>Arrival Minute</th><th>Travel Time</th><th>Direction</th></tr>";
 foreach($searchRes as $row){
 echo "<tr><td>";
 echo $sourcePrimaryStation;
 $train = $row['trainNumber'];
 echo $row['trainNumber'];
 echo "</td><td>";
 echo $row['stationName'];
 echo "</td><td>";

          $sql = "select t.city from TblStation as t where t.stationName='$source_station'";
          $stmt = sqlsrv_query( $conn, $sql);
          if( $stmt === false ) {
           die( print_r( sqlsrv_errors(), true));
           }
           if( sqlsrv_fetch( $stmt ) === false) {
           die( print_r( sqlsrv_errors(), true));
           }
           $sourceCity = sqlsrv_get_field( $stmt, 0);

 echo $sourceCity;
 echo "</td><td>";
 echo $destination_station;
 echo "</td><td>";

               $sql = "select t.city from TblStation as t where t.stationName='$destination_station'";
               $stmt = sqlsrv_query( $conn, $sql);
               if( $stmt === false ) {
                die( print_r( sqlsrv_errors(), true));
                }
                if( sqlsrv_fetch( $stmt ) === false) {
                die( print_r( sqlsrv_errors(), true));
                }
                $destinationCity = sqlsrv_get_field( $stmt, 0);

 echo $destinationCity;
 echo "</td><td>";
 $Date = $row['stopDate']->format('d/m/Y');
 echo $Date;
 echo "</td><td>";

         /*check destination arrival time*/
        $sql = "select s.stopHour
                from TblRoute r inner join TblStopsIn s on r.sourceStationName=s.startStation and r.destStationName=s.endStation
                where r.routeDate like '$travelDate' and r.startHour=$hour and r.endHour =$hour and s.stationName like '$destination_station' and s.stopHour=$hour and s.direction=$direction and s.trainNumber=$train";

        $stmt = sqlsrv_query( $conn, $sql);
           if( $stmt === false ) {
             die( print_r( sqlsrv_errors(), true));
           }

           if( sqlsrv_fetch( $stmt ) === false) {
             die( print_r( sqlsrv_errors(), true));
           }
         $arrivalHour = sqlsrv_get_field( $stmt, 0);

         $sql = "select s.stopMinute
         from TblRoute r inner join TblStopsIn s on r.sourceStationName=s.startStation and r.destStationName=s.endStation
         where r.routeDate like '$travelDate' and r.startHour=$hour and r.endHour =$hour and s.stationName like '$destination_station' and s.stopHour=$hour and s.direction=$direction and s.trainNumber=$train";

         $stmt = sqlsrv_query( $conn, $sql);
            if( $stmt === false ) {
              die( print_r( sqlsrv_errors(), true));
            }

            if( sqlsrv_fetch( $stmt ) === false) {
             die( print_r( sqlsrv_errors(), true));
            }
            $arrivalMinute = sqlsrv_get_field( $stmt, 0);

               $departure_hour = $row['stopHour'];
                     $departure_minute = $row['stopMinute'];
                     if($departure_hour < 10)
                         $departure_hour = "0".$departure_hour;
                     if($departure_minute < 10)
                         $departure_minute = "0".$departure_minute;
                   
                     $departure_time = "{$departure_hour}:{$departure_minute}";
           
                     $arrivalHour = $row['stopHour'];
                     if($arrivalHour < 10)
                         $arrivalHour = "0".$arrivalHour;
                     if($arrivalMinute < 10)
                         $arrivalMinute = "0".$arrivalMinute;
                   
                     $arrival_time = "{$arrivalHour}:{$arrivalMinute}";

 echo $row['stopHour'];
 echo "</td><td>";
 echo $row['stopMinute'];
 echo "</td><td>";
 echo $arrivalHour;
 echo "</td><td>";
 echo $arrivalMinute;
 echo "</td><td>";
 $timeOfTrip = $arrivalMinute-$row['stopMinute'];
 echo $timeOfTrip;
 echo "</td><td>";
 echo $row['startStation'] . " --> " . $row['endStation'];


}
echo "</table>";
}
else if($sameLineColor==0){

echo "<br><br><br><br><br><br><br><br><br><br><br><br><br><br><h2 style='margin-left: -100px;'>Search Results - First Train</h2>";
echo "<table>";
echo "<tr><th>Line Color</th><th>Train Number</th><th>Source Station</th><th>Source City</th><th>Destination Station</th><th>Destination City</th><th>Junction Station</th><th>Junction City</th><th>Date</th><th>Departure Hour</th><th>Departure Minute</th><th>Arrival Junction Hour</th><th>Arrival Junction Minute</th><th>Travel Time</th><th>Direction</th></tr>";
 foreach($searchResFirstLine as $row){
 echo "<tr><td>";
 echo $sourcePrimaryStation;
 echo "</td><td>";
 $train = $row['trainNumber'];
 echo $row['trainNumber'];
 echo "</td><td>";
 echo $row['stationName'];
 echo "</td><td>";

          $sql = "select t.city from TblStation as t where t.stationName='$source_station'";
          $stmt = sqlsrv_query( $conn, $sql);
          if( $stmt === false ) {
           die( print_r( sqlsrv_errors(), true));
           }
           if( sqlsrv_fetch( $stmt ) === false) {
           die( print_r( sqlsrv_errors(), true));
           }
           $sourceCity = sqlsrv_get_field( $stmt, 0);

 echo $sourceCity;
 echo "</td><td>";
 echo $destination_station;
 echo "</td><td>";

               $sql = "select t.city from TblStation as t where t.stationName='$destination_station'";
               $stmt = sqlsrv_query( $conn, $sql);
               if( $stmt === false ) {
                die( print_r( sqlsrv_errors(), true));
                }
                if( sqlsrv_fetch( $stmt ) === false) {
                die( print_r( sqlsrv_errors(), true));
                }
                $destinationCity = sqlsrv_get_field( $stmt, 0);

 echo $destinationCity;
 echo "</td><td>";

 echo $junctionPrimaryStation;
      echo "</td><td>";

                    $sql = "select t.city from TblStation as t where t.stationName='$junctionPrimaryStation'";
                    $stmt = sqlsrv_query( $conn, $sql);
                    if( $stmt === false ) {
                     die( print_r( sqlsrv_errors(), true));
                     }
                     if( sqlsrv_fetch( $stmt ) === false) {
                     die( print_r( sqlsrv_errors(), true));
                     }
                     $destinationJunctionCity = sqlsrv_get_field( $stmt, 0);

      echo $destinationJunctionCity;
      echo "</td><td>";

 $Date = $row['stopDate']->format('d/m/Y');
 echo $Date;
 echo "</td><td>";
 echo $row['stopHour'];
 echo "</td><td>";
 echo $row['stopMinute'];
 echo "</td><td>";
 echo $row['stopHour'];
 echo "</td><td>";
 echo $row['juncMinute'];
 echo "</td><td>";
 $timeOfTrip = $row['juncMinute']-$row['stopMinute'];
 echo $timeOfTrip;
 echo "</td><td>";
 echo $row['startStation'] . " --> " . $row['endStation'];

}
echo "</table>";

echo "<h2>Search Results - Second Train</h2>";
echo "<table>";
echo "<tr><th>Line Color</th><th>Train Number</th><th>Source Station</th><th>Source City</th><th>Destination Station</th><th>Destination City</th><th>Date</th><th>Departure Hour</th><th>Departure Minute</th><th>Arrival Hour</th><th>Arrival Minute</th><th>Travel Time</th><th>Direction</th></tr>";
 foreach($searchResSecondLine as $row){
 echo "<tr><td>";
 echo $destinationPrimaryStation;
 echo "</td><td>";
 $train = $row['trainNumber'];
 echo $row['trainNumber'];
 echo "</td><td>";
 echo $row['stationName'];
 echo "</td><td>";

          $sql = "select t.city from TblStation as t where t.stationName='$junctionSecondaryStation'";
          $stmt = sqlsrv_query( $conn, $sql);
          if( $stmt === false ) {
           die( print_r( sqlsrv_errors(), true));
           }
           if( sqlsrv_fetch( $stmt ) === false) {
           die( print_r( sqlsrv_errors(), true));
           }
           $sourceCity = sqlsrv_get_field( $stmt, 0);

 echo $sourceCity;
 echo "</td><td>";
 echo $destination_station;
 echo "</td><td>";

               $sql = "select t.city from TblStation as t where t.stationName='$destination_station'";
               $stmt = sqlsrv_query( $conn, $sql);
               if( $stmt === false ) {
                die( print_r( sqlsrv_errors(), true));
                }
                if( sqlsrv_fetch( $stmt ) === false) {
                die( print_r( sqlsrv_errors(), true));
                }
                $destinationCity = sqlsrv_get_field( $stmt, 0);

 echo $destinationCity;
 echo "</td><td>";

 $Date = $row['stopDate']->format('d/m/Y');
 echo $Date;
 echo "</td><td>";
 echo $row['stopHour'];
 echo "</td><td>";
 echo $row['stopMinute'];
 echo "</td><td>";
 echo $row['stopHour'];
 echo "</td><td>";
 echo $row['endTrainTime'];
 echo "</td><td>";
 $timeOfTrip = $row['endTrainTime']-$row['stopMinute'];
 echo $timeOfTrip;
 echo "</td><td>";
 echo $row['startStation'] . " --> " . $row['endStation'];

}
echo "</table>";

}
?>


  <script>
      (function (d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        js = d.createElement(s); js.id = id;
        js.src = "https://widgets.moovit.com/wtp/en";
        fjs.parentNode.insertBefore(js, fjs);
      }(document, 'script', 'moovit-jsw'));
  </script>

  <?php

    $sql = "SELECT map from TblStationTranslateHeb where stationName='$source_station'";
    $stmt = sqlsrv_query( $conn, $sql);
    if( $stmt === false ) {
    die( print_r( sqlsrv_errors(), true));
    }
    if( sqlsrv_fetch( $stmt ) === false) {
    die( print_r( sqlsrv_errors(), true));
    }
    $sourceStationLatLong = sqlsrv_get_field( $stmt, 0);

    $sql = "SELECT map from TblStationTranslateHeb where stationName='$destination_station'";
    $stmt = sqlsrv_query( $conn, $sql);
    if( $stmt === false ) {
    die( print_r( sqlsrv_errors(), true));
    }
    if( sqlsrv_fetch( $stmt ) === false) {
    die( print_r( sqlsrv_errors(), true));
    }
    $destinationStationLatLong = sqlsrv_get_field( $stmt, 0);

    // data-metro="121"
    
    
  ?>
  <div class="mv-wtp" style="height: 500px;" data-lang="hb" data-from=<?php echo $source_station; ?>
    data-from-lat-long =
    <?php echo $sourceStationLatLong; ?>
    data-to=
    <?php echo $destination_station; ?>
    data-to-lat-long =
    <?php echo $destinationStationLatLong; ?>
  </div>


</body>
<br>
<br>
<br>


<button id="back" class="results-button" onclick="window.location.href ='customer_page.php';">Back</button>
<button id="print" class="results-button" onclick="window.print()">Print</button>

</html>