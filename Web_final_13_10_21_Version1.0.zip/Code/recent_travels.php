<?php 

    /** 
     * This file includes form, styling & DB query for recent travels report including its functionality
     */


    //Start Session 
    session_start(); 
    
    //Check if session is set, if not:(User is not signed in) -> redirect to index.php
    if(!isset($_SESSION['username']) ){
        session_destroy();    
        header("Location: index.php");
    }

    //If Session is set:---------------------------------
    include 'customer_layout.php'; 
        
    $user_session = $_SESSION['username']; // Get user's session => ID Number

    /**
     * Including/Calling DB connection
     * @return connection
     */
    require 'databaseconnection.php';

    /** This file section is basically executed when the form is submitted */
    // If 
    if(isset($_POST['filter_submit_button'])){ //If form is submitted

        // Get parameters:
        $starting_date =  $_POST['starting_date'] ;
        $ending_date = $_POST['ending_date'];

        // Initialize arrays:
        $travels_array = array();
        $excel_travels_array = array();
        $new_excel_row = array();

        
        /**
         * Query for getting the recent travels data(date, hour, minute, source station & city, destination station & city, load and covis19 parameters)
         * @param user_session -> Users ID
         * @param starting_date -> First date of the report
         * @param ending_date -> Last date of the report
         */
        $sql = "SELECT exitEnterDate, exitEnterHour,exitEnterMinute, fromCity, toCity, statStation, endStation, loadParameter, covid19InOut
                from TblCustomerExitEnter
                Where id= $user_session AND exitEnterDate BETWEEN '$starting_date' AND '$ending_date'";
                $params = array();
                $options =  array( "Scrollable" => SQLSRV_CURSOR_STATIC );
        $stmt = sqlsrv_query( $conn, $sql, array(), array("Scrollable" => 'static'));


        // if( $stmt === false ) {
        //     die( print_r( sqlsrv_errors(), true));
        // }
        // if( sqlsrv_fetch( $stmt ) === false) {
        //     die( print_r( sqlsrv_errors(), true));
        // }

        
        // $num_of_rows = sqlsrv_num_rows($stmt);
        // var_dump($num_of_rows); 

       
        /** 
         * Looping over the result set -> Inserting each row data into the array
         * @param travels_array -> array
         * @param selectedItem -> query result row
         */ 
        while ($selectedItem = sqlsrv_fetch_array($stmt)) {
        
            array_push($travels_array, $selectedItem);// Push row to the array
        }

        $query_has_rows = sqlsrv_has_rows( $stmt ); // Check whether query has rows -> boolean

        if($query_has_rows === false){ // If query has rows -> there are no rides
           
            ?>
            <!-- Notify the user that no travels have been found -->
            <div class="search_dates_title" style="color:red;"> No travels found. Try to enter different date </div> <br> 
            <?php
        }

        else{ // Query has rows -> there is atleast one ride
           
            ?>
            
            <!-- Styling Settings -->
            <style>
            table {
                font-family: "comic sans ms MS", Arial, Helvetica, sans-serif;
                font-family: "comic sans ms MS", Arial, Helvetica, sans-serif;
                border-collapse: collapse;
                width: 100%;
                text-align: center;

            }

            table td, th {
                border: 1px solid #ddd;
                padding: 8px;

            }

            table tr:nth-child(even){
                background-color: #f2f2f2;
            }

            table tr:hover {background-color: #ddd;}

            table th {
                padding-top: 12px;
                padding-bottom: 12px;
                text-align: left;
                background-color: #4CAF50;
                color: white;
                text-align: center;
                font-family: "comic sans ms MS", Arial, Helvetica, sans-serif;
            }
            
            </style>
            <?php

            /**
             * Creating the result table with its headers
             */

            echo "<table>";
            echo "<tr><th> Parameter  </th><th> Value </th>";
            

            /**
             * Query for the summary table of recent travels(Users & Costs)
             * @param user_session -> Users ID
             * @param starting_date -> First date of the report
             * @param ending_date -> Last date of the report
             */
            $sql2 = "SELECT count(custEnterExitId)
                    FROM TblCustomerExitEnter
                    Where id= '$user_session' AND exitEnterDate BETWEEN '$starting_date' AND '$ending_date'";
            $stmt2 = sqlsrv_query( $conn, $sql2);

            if( $stmt2 === false ) {
                die( print_r( sqlsrv_errors(), true));
              }
           
              if( sqlsrv_fetch( $stmt2 ) === false) {
                die( print_r( sqlsrv_errors(), true));
              }

            $number_of_travels = sqlsrv_get_field($stmt2, 0);
            $travel_costs = 5*$number_of_travels;


            $headers = ["Date","Time", "Type", "Source Station", "Destination Station", "Train Number", "Load", "Covid19 Value" , "Direction", "Source City","Destination City", "Station Name"];
            
            
            /** 
             * Pushing the headers to the "excel_travels_array" array
             * @param excel_travels_array
             * @param headers
             */
            array_push($excel_travels_array, $headers );
            
            // Looping over the travels array array
            foreach($travels_array as $row){
                
                // $date = $row['exitEnterDate'];
                
                // Saving each data column field into variable        
                $date = $row['exitEnterDate']->format('d/m/Y');
                $hour = $row['exitEnterHour'];
                $minute = $row['exitEnterMinute'];

                //Adding zeros at the beginning if number is < 9 
                if($hour < 10)
                    $hour = "0".$hour;
                if($minute < 10)
                    $minute = "0".$minute;
                
                $time = "{$hour}:{$minute}";


                $fromCity = $row['fromCity'];
                $toCity = $row['toCity'];
                $statStation = $row['statStation'];
                $endStation = $row['endStation'];
                $loadParameter = $row['loadParameter'];
                $covid19InOut = $row['covid19InOut'];

                // Converting the covid19InOut parameter from number to string accrodingly
                if($covid19InOut[0] >= 0 && $covid19InOut[0] <= 0.5 )
                    $covid19InOut = "Covid Free";
                else{
                    $covid19InOut = "Nevermind";
                }

                // Converting the loadParameter parameter from number to string accrodingly
                if($loadParameter[1] >= 0 && $loadParameter[1] <= 0.5)
                    $loadParameter = "Free Load";
                else{
                    $loadParameter = "Nevermind";

                }
                
                // Craeting a row that will be added later to the travels array 
                $new_excel_row = [$date, $time, $fromCity,$toCity,$statStation,$endStation,$loadParameter,$covid19InOut];
                
                
                /**
                 * Pushing the new created row to the excel_travels_array array
                 * @param excel_travels_array
                 * @param new_excel_row
                 */
                array_push($excel_travels_array, $new_excel_row);

                // Print the new row array in the above created table
                
            }

            echo '<tr>
                                <td>  Number Of Travels </td>
                                <td> '.$number_of_travels.' </td>           
                    </tr>
                    
                    <tr>
                                <td>  Total Travel Expenses </td>
                                <td> '.$travel_costs.'&#8362; </td>
                    </tr>';


            ?>

            <script type='text/javascript'>
                var travels = <?php echo json_encode($excel_travels_array); ?>; //decoding array => converting from PHP to JS
                
                // document.getElemenqtById("download_btn").style.display = "block";
                        
            </script>

            <!-- Report CSV downloading button  -->
            <button class="download_btn" onclick="downloadCSV(travels)"> Download </button>
            
            <?php
        }
    
    } ?>

    
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<!-- Styling settings -->
<style>
    .row {
        height: 150px;
        content: "";
        display: flex;
        clear: both;
        width: 80%;
        margin: auto;
        text-align: center;

        
    }

    .column {
        width: auto;
        margin: auto;
    }

    .form-group {
        margin-top: 10px;
        margin-bottom: 15px;
        
        
    }

    .form-control {
        height: 20px;
        width: 196.8px;
        padding: 6px 12px;
        font-size: 14px;
        font-family: cursive;
        display: inherit;
        border-radius: 4px;
        border: 1px solid #ccc;
        text-align: center;
        outline: none;
    }

    .form-control:focus {
        border: 1px solid #66afe9;
        
    }

    label {
        display: inline-block;
        max-width: 100%;
        margin-bottom: 5px;
        font-weight: 700;
        font-size: 20px;
    }

    .download_btn {
        color: #fff;
        background-color: #3e9dc9;
        margin-bottom: 0;
        font-weight: 400;
        text-align: center;
        white-space: nowrap;
        vertical-align: middle;
        touch-action: manipulation;
        cursor: pointer;
        background-image: none;
        border: 1px solid transparent;
        padding: 6px 12px;
        font-size: 14px;
        line-height: 1.42857143;
        border-radius: 4px;
        margin-left: 25px;
        font-family: cursive;

    }

    .download_btn:hover {
        background-color: #297aa0f1;
        color: white
    }

    .submit_btn {
        color: #fff;
        background-color: #5cb85c;
        border-color: #4cae4c;
        display: inline-block;
        margin-bottom: 0;
        font-weight: 400;
        text-align: center;
        white-space: nowrap;
        vertical-align: middle;
        touch-action: manipulation;
        cursor: pointer;
        background-image: none;
        border: 1px solid transparent;
        padding: 6px 12px;
        font-size: 14px;
        line-height: 1.42857143;
        border-radius: 4px;
        margin-left: 46%;
        font-family: cursive;
    }

    .submit_btn:hover {
        background-color: #4CAF50;
        color: white
    }
</style>

<script>

    // Get users id from session
    var user_id = <?php echo $user_session; ?> ;

    /**
    * Function that creates teh CSV file
    * @param {array} array 
    * @return {array} result
    */
    function createCSV(array) {
        var keys = Object.keys(array[0]); //Collects Table Headers

        var result = ''; //CSV Contents
        result += keys.join(','); //Comma Seperates Headers
        result += '\n'; //New Row

        array.forEach(function (item) { //Goes Through Each Array Object
            keys.forEach(function (key) {//Goes Through Each Object value
                result += item[key] + ','; //Comma Seperates Each Key Value in a Row
            })
            result += '\n';//Creates New Row
        })

        return result;
    }


    /**
    * Function that downloads the CSV file
    * @func calls the above function for creating the CSV file first
    * @param {array} array
    */
    function downloadCSV(array) {
        csv = 'data:text/csv;charset=utf-8,' + createCSV(array); //Creates CSV File Format
        excel = encodeURI(csv); //Links to CSV 

        link = document.createElement('a');
        link.setAttribute('href', excel); //Links to CSV File 
        var file_name = user_id + ' Travels.csv';
        link.setAttribute('download', file_name); //Filename that CSV is saved as
        link.click();
    }

</script>


<body>

    <!-- Form which contains 2 inputs -> first date and last date of filtering reports -->
    <form action="" method="post" id ="form" style="width: 60%; height: 10%; margin: auto; ">
        <div class="row">
            <div class="column">

                <!-- First input field: first date -->
                <div class="form-group">
                    <label> From: </label>
                    <input type="date" class="form-control" value="<?php   //After first search -> parametrs will be shown in the form
                                                                            if(isset($_POST['starting_date'])){  
                                                                                echo $_POST['starting_date'];
                                                                                unset($_POST['starting_date']);

                                                                            }
                                                                                
                                                                            else { // Else if no search has been made yet (show todays date)
                                                                                echo date('Y-m-d');
                                                                            }
                                                                    ?>" id="starting_date" name="starting_date">
                </div>
            </div>

            <div class="column">

                <!-- Second input field: last date -->
                <div class="form-group">
                    <label> To: </label>
                    <input type="date" class="form-control" max= "<?php echo date('Y-m-d')?>" value="<?php   //After first search -> parametrs will be shown in the form
                                                                            if(isset($_POST['ending_date'])){  
                                                                                echo $_POST['ending_date'];
                                                                                unset($_POST['ending_date']);

                                                                            }
                                                                                
                                                                            else { // Else if no search has been made yet (show todays date)
                                                                                echo date('Y-m-d');
                                                                            }
                                                                    ?>" id="ending_date" name="ending_date">
                </div>
            </div>

        </div>

        <!-- Search button, onclick => Calls 'checkDateValidity()' function  -->
        <button class="submit_btn" type="submit" onclick="checkDateValidity('filter_submit_button')" name="filter_submit_button">Search</button>
        <br><br>

    </form>

    <script>

        /**
         * Function which checks if the second(Last) date is greater than the first date
         * Gets No parameters
         */
        function checkDateValidity(){

            var date_from = document.getElementById("starting_date").value; // Get starting date input value
            var date_till = document.getElementById("ending_date").value;   // Get ending date input value

            if (date_till < date_from) {

                alert( "Second must be greater than the first date. \n Please change the date");
            }

            else{
                document.getElementById("form").submit();

            }

        }

    </script>



</body>

</html>