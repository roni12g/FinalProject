<?php 	

    /** 
     * This file contains the "home page"/first page of the unregistered user
     */

    // Calling the unregistered layout and including it
    include 'index_layout.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>I-Travel</title>
    <link rel="icon" type="image/ico" href="favicon.ico">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="Styles/index.css">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>

</head>

<!-- Styling settings -->
<style>
    .row {
        content: "";
        display: table;
        clear: both;
        text-align: center;
        margin: auto;
    }

    label {
        padding-right: 0;
    }

    .form-control {
        text-align: center;
    }


</style>

<script type="text/javascript">

   
    /**
     * function which checks if the source station and destination station are identical
     */
    function checkIfSame(){

        // Getting the inserted values of the source station and destination input fields
        var chosen_source_station = document.getElementById('source_station').value;
        var chosen_destination_station = document.getElementById('destination_station').value;

        // Check wether the source station value and destination station value are identical
        if(chosen_source_station == chosen_destination_station){ // If they are the same
            alert("Source Station And Destination station are the same. \n Please change one of them."); // Alert the user to change one of these inputs
            return false;
        }

        else{ // Soucre station & destination station are different 
            document.getElementById("form").submit(); // Submit the form to the search algorithm file
        }
    }
    
    

    function change_direction_func2() {

        // document.write("hello");
        var chosen_source_station_value= document.getElementById('source_station').value;
        // alert(chosen_source_station_value);

        var chosen_destination_station_value = document.getElementById('destination_station').value;

        var select_source_station = document.getElementById('source_station');
        var select_destination_station = document.getElementById('destination_station');

        select_source_station.value = chosen_destination_station_value;
        select_destination_station.value = chosen_source_station_value;

    }

    
</script>


<body>

    <?php

    /**
     * Including/Calling DB connection
     * @return connection
     */
    require 'databaseconnection.php';

        // Initialize stations array
        $stations_array = array();

        /**
         * Query for getting station names and its cities ordered by city name ascending 
         */
        $sql = "SELECT stationName, city FROM TblStation order by city";
        $result = sqlsrv_query( $conn , $sql, array(), array("Scrollable" => 'static'));

        /** 
         * Looping over the result set -> Inserting each row data into the stations array
         */
        while ($selectedItem = sqlsrv_fetch_array($result)) {
            
            // Braeking down the current result set to station name and city
            $station_name = $selectedItem['city']; // Get the city field of the row
            $station_city = $selectedItem['stationName']; // Get the station name filed of the row
            
            // Conctinating the station name and its city
            $station_details = $station_name.", ".$station_city;

            /**
             * Pushing the new created station details varianle to the station array
             * @param stations_array
             * @param station_details
             */
            array_push($stations_array, $station_details);

        }
        
        // Initialize stations array
        $cities_array = array();

        /** 
         * Query for getting cities from TblStation DB tABLE
         */
        $sql2 = "SELECT DISTINCT city FROM TblStation";
        $result2 = sqlsrv_query( $conn , $sql2, array(), array("Scrollable" => 'static'));
        while ($selectedItem2 = sqlsrv_fetch_array($result2)) {
            
            array_push($cities_array, $selectedItem2);
        }

         // Initialize notifications array
         $notifictionDate_array = array();

        /**
         * Query for getting notifications and updates 
         */
        $sql3 = "SELECT *  from TblNotification";
        $result3 = sqlsrv_query( $conn , $sql3, array(), array("Scrollable" => 'static'));

        /** 
         * Looping over the notifications result set 
         * @param notifictionDate_array -> array
         * @param selectedItem3 -> query result row
         */
        while ($selectedItem3 = sqlsrv_fetch_array($result3)) {

            // Inserting each row data into the array 
            array_push($notifictionDate_array, $selectedItem3);

        }

    
    ?>

    <div id="jumbotron" class="jumbotron text-center">
     
        <!-- Search Route form (regular users) which contains 4 inputs -->
        <form action="search.php" method="post" id="form" onsubmit="return checkIfSame()" >
            <div class="form-group">
                <div class="row">

                    <!-- Code section of of first column -->
                    <div class="col-sm-5">
                       
                        <!-- First input: source station -->
                        <div class="form-group">
                            
                            <div class="source_datalist">
                                
                                <label for="source_station"> Source Station</label>
                                <!-- <input type="text" list="source_station_list" class="form-control" id="source_station"
                                    name="source_station" > -->
                                <select class="form-control" id="source_station" 
                                    name="source_station" autocomplete="on">

                                    <?php

                                            $former_opt_group = "Bat Yam";
                                            echo "<option> </option>";

                                            echo "<optgroup label='{$former_opt_group}'>";
                                            foreach ($stations_array as $value) {
                                                $city = explode(",",$value)[0];
                                                echo $city;
                                                $station = end(explode(",",$value));

                                                if($city != $former_opt_group){
                                                    echo "</optgroup>";
                                                    $city = explode(",",$value)[0];
                                                    $former_opt_group = $city;

                                                    echo "<optgroup label='{$city}'>";
                                                }

                                                echo "<option = {$station}> {$station} </option>";
                                            }
                                    
                                    ?>
                                </select>
                            </div>
                        </div>

                        <!-- Second input: travel date -->
                        <div class="form-group">
                            <label for="travelDate"> Travel Date: </label>
                            <input type="date" id="travelDate" class="form-control" name="travelDate"
                                value="<?php echo date('Y-m-d');?>" min="<?php //echo date('Y-m-d');?>"
                            >
                        </div>
                    </div>  <!-- End of first column -->

                    <div class="col-sm-1">
                        <div class="form-group">
                            <br>
                            <button type="button" id="change_direction" onclick="change_direction_func2()"  class="btn btn-link" data-toggle="tooltip" title="Change Direction"> &#8644; </button>
                        </div>
                    </div>

                    <!-- Code section of of second column -->
                    <div class="col-sm-5">

                        <!-- Third input: destination station -->
                        <div class="form-group">
                            <label> Destination Station</label>
                            <select id="destination_station" class="form-control" name="destination_station" autocomplete="on" >
                                <?php 
                              
                                    $former_opt_group = "Bat Yam";
                                    echo "<option> </option>";

                                    echo "<optgroup label='{$former_opt_group}'>";

                                    foreach ($stations_array as $value) {
                                        $city = explode(",",$value)[0];
                                        echo $city;
                                        $station = end(explode(",",$value));

                                        if($city != $former_opt_group){
                                            echo "</optgroup>";
                                            $city = explode(",",$value)[0];
                                            $former_opt_group = $city;

                                            echo "<optgroup label='{$city}'>";
                                        }

                                        echo "<option = {$station}> {$station} </option>";
                                    }
                                
                                      
                                ?>

                            </select>

                        </div>

                        <!-- Fourths input: travel time -->
                        <div class="form-group">
                            <label for="time"> Time: </label>

                            <input type="time" id="time" class="form-control" name="time" min="07:00" max="22:00"
                                required>
                        </div>
                    </div> <!-- End of second column -->
                </div>
            </div>

            <!-- Search route form ubmit button
                 onCLick event -> checkIfSame function is called  -->
            <button type="submit" class="btn btn-success"  name="submit_button">Search</button>

        </form>
        <br><br>
        <hr>
        <br><br>

        <!-- Code section for bottom info section -->
        <div class="container" style="margin-bottom: -14px;">
            <div class="row"> <!-- Row section -->

                <div class="col-md-6 col-sm-6"> <!-- First column -->
                    <h4> <strong> <u> Custom & Adjusted </u> </strong> </h4>
                    <h4> Bye bye to old light rails searching platforms </h4>
                    <!-- p> iTravel system finds the most suitable and personlized ligh rail routes </p -->
                </div> <!-- End of first column -->

                <!-- class="col-sm-1 -->

                <div class="col-md-6 col-sm-6"> <!-- Second column -->
                    <h4> <strong> <u> Covid 19 </u> </strong> </h4>
                    <!-- p> iTravels adjusted itself for covid 19 pandemic.   </p -->
                    <h4> Warn of covid patients that were on the train </h4>
                </div> <!-- End of second column -->
            </div> <!-- End of row section -->
            <br>
        </div> <!-- End of info container code section -->

        <br><br>

        <!-- News & Updates acode section
             Bottom  scrolling bar -->
        <div class="updates" style="width: 80%; margin: auto; display: flex; ">
            <p style="float: left; width: 24%;margin-bottom: 0px; ">Updates & News:</p>
            <marquee behavior=scroll direction="left" scrollamount="3" onmouseover="this.stop();"
                onmouseout="this.start();" style="margin-top: auto; margin-left: -28px;">
                <?php    

                    /** 
                     * Looping over the result set -> Printing each notification in a new line
                     * @param notifictionDate_array -> array
                     * @param value -> query result row
                     */
                    foreach ($notifictionDate_array as $value) {
                        echo " {$value['notifyDate']->format('d/m/Y')}: {$value['details']} |";                    
                    }
                ?>
            </marquee>
        </div>

    </div>

</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

</html>