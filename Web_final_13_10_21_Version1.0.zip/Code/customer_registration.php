<?php 

    /** 
     * This file represents the signup form page 
     */

    // Including the regular (unregistered) layout
    include 'index_layout.php'; 


    if (isset($_GET["msg"]) && $_GET["msg"] == 'existID') { // If recovery email successfully sent, show success alert in this page

    // Echo the success alert

    echo"
    <div class='alert alert-danger' role='alert'>
        <strong> User Already Exists With Same ID number</strong>
    </div> ";


    }

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Registration Form</title>
    <link rel="stylesheet" href="Styles/customer_registration.css">
</head>

<!-- Styling Settings -->
<style>
    body {
        background-color: #eee;
    }
</style>
<script>

    /**
     * function that gets fired by event that returns only numbers input -> disables other characters 
     * @event onclick entering data input in form
     * @param evt 
     * @return boolean
     */
    function onlyNumberKey(evt) {

        // Only ASCII character in that range allowed
        var ASCIICode = (evt.which) ? evt.which : evt.keyCode

        // Check if the inserted charcter is a number in ASCII code
        if (ASCIICode > 31 && (ASCIICode < 48 || ASCIICode > 57))
            return false;
        return true;
    }

    /**
     * function that gets fired by event that returns only letters input -> disables other characters 
     * @event onclick entering data input in form
     * @param evt 
     * @return boolean
     */
    function onlyLettersKey(evt) {

        // Only ASCII character in that range allowed
        var ASCIICode = (evt.which) ? evt.which : evt.keyCode

        // Check if the inserted charcter is a letter in ASCII code
        if ((ASCIICode > 64 && ASCIICode < 91) || (ASCIICode > 96 && ASCIICode < 123))
            return true;
        return false;
    }

</script>


<body>
    <div class="signup-form">

        <!-- Sign up form which contains several inputs -->
        <form action="signup.php" method="post" enctype="multipart/form-data">
            <h2>Register</h2>
            <p class="hint-text">Create your account. It's free and only takes a minute.</p>
            <div class="form-group">
                <div class="row">
                    <!-- div representing "row" as one chunk -->
                    <div class="col-sm-6">
                        <!-- First Column -->

                        <!-- First input field: ID Number -->
                        <div class="form-group">
                            <input type="text" class="form-control" name="id" pattern="[0-9]{9}" placeholder="ID"
                                onkeypress="return onlyNumberKey(event)" maxlength="9" required="required">
                        </div>

                        <!-- Second input field: First Name -->
                        <div class="form-group">
                            <input type="text" class="form-control" name="FirstName" placeholder="First Name"
                                onkeypress="return onlyLettersKey(event)" maxlength="15">
                        </div>

                        <!-- Third input field: Last Name -->
                        <div class="form-group">
                            <input type="text" class="form-control" name="LastName" placeholder="Last Name"
                                onkeypress="return onlyLettersKey(event)" maxlength="15" required="required">
                        </div>

                        <!-- Fourth input field: Email address -->
                        <div class="form-group">
                            <input type="email" class="form-control" name="Email"
                                pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" placeholder="Email"
                                required="required">
                        </div>

                        <!-- Fifth input field: phone number -->
                        <div class="form-group">
                            <input type="tel" class="form-control" name="phoneNumber" pattern="[0-9]{10}"
                                placeholder="Phone Number" maxlength="10" onkeypress="return onlyNumberKey(event)"
                                required="required">
                        </div>

                        <!-- Sixth input field: city -->
                        <div class="form-group">
                            

                            <select id="City" list="City" class="form-control" name="City" placeholder="Select city:" onkeypress="return onlyLettersKey(event)" required>
                                <?php 
    
                                require 'databaseconnection.php';
                                $cities_array = array();
                                $sql = "SELECT city FROM TblCity";
                                $result = sqlsrv_query( $conn , $sql, array(), array("Scrollable" => 'static'));
                                
                                while ($row = sqlsrv_fetch_array($result)) {
                                    
                                    array_push($cities_array, $row);
                                }
                                
                                echo"
                                <option value='' disabled selected> City </option>";

                                foreach ($cities_array as $value) {
                                    
                                    echo "<option> {$value['city']} </option>";
                                }
                            ?>
                            </select>
                        </div>

                        <!-- Seventh input field: street -->
                        <div class="form-group">
                            <input type="text" class="form-control" name="Street" onkeypress="return onlyLettersKey(event)" placeholder="Street"
                                required="required">
                        </div>
                        <!-- Eighth input field: zip code -->
                        <div class="form-group">
                            <input type="text" class="form-control" name="zip_code" placeholder="ZIP Code"
                                onkeypress="return onlyNumberKey(event)" pattern="\d{5}" maxlength="5"
                                required="required">
                        </div>
                    </div> <!-- End of first column -->

                    <div class="col-sm-6">
                        <!-- Second Column -->

                        <!-- Ninth input field: building number -->
                        <div class="form-group">
                            <input type="text" class="form-control" name="building_number" placeholder="Building Number"
                                onkeypress="return onlyNumberKey(event)" pattern="\d*" maxlength="2"
                                required="required">
                        </div>

                        <!-- Eighth input field: apartment number -->
                        <div class="form-group">
                            <input type="text" class="form-control" name="apartment_number"
                                placeholder="Apartment Number" onkeypress="return onlyNumberKey(event)" pattern="\d*"
                                maxlength="2" required="required">
                        </div>

                        <!-- Ninth input field: birth date -->
                        <div class="form-group">
                            <input type="date" class="form-control" name="birthDate" required="required"
                               max="<?php echo date('Y-m-d'); ?>" required="required">
                        </div>

                        <!-- Tenth input field: ride load parameter -->
                        <div class="form-group">

                            <select id="load_datalist" list="load_datalist" id="load" name="load" class="form-control" placeholder="load" onkeypress="return onlyLettersKey(event)"
                                required>

                                <option value="" disabled selected>  </option>
                                <option> Nevermind </option>
                                <option> Free Of Load </option>

                            </select>
                        </div>

                        <!-- Eleventh input field: ride covid19 parameter -->

                           
                        <select id="covid19List" list="covid19List" id="covid19Value" placeholder="Covid19 " name="covid19Value" onkeypress="return onlyLettersKey(event)"
                            class="form-control" name="covid19Value" required>

                            <option value="" disabled selected>  Preferred light rail covid19 value </option>
                            <option> Nevermind </option>
                            <option> Covid Free </option>
                        </select>

                        <!-- Twelfth input field: System password -->
                        <div class="form-group">
                            <input type="password" pattern=".{8,}" maxlength="16" class="form-control" name="password"
                                placeholder="Password (At least 8 characters)">
                        </div>

                        <!-- Thirteenth input field: confirm password -->
                        <div class="form-group">
                            <input type="password" class="form-control" pattern=".{8,}" maxlength="16" name="confirm_password"
                                placeholder="Confirm Password" required="required">
                        </div>
                    </div><!-- End of second column -->
                </div> <!-- End of row div -->
            </div>

            <label for="img1">Select Image:</label>
            <input type="file" name="img1" accept="image/*" onchange="loadFile(event)" height="20" width="20">
            <img id="output" />
            <script>
                var loadFile = function (event) {
                    var output = document.getElementById('output');
                    output.style.height = '100px';
                    output.style.width = '100px';
                    output.src = URL.createObjectURL(event.target.files[0]);
                    output.onload = function () {
                        URL.revokeObjectURL(output.src) // free memory
                    }
                };
            </script>

            <!-- Div section for terms & conditions checkbox -->
            <div class="form-group">
                <label class="checkbox-inline"><input type="checkbox" required="required"> I accept the <a
                        href="terms_and_conditions.html" target="_blank">Terms And Conditions</a></label>
            </div>

            <!-- Div section for registering button  -->
            <div class="form-group">
                <button type="submit" class="btn btn-success btn-lg btn-block">Register Now</button>
            </div>

            <!-- Div section for having account button -->
            <div class="text-center">Already have an account? <a href="user_login.php">Sign in</a></div>
        </form>
    </div>

</body>

</html>