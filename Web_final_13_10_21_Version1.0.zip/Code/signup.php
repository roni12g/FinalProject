<?php

/**
 * This file contains the sign up functionality
 */

 //Start session:
	session_start(); 

	/**
	 * Including/Calling DB connection
	 * @return connection
	 */
	include 'databaseconnection.php';

	$img_move = null;
	$x=0;
	$name = "image_name_need_still_work";

	// Get user's registration form input:

		$newID = $_POST['id'];
		$newFirstName = $_POST['FirstName'];
		$newLastName = $_POST['LastName'];
		$newEmail = $_POST['Email']; //
		$newPhoneNumber = $_POST['phoneNumber']; //
		$newCity = $_POST['City']; //
		$newStreet = $_POST['Street'];
		$newZipCode = $_POST['zip_code']; // 
		$newBuildingNumber = $_POST['building_number'];
		$newApartmentNumber = $_POST['apartment_number'];

		$newBirthDate = $_POST['birthDate'];
		$newPwd = $_POST['password'];
		$newLoad = $_POST['load']; //
		$newcovid19Value = $_POST['covid19Value']; //
		

		// Converting the users_covid19_val parameter from number to string accrodingly
		if($newcovid19Value == "Covid Free"){
			$newcovid19Value = 0;
		}
		else{
			$newcovid19Value = 1;
		}

		// Converting the loadParameter parameter from number to string accrodingly
		if($newLoad == "Free") {
			$newLoad = 0.5;
		}
		else{
			$newLoad = 1;
		}
		
		// Get today's date
		$join_date = date("Y-m-d");
		// $newUserType = $_POST['userType'];
		// $newUsername = $_POST['Username'];
		// $img_name = $_FILES["img1"]["name"];
		// print_r($img);
		// echo($img['name']);
				

		$img_uploaded = isset($_POST['img1']);
	
		
		// if(!empty($_FILES["img1"]["name"])){
		// 	echo "NOT EMPTTTTTTYYYYYY";

		$target_dir = "images/users_images/";
		$imageFileType = strtolower(pathinfo($_FILES["img1"]["name"],PATHINFO_EXTENSION));
		$target_file = $target_dir . basename($newID.".".$imageFileType);
		$uploadOk = 1;

		move_uploaded_file($_FILES["img1"]["tmp_name"], $target_file);
	
		// Check if image file is a actual image or fake image
		// if(isset($_POST["img1"])) {
		// 	$check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
		// 	if($check !== false) {
		// 		$uploadOk = 1;
		// 	} 
			
		// 	else {
		// 		echo "File is not an image.";
		// 		$uploadOk = 0;
		// 	}
		// }



	/**
	 * Query for checking if such user with the registered ID exists 
	 * @param newID -> users id 
	 */
		$sql = "SELECT * FROM TblSystemUser WHERE id = '$newID' "; // or Email='$newEmail' 
		$result = sqlsrv_query( $conn , $sql, array(), array("Scrollable" => 'static'));
		$my_array = sqlsrv_fetch_array($result); //key:value [username:'u1']
		
		
		// $actual_username = $my_array["id"]; 
		// $actual_password = $my_array["email"];

		// print_r($my_array) ;
			
		// If another user with same ID has been found
		if(sqlsrv_num_rows($result) > 0){

			header("Location: customer_registration.php?msg=existID");
			// echo "User Already Exists With Same ID number";

		}
			
		else{
			
			/**
			 * Query for inserting user's address values
			 *  @param newCity -> user's residential city
			 *  @param newZipCode -> user's residential zip Code
			 *  @param newStreet -> user's residential street
			 *  @param newBuildingNumber -> user's residential building number 
			 *  @param newApartmentNumber -> user's residential apartment number
			 */
			$sql1 = "INSERT INTO TblAddress VALUES ( ? , ? , ? , ? , ?);";
			$params1 = array( $newCity, $newZipCode,  $newStreet , $newBuildingNumber,  $newApartmentNumber );
			$options1 =  array('Scrollable' => SQLSRV_CURSOR_FORWARD);
			$result1 = sqlsrv_query( $conn , $sql1, $params1);
					
			if( $result1 === false ) {
				die( print_r( sqlsrv_errors(), true));
		   	}

			/**
			 * Query for inserting user's personal infrmation values
			 *  @param newID -> user's id number
			 *  @param newFirstName -> user's first name
			 *  @param newLastName -> user's last name
			 *  @param newEmail -> user's email address
			 *  @param newBirthDate -> user's birth day
			 *  @param newPwd -> user's password
			 *  @param newPhoneNumber -> user's phone number
			 */
			$sql2 = "INSERT INTO TblSystemUser (id, firstName, lastName	, email, birthDate, pass, phone)
			VALUES ( ? , ? , ? , ? , ? , ?, ?);";
			$params2 = array( $newID, $newFirstName,$newLastName, $newEmail, $newBirthDate, $newPwd, $newPhoneNumber); ///*base64_decode($name)*/
			$options2 =  array('Scrollable' => SQLSRV_CURSOR_FORWARD);
			$result2 = sqlsrv_query( $conn , $sql2, $params2);	
			
			if( $result2 === false ) {
				die( print_r( sqlsrv_errors(), true));
		   	}
			

			/**
			 * Query for creating travel card for the user and initializing it with 0 Shekels
			 *  @param moneyAmount -> user's id number
			 *  @param join_date -> user's first name
			 */
			   $sql4 = "INSERT INTO TblCard (moneyAmount, cardDate)
			   VALUES ( ? , ?);";
			   $moneyAmount =0;
			   $params4 = array($moneyAmount,$join_date); ///*base64_decode($name)*/
			   $options4 =  array('Scrollable' => SQLSRV_CURSOR_FORWARD);
			   $result4 = sqlsrv_query( $conn , $sql4, $params4);	
			   
			   if( $result4 === false ) {
				   die( print_r( sqlsrv_errors(), true));
			 }


			 /**
			 * Query for getting the new travel card number
			 *  @return cardNumber -> greatest catd number
			 */
			 $sql5 = "SELECT max(TblCard.cardNumber) from TblCard ";
			 $stmt5 = sqlsrv_query( $conn, $sql5);
				if( $stmt5 === false ) {
				  die( print_r( sqlsrv_errors(), true));
				}
		  
				if( sqlsrv_fetch( $stmt5 ) === false) {
				  die( print_r( sqlsrv_errors(), true));
				}

			// Save the card number in variable
			$cardNum = sqlsrv_get_field( $stmt5, 0);


			/**
			 * Query for inserting user's personal infrmation values
			 *  @param newID -> user's id number
			 *  @param newcovid19Value -> user's covid19 parameter preference
			 *  @param join_date -> user's join date
			 *  @param cardNum -> user's card number 
			 *  @param newZipCode -> user's zip code
			 *  @param newLoad -> user's load parameter preference
			 *  @param newStreet -> user's street
			 *  @param newBuildingNumber -> user's building number
			 *  @param newApartmentNumber -> user's apartment number
			 */
			$sql3= "INSERT INTO TblCustomer VALUES ( ? , ? , ? , ? , ? , ?, ?, ? , ? , ? );";
			$params3 = array( $newID, $newcovid19Value , $join_date, $cardNum, $newCity,$newZipCode, $newLoad, $newStreet, $newBuildingNumber, $newApartmentNumber );
			$options3 =  array('Scrollable' => SQLSRV_CURSOR_FORWARD);
			$result3 = sqlsrv_query( $conn , $sql3, $params3);
			
			if( $result3 === false ) {
				die( print_r( sqlsrv_errors(), true));
		   	}

			// if(isset($_POST['file'])){
			
			// 	echo "HELLLO";
			// 	// $_FILES['img1']['name'] = $_POST['img1'];
			// 	// $name = $_FILES['img1']['name'];
			// 	$target_dir = "upload/";
			// 	$target_file = $target_dir . basename($_FILES["file"]["name"]);
			
			// 	// Select file type
			// 	$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
			
			// 	// Valid file extensions
			// 	$extensions_arr = array("jpg","jpeg","png","gif");
			
			// 	// Check extension
			// 	if( in_array($imageFileType,$extensions_arr) ){
			// 		// Upload file
			// 		if(move_uploaded_file($_FILES['file']['tmp_name'],$target_dir.$name)){
			// 			// Convert to base64 
			// 			$image_base64 = base64_encode(file_get_contents('upload/'.$name) );
			// 			$image = 'data:image/'.$imageFileType.';base64,'.$image_base64;
			// 			// Insert record
			// 			$query = "INSERT into TblSystemUser (img) values('$image') WHERE id= $newID  ";
			// 			$result4 = sqlsrv_query($conn,$query);
			// 			if( $result4 === false ) {
			// 				die( print_r( sqlsrv_errors(), true));
			// 			}
			// 			$img_move = true;
	
			// 		}
				
			// 	}
			
			// }

			/**
			 * If all 3 queries are ok, commit transaction
			 */
			if( $sql1 && $sql2 && $sql3 ) {
				sqlsrv_commit( $conn );
				if($img_uploaded == true){ // If image is uploaded case
					header('Location: SuccessMessage.html'); // Redirect to Success page		

					// if($img_move == true ){
					// }
					// else{
					// 	echo "Image Couldn't be uploaded";
					// }
					// echo"					
					// 	<!-- Modal HTML -->
					// 	<div id="myModal" class="modal fade">
					// 		<div class="modal-dialog modal-confirm">
					// 			<div class="modal-content">
					// 				<div class="modal-header">
					// 					<div class="icon-box">
					// 						<i class="material-icons">&#xE876;</i>
					// 					</div>				
					// 					<h4 class="modal-title w-100">Awesome!</h4>	
					// 				</div>
					// 				<div class="modal-body">
					// 					<p class="text-center">Your booking has been confirmed. Check your email for detials.</p>
					// 				</div>
					// 				<div class="modal-footer">
					// 					<button class="btn btn-success btn-block" data-dismiss="modal">OK</button>
					// 				</div>
					// 			</div>
					// 		</div>
					// 	</div>  ";

				}

				else{ // If no image is uploaded case
					header('Location: SuccessMessage.html'); // Redirect to Success page	

				}
				
			} else { 
				
				// If something went wrong
				sqlsrv_rollback( $conn );		
			}

		
		}
			
	
	


?>