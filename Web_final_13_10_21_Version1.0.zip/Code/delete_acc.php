<?php

    /** 
     * This file contains deleting customer account functionality 
     */

    //Start Session:
    session_start(); 
        
    //Check if session is set, if not:(User is not signed in) -> redirect to index.php
    if(!isset($_SESSION['username']) ){
        session_destroy();    
        header("Location: index.php");
    }

    //If Session is set:---------------------------------

    /**
     * Including/Calling DB connection
     * @return connection
     */
    require "databaseconnection.php";

    $user_session = $_SESSION['username']; // Get users id from the session

    /**
     * Query for deleting the user from TblCustomerExitEnter DB table
     * @param user_session -> user id
     */
    $sql1 = "DELETE FROM TblCustomerExitEnter WHERE id = $user_session";
    $stmt1 = sqlsrv_query($conn, $sql1);
   
    if( $stmt1 === false  ) {
        die( print_r( sqlsrv_errors(), true));
    }

    //-------------------------------------------------------
    
     /**
     * Query for deleting the user from TblCustSearch DB table
     * @param user_session -> user id
     */
    $sql2 = "DELETE FROM TblCustSearch WHERE id = $user_session";
    $stmt2 = sqlsrv_query($conn, $sql2);
   
    if( $stmt2 === false  ) {
        die( print_r( sqlsrv_errors(), true));
    }

    //-------------------------------------------------------


    /**
     * Query for deleting the user from TblCustomer DB table
     * @param user_session -> user id
     */
    $sql3 = "DELETE FROM TblCustomer WHERE id = $user_session";
    $stmt3 = sqlsrv_query($conn, $sql3);
   
    if( $stmt3 === false  ) {
        die( print_r( sqlsrv_errors(), true));
    }

    //-------------------------------------------------------

    /**
     * Query for deleting the user from TblSystemUser DB table
     * @param user_session -> user id
     */
    $sql4 = "DELETE FROM TblSystemUser WHERE id = $user_session";
    // $params = array($user_session);
    $stmt4 = sqlsrv_query( $conn, $sql4);

    if( $stmt4 === false  ) {
        die( print_r( sqlsrv_errors(), true));
    }


    /** 
     * If all queries successfully executed -> Account is deleted
     * Redirect the user to 'index_logout.php' file, which logs the user out
     */
    echo"
    <script>
        window.location.href ='index_logout.php';
    </script>";

//-------------------------------------------------------

?>