<?php 

    /** 
     * This file contains form for loading the travel card for registered customers
     */

    //Start Session:
    session_start(); 
    
    //Check if session is set, if not:(User is not signed in) -> redirect to index.php
    if(!isset($_SESSION['username']) ){
        session_destroy();    
        header("Location: index.php");
    }

    //If Session is set:---------------------------------

    /**
     * If the loading card functionality failed -> Show the alert message here
     */
    if(isset($_GET['msg'])){ 
        ?>
<div class="alert alert-success" role="alert" style="background-color : #26c281">
    Card Amount Updated!
</div> <!-- Alert -->
<?php
            unset($_GET['msg']); //Unset the variable
    }
            
        ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Styles/customer_registration.css">

    <title>Document</title>

    <?php
        include 'customer_layout.php'; 
    ?>

    <!-- Styling settings -->
    <style>
        .row {
            width: 50%;
            content: "";
            display: flex;
            clear: both;
            text-align: center;
            margin: 0 auto;
            margin-top: 30px;
            justify-content: space-around;
        }

        .column {
            /* margin-right: auto; */
            width: auto;
        }

        .form-group {
            margin-bottom: 15px;
            color: black;

            /* margin-bottom: 20px; */
            /* margin-top: 30px; */
        }

        .form-control {
            height: 20px;
            width: 196.8px;
            padding: 6px 12px;
            font-size: 14px;
            font-family: cursive;
            display: inherit;
            border-radius: 4px;
            border: 1px solid #ccc;
            text-align: center;
            outline: none;

        }

        .form-control:focus {
            border: 1px solid #66afe9;
        }


        label {
            color: black;
            display: inline-block;
            max-width: 100%;
            margin-bottom: 5px;
            font-weight: 700;
            font-size: 14px;
        }

        #load_btn {
            color: #fff;
            background-color: #5cb85c;
            border-color: #4cae4c;
            font-weight: 400;
            text-align: center;
            white-space: nowrap;
            vertical-align: middle;
            touch-action: manipulation;
            cursor: pointer;
            background-image: none;
            border: 1px solid transparent;
            padding: 6px 12px;
            font-size: 14px;
            line-height: 1.42857143;
            border-radius: 4px;
            font-family: cursive;
            display: block;
            margin: auto;

        }

        #load_btn:hover {
            background-color: #4CAF50;
            color: white
        }
    </style>

    <script>

        /**
         * function that gets fired by event that returns only numbers input -> disables other characters 
         * @event onclick entering data input in form
         * @param evt 
         * @return boolean
         */
        function onlyNumberKey(evt) {

            // Only ASCII character in that range allowed
            var ASCIICode = (evt.which) ? evt.which : evt.keyCode

            // Check if the inserted charcter is a number in ASCII code
            if (ASCIICode > 31 && (ASCIICode < 48 || ASCIICode > 57))
                return false;
            return true;
        }

    </script>

</head>

<body>

    <?php

        $user_id = $_SESSION['username']; // Gedt users ID number from the session
        
        if(isset($_GET['msg']) && ($_GET['msg']== "failed")){

            echo"
                <div class='error-message' style='color:red;'> Something went wrong, please try again</div>";
        }
        
         /**
         * Query for getting specific card number from TblCustomer via his ID
         * @param  user_id 
         */
        $sql_card_number = "SELECT cardNumber FROM TblCustomer WHERE id = '$user_id' ";

        $result_card_number = sqlsrv_query( $conn , $sql_card_number);

        if( $result_card_number === false ) {
            die( print_r( sqlsrv_errors(), true));
        }

        if( sqlsrv_fetch( $result_card_number ) === false) {
            die( print_r( sqlsrv_errors(), true));
        }

        // Get the sql query result field:
        $user_card_number = sqlsrv_get_field($result_card_number, 0);
    
        /**
         * Query for getting users card amount from TblCard via his card number
         * @param  user_card_number 
         */
        $sql = "SELECT moneyAmount FROM TblCard WHERE cardNumber = '$user_card_number' ";

        $result = sqlsrv_query( $conn , $sql);

        if( $result === false ) {
            die( print_r( sqlsrv_errors(), true));
        }

        if( sqlsrv_fetch( $result ) === false) {
            die( print_r( sqlsrv_errors(), true));
        }

        // Get the sql query result field -> current amount:
        $left_amount_in_card = sqlsrv_get_field($result, 0); 

    ?>

    <div class="signup-form">

        <!-- Load card form which contains 6 inputs -->
        <form action="load_card_charge.php" method="post">

            <!-- Show the user the current amount -->
            <label for="CardNumberAmount"> Amount left in card: </label>
            <input type="number" id="CardNumberAmount" name="CardNumberAmount"
                value="<?php echo $left_amount_in_card; ?>" style="text-align: center; background-color : #d1d1d1;"
                readonly>

            <div class="row">
                <!-- Form row -->

                <div class="column">
                    <!-- First column of the form -->


                    <!-- First input field: travel card number -->
                    <div class="form-group">
                        <label for="travelCardNumber"> Travel Card Number: </label>
                        <input type="text" class="form-control" id="travelCardNumber" name="travelCardNumber"
                            placeholder="Enter travel card number" onkeypress="return onlyNumberKey(event)"
                            maxlength="5" value=<?php echo $user_card_number; ?> >
                    </div>

                    <!-- Second input field: credit card number -->
                    <div class="form-group">
                        <label for="creditCardNumber"> Credit Card Number: </label>
                        <input type="text" class="form-control" id="creditCardNumber" pattern="\d{16}"
                            onkeypress="return onlyNumberKey(event)" maxlength="16" name="creditCardNumber" placeholder="16 Digits" required>
                    </div>

                    <!-- Third input field: credit card expiry date -->
                    <div class="form-group">
                        <label for="expiryDate"> Expiry Date: </label>
                        <input type="month" class="form-control" id="expiryDate" name="expiryDate" min="2021-10" required>
                    </div>
                </div><!-- End of fisrt column of the form -->

                <div class="column">
                    <!-- Second column of the form -->

                    <!-- Fourth input field: Money amount -->
                    <div class="form-group">
                        <label for="amount"> Amount: </label>
                        <input type="text" class="form-control" max="999" maxlength="3" id="amount" name="amount"
                            placeholder="Enter wished amount" onkeypress="return onlyNumberKey(event)" required />
                    </div>

                    <!-- Fifth input field: credit card company -->
                    <div class="form-group">
                        <label for="creditCardCompany"> Credit Card Company:</label>

                        <select name="creditCardCompany" class="form-control" id="creditCardCompany"
                            style="height: auto; width: -webkit-fill-available;"  required>
                            <option value="Visa">Visa</option>
                            <option value="Mastercard"> Mastercard</option>
                            <option value="American Express"> American Express </option>
                        </select>
                    </div>

                    <!-- Sixth input field: credit card CVV -->
                    <div class="form-group">
                        <label for="cvv"> CVV: </label>
                        <input type="text" class="form-control" onkeypress="return onlyNumberKey(event)" maxlength="3"
                            id="cvv" name="cvv" maxlength="4" placeholder= "3 Digits (Placed on the back)"   required>
                    </div>
                </div>
            </div>

            <!-- Charge credit card button -->
            <button id="load_btn" type="submit"> Charge </button>

        </form> <!-- End of form -->
    </div>
    <!-- </div> -->

</body>

</html>