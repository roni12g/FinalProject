<?php 	
    include 'customer_layout.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="Styles/lines&stations.css">

</head>

<body>
    <!-- <div class="contant"> -->
    <div class="line-list">
        <ul style="display: flex; justify-content: space-around;margin-top: 50px;">

            <div class="red-line">
                <li id="red" onClick="showMap(this.id)">Red Line</li>
                <p>From Petah Tikva through Bnei Brak, <br> Ramat Gan and Tel Aviv to Bat Yam</p>
                <a href="images/linesAndStations/red-line.jpg">
                    <img class="pic" id="red-pic" src="images/linesAndStations/red-line.jpg" alt="">
                </a>

            </div>
            <div class="green-line">
                <li id="green" onClick="showMap(this.id)">Green Line</li>
                <p>From Herzliya through Tel Aviv and <br> Holon to Rishon Lezion</p>
                <a href="images/linesAndStations/green-line.jpg">
                    <img class="pic" id="green-pic" src="images/linesAndStations/green-line.jpg" alt=""></a>
            </div>


            <div class="purple-line">
                <li id="purple" onClick="showMap(this.id)">Purple Line</li>
                <p>From Tel Aviv through Ramat Gan,<br> Givat Shmuel, Or Yehuda to Yehud</p>
                <a href="images/linesAndStations/purple-line.jpg">
                    <img class="pic" id="purple-pic" src="images/linesAndStations/purple-line.jpg" alt=""></a>
            </div>
        </ul>
    </div>
    <!-- <div class="side-pic">
            <img src="images/map.png" alt="" style="float: right;" width="30%"
            height="100%">
        </div> -->
    <!-- </div> -->
</body>

<script>

    function showMap(clicked_id) {
        let color = clicked_id;
        document.getElementById(color + "-pic").classList.toggle('show');
    }

</script>

</html>